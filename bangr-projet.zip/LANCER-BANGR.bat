@echo off
chcp 65001 >nul
title BANGR - Lancement
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto nonode

if not exist node_modules (
  echo [1/4] Installation du site - la premiere fois, cela prend quelques minutes...
  call npm install
  if errorlevel 1 goto erreur
)
echo [2/4] Construction du site...
call npm run build
if errorlevel 1 goto erreur

if not exist desktop\node_modules (
  echo [3/4] Installation de l'application Windows - la premiere fois seulement...
  pushd desktop
  call npm install
  if errorlevel 1 ( popd & goto erreur )
  popd
)
echo [4/4] Lancement de BANGR...
call node scripts\prepare-desktop.mjs
if errorlevel 1 goto erreur
pushd desktop
call npm start
popd
exit /b 0

:nonode
echo.
echo Node.js n'est pas installe sur ce PC.
echo Installe la version LTS depuis https://nodejs.org puis relance ce fichier.
start https://nodejs.org
pause
exit /b 1

:erreur
echo.
echo Une erreur est survenue. Prends une photo ou une capture de cette fenetre et envoie-la.
pause
exit /b 1
