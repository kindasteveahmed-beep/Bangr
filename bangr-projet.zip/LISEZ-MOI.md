# BÃNGR – Ma boutique, bien gérée.
PWA Android : React + TypeScript + IndexedDB (Vite).
- src/domain : logique métier pure (testée) – services.ts, stats.ts, repo.ts (contrat de stockage)
- src/data : IndexedDB (implémentation de Repo)
- src/ui : écrans React
Tests : npm test   |   Développement : npm install && npm run dev   |   Production : npm run build
Une synchronisation distante se branchera en fournissant une autre implémentation de Repo.
