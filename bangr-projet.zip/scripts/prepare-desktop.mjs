// Copie le site construit (dist) dans le dossier de l'application Windows (desktop).
import { cpSync, rmSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
if (!existsSync(join(root, 'dist', 'index.html'))) { console.error('Le site n\'est pas construit : lance d\'abord "npm run build".'); process.exit(1); }
rmSync(join(root, 'desktop', 'dist'), { recursive: true, force: true });
cpSync(join(root, 'dist'), join(root, 'desktop', 'dist'), { recursive: true });
mkdirSync(join(root, 'desktop', 'build'), { recursive: true });
cpSync(join(root, 'icon-1024.png'), join(root, 'desktop', 'build', 'icon.png'));
console.log('Application Windows prête dans desktop/.');
