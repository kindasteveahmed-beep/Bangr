import type { SyncRepo, StoreName, Op } from '../domain/repo.ts';
import { STORE_NAMES } from '../domain/repo.ts';

// Stockage persistant sur l'appareil (IndexedDB). putMany = une seule transaction : tout ou rien.
export class IdbRepo implements SyncRepo {
  private db: Promise<IDBDatabase>;
  constructor(name = 'bangr') {
    this.db = new Promise((res, rej) => {
      const r = indexedDB.open(name, 2);
      r.onupgradeneeded = () => {
        const db = r.result;
        for (const s of STORE_NAMES) if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: 'id' });
        if (!db.objectStoreNames.contains('outbox')) db.createObjectStore('outbox', { keyPath: 'key' });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  private req<T>(r: IDBRequest): Promise<T> { return new Promise((res, rej) => { r.onsuccess = () => res(r.result as T); r.onerror = () => rej(r.error); }); }
  private done(t: IDBTransaction) { return new Promise<void>((res, rej) => { t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); }); }
  async all<T>(s: StoreName) { const d = await this.db; return this.req<T[]>(d.transaction(s, 'readonly').objectStore(s).getAll()); }
  async get<T>(s: StoreName, id: string) { const d = await this.db; return this.req<T | undefined>(d.transaction(s, 'readonly').objectStore(s).get(id)); }
  async putMany(ops: Op[]) {
    const d = await this.db; const u = Date.now();
    const t = d.transaction([...new Set(ops.map((o) => o.s)), 'outbox'], 'readwrite');
    const p = this.done(t);
    for (const o of ops) { const v = { ...(o.v as object), u } as unknown as { id: string }; t.objectStore(o.s).put(v); t.objectStore('outbox').put({ key: o.s + ':' + v.id }); }
    await p;
  }
  async putRemote(ops: Op[]) {
    const d = await this.db;
    const t = d.transaction([...new Set(ops.map((o) => o.s))], 'readwrite');
    const p = this.done(t);
    for (const o of ops) t.objectStore(o.s).put(o.v);
    await p;
  }
  async outbox() { const d = await this.db; return this.req<string[]>(d.transaction('outbox', 'readonly').objectStore('outbox').getAllKeys()); }
  async clearOutbox(keys: string[]) { const d = await this.db; const t = d.transaction('outbox', 'readwrite'); const p = this.done(t); for (const k of keys) t.objectStore('outbox').delete(k); await p; }
  async markAllDirty() {
    const d = await this.db; const all: string[] = [];
    for (const s of STORE_NAMES) for (const id of await this.req<string[]>(d.transaction(s, 'readonly').objectStore(s).getAllKeys())) all.push(s + ':' + id);
    const t = d.transaction('outbox', 'readwrite'); const p = this.done(t);
    for (const key of all) t.objectStore('outbox').put({ key });
    await p;
  }
}
