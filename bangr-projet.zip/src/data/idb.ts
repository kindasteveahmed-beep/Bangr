import type { Repo, StoreName, Op } from '../domain/repo.ts';
const STORES: StoreName[] = ['products', 'moves', 'sales'];

// Stockage persistant sur l'appareil (IndexedDB). putMany = une seule transaction : tout ou rien.
export class IdbRepo implements Repo {
  private db: Promise<IDBDatabase>;
  constructor(name = 'bangr') {
    this.db = new Promise((res, rej) => {
      const r = indexedDB.open(name, 1);
      r.onupgradeneeded = () => { for (const s of STORES) r.result.createObjectStore(s, { keyPath: 'id' }); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  private req<T>(r: IDBRequest): Promise<T> { return new Promise((res, rej) => { r.onsuccess = () => res(r.result as T); r.onerror = () => rej(r.error); }); }
  async all<T>(s: StoreName) { const d = await this.db; return this.req<T[]>(d.transaction(s, 'readonly').objectStore(s).getAll()); }
  async get<T>(s: StoreName, id: string) { const d = await this.db; return this.req<T | undefined>(d.transaction(s, 'readonly').objectStore(s).get(id)); }
  async putMany(ops: Op[]) {
    const d = await this.db;
    const t = d.transaction([...new Set(ops.map((o) => o.s))], 'readwrite');
    await new Promise<void>((res, rej) => {
      for (const o of ops) t.objectStore(o.s).put(o.v);
      t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    });
  }
}
