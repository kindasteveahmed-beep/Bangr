import type { ReceiptHeader } from '../domain/receipt.ts';
import { EMPTY_HEADER } from '../domain/receipt.ts';

export interface SimpleKV { get(k: string): string | null; set(k: string, v: string): void }
export const localKV: SimpleKV = { get: (k) => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* stockage indisponible */ } } };
const KEY = 'bangr_receipt';

export function loadHeader(kv: SimpleKV): ReceiptHeader {
  try {
    const raw = JSON.parse(kv.get(KEY) ?? '{}');
    const h = { ...EMPTY_HEADER };
    for (const k of Object.keys(h) as (keyof ReceiptHeader)[]) if (typeof raw[k] === 'string') h[k] = raw[k];
    return h;
  } catch { return { ...EMPTY_HEADER }; }
}
export function saveHeader(kv: SimpleKV, h: ReceiptHeader) { kv.set(KEY, JSON.stringify(h)); }
