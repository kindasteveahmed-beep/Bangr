// Code-barres Code 39 (lisible par tous les lecteurs). n = fin, w = large ; ordre : barre, espace, barre…
const P: Record<string, string> = {
  '0': 'nnnwwnwnn', '1': 'wnnwnnnnw', '2': 'nnwwnnnnw', '3': 'wnwwnnnnn', '4': 'nnnwwnnnw', '5': 'wnnwwnnnn', '6': 'nnwwwnnnn', '7': 'nnnwnnwnw', '8': 'wnnwnnwnn', '9': 'nnwwnnwnn',
  A: 'wnnnnwnnw', B: 'nnwnnwnnw', C: 'wnwnnwnnn', D: 'nnnnwwnnw', E: 'wnnnwwnnn', F: 'nnwnwwnnn', G: 'nnnnnwwnw', H: 'wnnnnwwnn', I: 'nnwnnwwnn', J: 'nnnnwwwnn',
  K: 'wnnnnnnww', L: 'nnwnnnnww', M: 'wnwnnnnwn', N: 'nnnnwnnww', O: 'wnnnwnnwn', P: 'nnwnwnnwn', Q: 'nnnnnnwww', R: 'wnnnnnwwn', S: 'nnwnnnwwn', T: 'nnnnwnwwn',
  U: 'wwnnnnnnw', V: 'nwwnnnnnw', W: 'wwwnnnnnn', X: 'nwnnwnnnw', Y: 'wwnnwnnnn', Z: 'nwwnwnnnn', '-': 'nwnnnnwnw', '.': 'wwnnnnwnn', ' ': 'nwwnnnwnn', '*': 'nwnnwnwnn',
};
export const CODE39_PATTERNS = P;
/** Suite de segments (largeur en modules, plein ou vide). Un trait large vaut `ratio` modules. */
export function code39Bars(text: string, ratio = 2.5): { w: number; bar: boolean }[] {
  const t = text.toUpperCase().split('').filter((c) => c !== '*' && P[c]).join('');
  const out: { w: number; bar: boolean }[] = [];
  [...`*${t}*`].forEach((ch, ci) => {
    if (ci > 0) out.push({ w: 1, bar: false });
    [...P[ch]].forEach((e, i) => out.push({ w: e === 'w' ? ratio : 1, bar: i % 2 === 0 }));
  });
  return out;
}
