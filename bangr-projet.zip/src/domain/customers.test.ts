import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MemoryRepo } from './repo.ts';
import { createProduct, recordSale, cancelSale, createCustomer, updateCustomer, recordDebtPayment, customerBalance, DomainError } from './services.ts';
import { computeStats } from './stats.ts';
import { formatReceiptText, EMPTY_HEADER } from './receipt.ts';
import type { Product, Sale, Customer } from './types.ts';

const D = 86400000;
const T = new Date(2026, 9, 24, 10, 0, 0).getTime();
async function setup() {
  const r = new MemoryRepo();
  const p = await createProduct(r, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 50 }, T);
  const c = await createCustomer(r, { name: 'Awa Ouédraogo', phone: '70 11 22 33' }, T);
  return { r, p, c };
}
const stats = async (r: MemoryRepo, now = T) => computeStats({ products: await r.all<Product>('products'), sales: await r.all<Sale>('sales') }, now);

test('client : nom obligatoire, téléphone valide, doublon refusé', async () => {
  const { r, c } = await setup();
  await assert.rejects(() => createCustomer(r, { name: '  ' }), DomainError);
  await assert.rejects(() => createCustomer(r, { name: 'X', phone: 'abc' }), DomainError);
  await assert.rejects(() => createCustomer(r, { name: 'Y', phone: '70112233' }), /existe déjà/);
  const ok = await createCustomer(r, { name: 'Sans numéro' }); assert.equal(ok.phone, '');
  const up = await updateCustomer(r, c.id, { name: 'Awa O.', phone: '70 11 22 33', address: 'Secteur 15' });
  assert.equal(up.name, 'Awa O.'); assert.equal((await r.all<Customer>('customers')).length, 2);
});
test('vente payée en Orange Money : mode enregistré et compté dans les encaissements', async () => {
  const { r, p } = await setup();
  const s = await recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 6000, method: 'ORANGE_MONEY' }, T);
  assert.deepEqual(s.payments, [{ method: 'ORANGE_MONEY', amount: 6000, at: T }]);
  const st = await stats(r); assert.equal(st.day.byMethod.ORANGE_MONEY, 6000); assert.equal(st.day.cashIn, 6000);
  assert.ok(formatReceiptText(s, EMPTY_HEADER).includes('Payé - Orange Money'));
});
test('mode de paiement par défaut : espèces ; mode inconnu refusé', async () => {
  const { r, p } = await setup();
  const s = await recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 3000 }, T);
  assert.equal(s.payments![0].method, 'ESPECES');
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 3000, method: 'BITCOIN' as any }, T), DomainError);
});
test('crédit lié à un client : solde, puis remboursement en Moov Money réparti du plus ancien au plus récent', async () => {
  const { r, p, c } = await setup();
  const s1 = await recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 1000, customerId: c.id }, T);        // doit 5 000
  const s2 = await recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 0, customerId: c.id }, T + 1000);      // doit 3 000
  assert.equal(s1.customerName, 'Awa Ouédraogo');
  assert.equal(customerBalance(await r.all<Sale>('sales'), c.id), 8000);
  await recordDebtPayment(r, c.id, 6000, 'MOOV_MONEY', T + D);
  const sales = await r.all<Sale>('sales'); const a = sales.find((s) => s.id === s1.id)!, b = sales.find((s) => s.id === s2.id)!;
  assert.equal(a.paid, 6000); assert.equal(b.paid, 1000);
  assert.equal(customerBalance(sales, c.id), 2000);
  assert.equal(a.payments!.length, 2); assert.equal(a.payments![1].method, 'MOOV_MONEY');
  const st = await stats(r, T + D);
  assert.equal(st.day.cashIn, 6000); assert.equal(st.day.byMethod.MOOV_MONEY, 6000); assert.equal(st.receivables, 2000);
  assert.equal((await stats(r, T)).day.cashIn, 1000);
});
test('remboursement : montant supérieur à la dette refusé, rien n’est modifié', async () => {
  const { r, p, c } = await setup();
  await recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 0, customerId: c.id }, T);
  await assert.rejects(() => recordDebtPayment(r, c.id, 3001, 'ESPECES', T), /ne doit que/);
  await assert.rejects(() => recordDebtPayment(r, c.id, 0, 'ESPECES', T), DomainError);
  assert.equal(customerBalance(await r.all<Sale>('sales'), c.id), 3000);
});
test('vente à crédit sans client refusée ; client inconnu refusé', async () => {
  const { r, p } = await setup();
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 0 }, T), /client/);
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 0, customerId: 'nope' }, T), DomainError);
});
test('vente annulée : sa dette et ses paiements ne comptent plus', async () => {
  const { r, p, c } = await setup();
  const s = await recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 2000, customerId: c.id, method: 'ORANGE_MONEY' }, T);
  await cancelSale(r, s.id, 'erreur', T);
  const st = await stats(r); assert.equal(st.day.cashIn, 0); assert.equal(st.receivables, 0);
  assert.equal(customerBalance(await r.all<Sale>('sales'), c.id), 0);
});
test('ancienne vente sans mode de paiement : comptée « Non précisé », pas inventée', async () => {
  const { r } = await setup();
  const legacy: any = { id: 'old', number: 'V-00001', at: T, lines: [{ productId: 'x', name: 'Ancien', qty: 1, unitPrice: 1000, unitCost: 500 }], total: 1000, paid: 1000, customerName: '', status: 'VALIDEE' };
  await r.putMany([{ s: 'sales', v: legacy }]);
  const st = await stats(r); assert.equal(st.day.byMethod.INCONNU, 1000); assert.equal(st.day.cashIn, 1000);
  assert.ok(formatReceiptText(legacy, EMPTY_HEADER).includes('Payé'));
});
