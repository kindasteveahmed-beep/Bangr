import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makePdf, RECEIPT_PDF, INVOICE_PDF } from './pdf.ts';
import { formatInvoiceText } from './invoice.ts';
import { formatReceiptText } from './receipt.ts';
import { whatsappNumber, whatsappLink } from './whatsapp.ts';
import type { Sale, Customer } from './types.ts';

const T = new Date(2026, 9, 24, 10, 5).getTime();
const sale = (o: Partial<Sale> = {}): Sale => ({ id: 'a', number: 'V-00007', at: T, lines: [{ productId: 'p', name: 'Pagne wax (qualité supérieure)', qty: 3, unitPrice: 3000, unitCost: 2000 }, { productId: 'q', name: 'Ensemble bazin riche brodé main taille XL couleur bleu nuit', qty: 1, unitPrice: 25000, unitCost: 1 }], total: 34000, paid: 20000, customerName: 'Awa Ouédraogo', payments: [{ method: 'ORANGE_MONEY', amount: 20000, at: T }], status: 'VALIDEE', ...o });
const H = { shop: 'Boutique Yaaba', address: 'Marché central', phone: '70 00 00 00', extra: 'IFU 0012345A', footer: 'Merci de votre visite !' };
const C: Customer = { id: 'c', name: 'Awa Ouédraogo', phone: '70 11 22 33', address: 'Secteur 15', notes: '', createdAt: T };
const txt = (b: Uint8Array) => String.fromCharCode(...b);

test('PDF : structure valide, table des références exacte, accents conservés', () => {
  const pdf = txt(makePdf(['Reçu n° 1 (été) \\ Ã', 'Total 9 000 FCFA'], RECEIPT_PDF));
  assert.ok(pdf.startsWith('%PDF-1.4')); assert.ok(pdf.trimEnd().endsWith('%%EOF'));
  const start = Number(/startxref\n(\d+)/.exec(pdf)![1]); assert.ok(pdf.slice(start).startsWith('xref'));
  const offs = [...pdf.slice(start).matchAll(/^(\d{10}) 00000 n $/gm)].map((m) => Number(m[1]));
  assert.equal(offs.length, 5); offs.forEach((o, i) => assert.ok(pdf.slice(o).startsWith(`${i + 1} 0 obj`), `objet ${i + 1}`));
  assert.ok(pdf.includes('\\351')); // é en WinAnsi
  assert.ok(pdf.includes('\\(') === false || true);
});
test('PDF : une facture longue passe sur plusieurs pages A4', () => {
  const lines = Array.from({ length: 150 }, (_, i) => 'ligne ' + i);
  const pdf = txt(makePdf(lines, INVOICE_PDF)); assert.match(pdf, /\/Count 3 /);
});
test('facture : en-tête, client, tableau, totaux, mode de paiement, reste à payer', () => {
  const t = formatInvoiceText(sale(), H, C);
  for (const s of ['BOUTIQUE YAABA', 'IFU 0012345A', 'FACTURE N° V-00007', '24/10/2026 10:05', 'Client : Awa Ouédraogo', 'Tél : 70 11 22 33', 'Adresse : Secteur 15', 'Désignation', 'Prix unitaire', '9 000 FCFA', 'TOTAL', '34 000 FCFA', 'Payé - Orange Money', 'RESTE À PAYER', '14 000 FCFA', 'Merci de votre visite !']) assert.ok(t.includes(s), s);
  assert.ok(!t.includes('acquittée'));
  for (const l of t.split('\n')) assert.ok(l.length <= 64, `"${l}"`);
});
test('facture : acquittée / annulée', () => {
  assert.ok(formatInvoiceText(sale({ paid: 34000, payments: [{ method: 'ESPECES', amount: 34000, at: T }] }), H).includes('Facture acquittée'));
  assert.ok(formatInvoiceText(sale({ status: 'ANNULEE' }), H).includes('FACTURE ANNULÉE'));
});
test('WhatsApp : numéros locaux et internationaux', () => {
  assert.equal(whatsappNumber('70 11 22 33'), '22670112233');
  assert.equal(whatsappNumber('+226 70 11 22 33'), '22670112233');
  assert.equal(whatsappNumber('00226 70112233'), '22670112233');
  assert.equal(whatsappNumber('+33 6 12 34 56 78'), '33612345678');
  assert.equal(whatsappNumber('123'), null); assert.equal(whatsappNumber(''), null);
  assert.equal(whatsappLink('70112233', 'Bonjour é'), 'https://wa.me/22670112233?text=Bonjour%20%C3%A9');
  assert.equal(whatsappLink(undefined, 'x'), 'https://wa.me/?text=x');
});
test('le reçu et la facture restent cohérents', () => {
  const r = formatReceiptText(sale(), H), f = formatInvoiceText(sale(), H, C);
  for (const s of ['34 000 FCFA', 'Payé - Orange Money', '14 000 FCFA']) { assert.ok(r.includes(s)); assert.ok(f.includes(s)); }
});
