import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MemoryRepo } from './repo.ts';
import { createProduct, updateProduct, adjustStock, recordSale, cancelSale, DomainError } from './services.ts';
import { computeStats } from './stats.ts';
import type { Product, Sale, StockMove } from './types.ts';

const T = new Date(2026, 9, 24, 10, 0, 0).getTime();
async function setup() {
  const r = new MemoryRepo();
  const p = await createProduct(r, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 10, minStock: 2 }, T);
  return { r, p };
}
const stockOf = async (r: MemoryRepo, id: string) => (await r.get<Product>('products', id))!.stock;
const stats = async (r: MemoryRepo) => computeStats({ products: await r.all<Product>('products'), sales: await r.all<Sale>('sales') }, T);

test('stock initial crée un mouvement', async () => {
  const { r, p } = await setup();
  const moves = await r.all<StockMove>('moves');
  assert.equal(moves.length, 1); assert.equal(moves[0].type, 'ENTREE'); assert.equal(moves[0].qty, 10);
  assert.equal(await stockOf(r, p.id), 10);
});
test('vente : stock, total, coût figé, marge', async () => {
  const { r, p } = await setup();
  const s = await recordSale(r, { lines: [{ productId: p.id, qty: 3 }], paid: 9000 }, T);
  assert.equal(s.total, 9000); assert.equal(s.number, 'V-00001'); assert.equal(s.lines[0].unitCost, 2000);
  assert.equal(await stockOf(r, p.id), 7);
  const st = await stats(r);
  assert.equal(st.day.revenue, 9000); assert.equal(st.day.margin, 3000); assert.equal(st.receivables, 0);
});
test('changer le prix d’achat ne modifie pas la marge historique', async () => {
  const { r, p } = await setup();
  await recordSale(r, { lines: [{ productId: p.id, qty: 3 }], paid: 9000 }, T);
  await updateProduct(r, p.id, { costPrice: 2500 });
  assert.equal((await stats(r)).day.margin, 3000);
  assert.equal(await stockOf(r, p.id), 7);
});
test('stock insuffisant : vente refusée, rien n’est modifié', async () => {
  const { r, p } = await setup();
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 11 }], paid: 0, customerName: 'X' }, T), DomainError);
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 6 }, { productId: p.id, qty: 5 }], paid: 33000 }, T), DomainError);
  assert.equal(await stockOf(r, p.id), 10); assert.equal((await r.all<Sale>('sales')).length, 0);
});
test('crédit : nom du client obligatoire, créance calculée', async () => {
  const { r, p } = await setup();
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 2000 }, T), DomainError);
  await recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 2000, customerName: 'Awa' }, T);
  const st = await stats(r);
  assert.equal(st.receivables, 4000); assert.equal(st.day.cashIn, 2000);
  await assert.rejects(() => recordSale(r, { lines: [{ productId: p.id, qty: 1 }], paid: 5000 }, T), DomainError);
});
test('annulation : stock restitué, exclue des stats, pas de double annulation', async () => {
  const { r, p } = await setup();
  const s = await recordSale(r, { lines: [{ productId: p.id, qty: 4 }], paid: 12000 }, T);
  assert.equal(await stockOf(r, p.id), 6);
  await cancelSale(r, s.id, 'Erreur de saisie', T);
  assert.equal(await stockOf(r, p.id), 10);
  const st = await stats(r);
  assert.equal(st.day.count, 0); assert.equal(st.day.revenue, 0);
  await assert.rejects(() => cancelSale(r, s.id, '', T), DomainError);
  assert.equal(await stockOf(r, p.id), 10);
});
test('annulation d’une vente avec deux fois le même produit', async () => {
  const { r, p } = await setup();
  const s = await recordSale(r, { lines: [{ productId: p.id, qty: 2 }, { productId: p.id, qty: 3 }], paid: 15000 }, T);
  assert.equal(await stockOf(r, p.id), 5);
  await cancelSale(r, s.id, '', T);
  assert.equal(await stockOf(r, p.id), 10);
});
test('mouvements manuels : entrée, sortie, stock jamais négatif', async () => {
  const { r, p } = await setup();
  await adjustStock(r, p.id, 'ENTREE', 5, 'Réception fournisseur', T);
  assert.equal(await stockOf(r, p.id), 15);
  await adjustStock(r, p.id, 'SORTIE', -3, 'Casse', T);
  assert.equal(await stockOf(r, p.id), 12);
  await assert.rejects(() => adjustStock(r, p.id, 'SORTIE', -13, '', T), DomainError);
  await assert.rejects(() => adjustStock(r, p.id, 'ENTREE', 0, '', T), DomainError);
  assert.equal(await stockOf(r, p.id), 12);
});
test('validation : prix décimaux ou négatifs refusés ; alerte de stock bas', async () => {
  const r = new MemoryRepo();
  await assert.rejects(() => createProduct(r, { name: 'A', costPrice: 10.5, salePrice: 20 }), DomainError);
  await assert.rejects(() => createProduct(r, { name: ' ', costPrice: 10, salePrice: 20 }), DomainError);
  await assert.rejects(() => createProduct(r, { name: 'A', costPrice: -1, salePrice: 20 }), DomainError);
  await createProduct(r, { name: 'Savon', costPrice: 100, salePrice: 150, stock: 2, minStock: 3 }, T);
  const st = computeStats({ products: await r.all<Product>('products'), sales: [] }, T);
  assert.equal(st.lowStock.length, 1); assert.equal(st.stockValue, 200);
});
