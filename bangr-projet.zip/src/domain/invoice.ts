import type { Customer, Sale } from './types.ts';
import type { ReceiptHeader } from './receipt.ts';
import { fmtDate } from './receipt.ts';
import { fcfa } from './money.ts';
import { PAYMENT_LABEL, paymentsOf } from './payments.ts';

function wrap(s: string, w: number): string[] {
  const out: string[] = []; let cur = '';
  for (let word of s.trim().split(/\s+/).filter(Boolean)) {
    while (word.length > w) { if (cur) { out.push(cur); cur = ''; } out.push(word.slice(0, w)); word = word.slice(w); }
    if (!cur) cur = word; else if (cur.length + 1 + word.length <= w) cur += ' ' + word; else { out.push(cur); cur = word; }
  }
  if (cur) out.push(cur);
  return out;
}
const center = (s: string, w: number) => wrap(s, w).map((l) => ' '.repeat(Math.floor((w - l.length) / 2)) + l);
const row = (a: string, b: string, w: number) => a + ' '.repeat(Math.max(1, w - a.length - b.length)) + b;
const right = (s: string, n: number) => ' '.repeat(Math.max(0, n - s.length)) + s;

/** Facture commerciale simple (texte à chasse fixe, 64 colonnes) : en-tête, client, tableau des articles, totaux, paiements. */
export function formatInvoiceText(sale: Sale, h: ReceiptHeader, customer?: Customer, width = 64): string {
  const w = width, line = '-'.repeat(w), L: string[] = [];
  if (h.shop.trim()) L.push(...center(h.shop.toUpperCase(), w));
  if (h.address.trim()) L.push(...center(h.address, w));
  if (h.phone.trim()) L.push(...center('Tél : ' + h.phone.trim(), w));
  if (h.extra.trim()) L.push(...center(h.extra, w));
  if (L.length) L.push('='.repeat(w));
  L.push(row(`FACTURE N° ${sale.number}`, 'Date : ' + fmtDate(sale.at), w));
  const name = customer?.name || sale.customerName;
  if (name) L.push(...wrap('Client : ' + name, w));
  if (customer?.phone) L.push('Tél : ' + customer.phone);
  if (customer?.address) L.push(...wrap('Adresse : ' + customer.address, w));
  const nameW = w - 4 - 13 - 13 - 3;
  L.push(line, 'Désignation'.padEnd(nameW) + ' ' + right('Qté', 4) + ' ' + right('Prix unitaire', 13) + ' ' + right('Montant', 13), line);
  for (const l of sale.lines) {
    const n = wrap(l.name, nameW);
    L.push((n[0] ?? '').padEnd(nameW) + ' ' + right(String(l.qty), 4) + ' ' + right(fcfa(l.unitPrice), 13) + ' ' + right(fcfa(l.qty * l.unitPrice), 13), ...n.slice(1));
  }
  L.push(line, row('TOTAL', fcfa(sale.total), w));
  for (const p of paymentsOf(sale)) L.push(row(p.method === 'INCONNU' ? 'Payé' : 'Payé - ' + PAYMENT_LABEL[p.method], fcfa(p.amount), w));
  if (!paymentsOf(sale).length) L.push(row('Payé', fcfa(0), w));
  if (sale.total > sale.paid) L.push(row('RESTE À PAYER', fcfa(sale.total - sale.paid), w));
  L.push(line);
  if (sale.status === 'ANNULEE') L.push(...center('*** FACTURE ANNULÉE ***', w));
  else if (sale.paid >= sale.total) L.push(...center('Facture acquittée', w));
  if (h.footer.trim()) L.push(...center(h.footer, w));
  return L.join('\n');
}
