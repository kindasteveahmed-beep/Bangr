export const isMoney = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n) && n >= 0;
export const fcfa = (n: number): string => new Intl.NumberFormat('fr-FR').format(Math.round(n)).replace(/[\u202f\u00a0]/g, ' ') + ' FCFA';
