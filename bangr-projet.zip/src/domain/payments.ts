import type { Payment, PaymentMethod, Sale } from './types.ts';

// Modes proposés à la caisse (INCONNU ne sert que pour les anciennes ventes).
export const PAYMENT_METHODS: PaymentMethod[] = ['ESPECES', 'ORANGE_MONEY', 'MOOV_MONEY'];
export const PAYMENT_LABEL: Record<PaymentMethod, string> = { ESPECES: 'Espèces', ORANGE_MONEY: 'Orange Money', MOOV_MONEY: 'Moov Money', INCONNU: 'Non précisé' };

// Paiements d'une vente. Une ancienne vente sans détail est comptée comme « Non précisé » à la date de la vente.
export function paymentsOf(s: Sale): Payment[] {
  return s.payments ?? (s.paid > 0 ? [{ method: 'INCONNU', amount: s.paid, at: s.at }] : []);
}
