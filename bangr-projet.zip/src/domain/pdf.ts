// Mini générateur de PDF (texte à chasse fixe, police Courier intégrée) : aucune bibliothèque, fonctionne hors connexion.
export interface PdfOpts { width: number; height?: number; margin: number; size: number; leading: number }

const WIN: Record<number, number> = { 0x2019: 0x92, 0x2018: 0x91, 0x201c: 0x93, 0x201d: 0x94, 0x2013: 0x96, 0x2014: 0x97, 0x20ac: 0x80, 0x0153: 0x9c, 0x0152: 0x8c, 0x2026: 0x85 };
/** Texte → chaîne PDF en WinAnsi (accents français inclus) ; les signes inconnus deviennent « ? ». */
function enc(s: string): string {
  let o = '';
  for (const ch of s.replace(/[\u00a0\u202f]/g, ' ')) {
    const c = ch.codePointAt(0)!;
    const b = c < 0x80 || (c >= 0xa0 && c <= 0xff) ? c : WIN[c] ?? 0x3f;
    if (b === 0x28 || b === 0x29 || b === 0x5c) o += '\\' + String.fromCharCode(b);
    else if (b < 0x20 || b > 0x7e) o += '\\' + b.toString(8).padStart(3, '0');
    else o += String.fromCharCode(b);
  }
  return o;
}

export function makePdf(lines: string[], o: PdfOpts): Uint8Array {
  const perPage = o.height ? Math.max(1, Math.floor((o.height - 2 * o.margin) / o.leading)) : Math.max(1, lines.length);
  const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += perPage) pages.push(lines.slice(i, i + perPage));
  if (!pages.length) pages.push([]);
  const h = o.height ?? 2 * o.margin + Math.max(1, lines.length) * o.leading;
  const objs: string[] = ['<< /Type /Catalog /Pages 2 0 R >>', `<< /Type /Pages /Kids [${pages.map((_, i) => `${4 + 2 * i} 0 R`).join(' ')}] /Count ${pages.length} >>`, '<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>'];
  pages.forEach((pl, i) => {
    const content = `BT /F1 ${o.size} Tf ${o.leading} TL ${o.margin} ${(h - o.margin - o.size).toFixed(2)} Td\n${pl.map((l) => `(${enc(l)}) Tj T*`).join('\n')}\nET`;
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${o.width} ${h.toFixed(2)}] /Resources << /Font << /F1 3 0 R >> >> /Contents ${5 + 2 * i} 0 R >>`);
    objs.push(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
  });
  let out = '%PDF-1.4\n'; const off: number[] = [];
  objs.forEach((b, i) => { off.push(out.length); out += `${i + 1} 0 obj\n${b}\nendobj\n`; });
  const x = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${off.map((n) => String(n).padStart(10, '0') + ' 00000 n \n').join('')}trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${x}\n%%EOF\n`;
  return Uint8Array.from(out, (c) => c.charCodeAt(0));
}
// Formats prêts à l'emploi
export const RECEIPT_PDF: PdfOpts = { width: 226.77, margin: 14, size: 9, leading: 11 }; // ticket de 80 mm, hauteur automatique
export const INVOICE_PDF: PdfOpts = { width: 595.28, height: 841.89, margin: 36, size: 10, leading: 12.5 }; // A4
