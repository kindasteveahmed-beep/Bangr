import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MemoryRepo } from './repo.ts';
import { createProduct, recordSale, DomainError } from './services.ts';
import { computeStats } from './stats.ts';
import { createExpense, cancelExpense, dateToMs, EXPENSE_CATEGORIES, createSupplierOrder, paySupplierOrder, deliverSupplierOrder, deleteSupplierOrder, supplierDebt, createClientOrder, collectClientOrder, deliverClientOrder, deleteClientOrder, clientOrdersDue } from './purchasing.ts';
import type { ClientOrder, Expense, Product, Sale, SupplierOrder } from './types.ts';

const T = new Date(2026, 9, 24, 10, 0, 0).getTime();
const stats = async (r: MemoryRepo) => computeStats({ products: await r.all<Product>('products'), sales: await r.all<Sale>('sales'), expenses: await r.all<Expense>('expenses'), supplierOrders: await r.all<SupplierOrder>('supplierOrders') }, T);

test('dépenses : les 6 catégories, validations', async () => {
  const r = new MemoryRepo();
  assert.deepEqual([...EXPENSE_CATEGORIES], ['Marchandise', 'Loyer', 'Transport', 'Salaire', 'Électricité / Eau', 'Autre']);
  const e = await createExpense(r, { category: 'Loyer', amount: 50000, description: ' Loyer octobre ', method: 'ORANGE_MONEY' }, T);
  assert.equal(e.description, 'Loyer octobre'); assert.equal(e.status, 'VALIDEE'); assert.equal(e.method, 'ORANGE_MONEY');
  await assert.rejects(() => createExpense(r, { category: 'Cadeaux', amount: 100 }, T), DomainError);
  await assert.rejects(() => createExpense(r, { category: 'Autre', amount: 0 }, T), /positif/);
  await assert.rejects(() => createExpense(r, { category: 'Autre', amount: 10.5 }, T), DomainError);
  await assert.rejects(() => createExpense(r, { category: 'Autre', amount: 100, at: T + 5 * 86400000 }, T), /date/);
  assert.equal((await r.all<Expense>('expenses')).length, 1);
});
test('dépenses : chiffres du jour/mois, bénéfice net sans double compte de la marchandise, suppression', async () => {
  const r = new MemoryRepo();
  const p = await createProduct(r, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 5 }, T);
  await recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 6000 }, T); // marge 2 000
  const loyer = await createExpense(r, { category: 'Loyer', amount: 500 }, T);
  await createExpense(r, { category: 'Marchandise', amount: 9000 }, T);
  await createExpense(r, { category: 'Transport', amount: 300, at: T - 3 * 86400000 }, T);
  let st = await stats(r);
  assert.equal(st.day.expenses, 9500); assert.equal(st.day.opExpenses, 500); assert.equal(st.day.profit, 1500);
  assert.equal(st.month.expenses, 9800); assert.equal(st.month.profit, 2000 - 800);
  await cancelExpense(r, loyer.id, T); st = await stats(r);
  assert.equal(st.day.expenses, 9000); assert.equal(st.day.profit, 2000);
  await assert.rejects(() => cancelExpense(r, loyer.id, T), /déjà annulée/);
});
test('date saisie : aujourd’hui garde l’heure, un autre jour = midi', () => {
  assert.equal(dateToMs('2026-10-24', T), T);
  assert.equal(new Date(dateToMs('2026-10-20', T)).getHours(), 12); assert.equal(dateToMs('n’importe quoi', T), T);
});
test('commande fournisseur : création avec montant déjà versé (crée la dépense), validations', async () => {
  const r = new MemoryRepo();
  const o = await createSupplierOrder(r, { supplier: ' Grossiste Kone ', goods: '20 sacs de riz', total: 400000, paid: 100000, dueDate: T + 5 * 86400000 }, T);
  assert.equal(o.number, 'F-00001'); assert.equal(o.supplier, 'Grossiste Kone'); assert.equal(o.status, 'EN_ATTENTE'); assert.equal(o.paid, 100000);
  const ex = await r.all<Expense>('expenses'); assert.equal(ex.length, 1); assert.equal(ex[0].amount, 100000); assert.equal(ex[0].category, 'Marchandise'); assert.equal(ex[0].orderId, o.id);
  assert.equal((await createSupplierOrder(r, { supplier: 'B', goods: 'x', total: 10 }, T)).number, 'F-00002'); // sans acompte : pas de dépense
  assert.equal((await r.all<Expense>('expenses')).length, 1);
  await assert.rejects(() => createSupplierOrder(r, { supplier: '', goods: 'x', total: 10 }, T), /Fournisseur/);
  await assert.rejects(() => createSupplierOrder(r, { supplier: 'A', goods: '  ', total: 10 }, T), /Marchandise/);
  await assert.rejects(() => createSupplierOrder(r, { supplier: 'A', goods: 'x', total: 0 }, T), /positif/);
  await assert.rejects(() => createSupplierOrder(r, { supplier: 'A', goods: 'x', total: 100, paid: 101 }, T), /entre 0 et le total/);
});
test('commande fournisseur : paiements, dette, réception, suppression (retire ses dépenses)', async () => {
  const r = new MemoryRepo();
  const o = await createSupplierOrder(r, { supplier: 'Kone', goods: 'riz', total: 30000, paid: 10000 }, T);
  assert.equal(supplierDebt(await r.all<SupplierOrder>('supplierOrders')), 20000); assert.equal((await stats(r)).payables, 20000);
  await paySupplierOrder(r, o.id, 5000, 'ORANGE_MONEY', T + 1);
  await assert.rejects(() => paySupplierOrder(r, o.id, 15001, 'ESPECES', T), /reste que 15\s?000/);
  const done = await paySupplierOrder(r, o.id, 15000, 'ESPECES', T + 2);
  assert.equal(done.paid, 30000); assert.equal(supplierDebt(await r.all<SupplierOrder>('supplierOrders')), 0);
  await assert.rejects(() => paySupplierOrder(r, o.id, 1, 'ESPECES', T), /déjà payée/);
  assert.equal((await stats(r)).month.expenses, 30000);
  assert.equal((await deliverSupplierOrder(r, o.id, T + 3)).status, 'LIVREE');
  await assert.rejects(() => deliverSupplierOrder(r, o.id, T), /déjà/);
  const pay = (await r.all<Expense>('expenses'))[0]; await assert.rejects(() => cancelExpense(r, pay.id, T), /commande/);
  await deleteSupplierOrder(r, o.id, T + 4);
  assert.equal((await r.get<SupplierOrder>('supplierOrders', o.id))!.deleted, true);
  assert.equal((await stats(r)).month.expenses, 0); assert.equal((await stats(r)).payables, 0);
  await assert.rejects(() => paySupplierOrder(r, o.id, 1, 'ESPECES', T), /introuvable/); await assert.rejects(() => deleteSupplierOrder(r, o.id), /introuvable/);
});
test('commande client : avance, encaissement du solde, livraison, suppression', async () => {
  const r = new MemoryRepo();
  const o = await createClientOrder(r, { customer: ' Awa ', item: '3 pagnes sur mesure', total: 45000, advance: 15000, dueDate: T + 7 * 86400000 }, T);
  assert.equal(o.number, 'K-00001'); assert.equal(o.customer, 'Awa'); assert.equal(o.status, 'EN_ATTENTE');
  assert.equal(clientOrdersDue(await r.all<ClientOrder>('clientOrders')), 30000);
  await assert.rejects(() => collectClientOrder(r, o.id, 30001), /reste que 30\s?000/);
  assert.equal((await collectClientOrder(r, o.id, 30000)).advance, 45000);
  await assert.rejects(() => collectClientOrder(r, o.id, 1), /déjà payée/);
  assert.equal((await deliverClientOrder(r, o.id, T)).status, 'LIVREE'); await assert.rejects(() => deliverClientOrder(r, o.id, T), /déjà livrée/);
  await deleteClientOrder(r, o.id); assert.equal(clientOrdersDue(await r.all<ClientOrder>('clientOrders')), 0);
  await assert.rejects(() => createClientOrder(r, { customer: '', item: 'x', total: 10 }, T), /Client/);
  await assert.rejects(() => createClientOrder(r, { customer: 'A', item: '', total: 10 }, T), /Article/);
  await assert.rejects(() => createClientOrder(r, { customer: 'A', item: 'x', total: 10, advance: 11 }, T), /entre 0 et le prix total/);
});
