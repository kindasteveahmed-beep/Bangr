import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MemoryRepo } from './repo.ts';
import { createProduct, recordSale, DomainError } from './services.ts';
import { computeStats } from './stats.ts';
import { createExpense, cancelExpense, dateToMs, createSupplier, updateSupplier, archiveSupplier, restoreSupplier, createOrder, receiveOrder, payOrder, cancelOrder, supplierBalance, EXPENSE_CATEGORIES } from './purchasing.ts';
import type { Expense, Product, PurchaseOrder, Sale, StockMove, Supplier } from './types.ts';

const T = new Date(2026, 9, 24, 10, 0, 0).getTime();
async function setup() {
  const r = new MemoryRepo();
  const p = await createProduct(r, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 5, minStock: 1 }, T);
  const s = await createSupplier(r, { name: 'Grossiste Kone', phone: '70 22 33 44' }, T);
  return { r, p, s };
}
const stats = async (r: MemoryRepo) => computeStats({ products: await r.all<Product>('products'), sales: await r.all<Sale>('sales'), expenses: await r.all<Expense>('expenses'), orders: await r.all<PurchaseOrder>('orders') }, T);

test('dépenses : les 6 catégories, validations', async () => {
  const r = new MemoryRepo();
  assert.deepEqual([...EXPENSE_CATEGORIES], ['Marchandise', 'Loyer', 'Transport', 'Salaire', 'Électricité / Eau', 'Autre']);
  const e = await createExpense(r, { category: 'Loyer', amount: 50000, description: ' Loyer octobre ', method: 'ORANGE_MONEY' }, T);
  assert.equal(e.description, 'Loyer octobre'); assert.equal(e.status, 'VALIDEE'); assert.equal(e.method, 'ORANGE_MONEY');
  await assert.rejects(() => createExpense(r, { category: 'Cadeaux', amount: 100 }, T), DomainError);
  await assert.rejects(() => createExpense(r, { category: 'Autre', amount: 0 }, T), /positif/);
  await assert.rejects(() => createExpense(r, { category: 'Autre', amount: 10.5 }, T), DomainError);
  await assert.rejects(() => createExpense(r, { category: 'Autre', amount: 100, at: T + 5 * 86400000 }, T), /date/);
  assert.equal((await r.all<Expense>('expenses')).length, 1);
});
test('dépenses : chiffres du jour/mois, bénéfice net sans double compte de la marchandise, annulation', async () => {
  const { r, p } = await setup();
  await recordSale(r, { lines: [{ productId: p.id, qty: 2 }], paid: 6000 }, T); // marge 2 000
  const loyer = await createExpense(r, { category: 'Loyer', amount: 500 }, T);
  await createExpense(r, { category: 'Marchandise', amount: 9000 }, T);
  await createExpense(r, { category: 'Transport', amount: 300, at: T - 3 * 86400000 }, T); // même mois, pas aujourd'hui
  let st = await stats(r);
  assert.equal(st.day.expenses, 9500); assert.equal(st.day.opExpenses, 500); assert.equal(st.day.profit, 1500);
  assert.equal(st.month.expenses, 9800); assert.equal(st.month.profit, 2000 - 800);
  await cancelExpense(r, loyer.id, T); st = await stats(r);
  assert.equal(st.day.expenses, 9000); assert.equal(st.day.profit, 2000);
  await assert.rejects(() => cancelExpense(r, loyer.id, T), /déjà annulée/);
});
test('date saisie : aujourd’hui garde l’heure, un autre jour = midi', () => {
  assert.equal(dateToMs('2026-10-24', T), T);
  assert.equal(new Date(dateToMs('2026-10-20', T)).getHours(), 12); assert.equal(dateToMs('n’importe quoi', T), T);
});
test('fournisseurs : création, doublon de téléphone, modification, suppression = archivage, restauration', async () => {
  const { r, s } = await setup();
  await assert.rejects(() => createSupplier(r, { name: '' }, T), /obligatoire/);
  await assert.rejects(() => createSupplier(r, { name: 'Autre', phone: '70-22-33-44' }, T), /existe déjà/);
  await assert.rejects(() => createSupplier(r, { name: 'Autre', phone: '12' }, T), /invalide/);
  const u = await updateSupplier(r, s.id, { name: 'Kone & Fils', phone: '70 22 33 44' }); assert.equal(u.name, 'Kone & Fils');
  await archiveSupplier(r, s.id); assert.equal((await r.get<Supplier>('suppliers', s.id))!.active, false);
  await assert.rejects(() => createOrder(r, { supplierId: s.id, lines: [] }, T), DomainError);
  await restoreSupplier(r, s.id); assert.equal((await r.get<Supplier>('suppliers', s.id))!.active, true);
});
test('commande : création, réception (stock +), paiement en deux fois, dette fournisseur', async () => {
  const { r, p, s } = await setup();
  const o = await createOrder(r, { supplierId: s.id, lines: [{ productId: p.id, qty: 10 }, { productId: p.id, qty: 5, unitCost: 1800 }], note: 'urgent' }, T);
  assert.equal(o.number, 'C-00001'); assert.equal(o.total, 10 * 2000 + 5 * 1800); assert.equal(o.status, 'EN_COURS'); assert.equal(o.supplierName, 'Grossiste Kone');
  assert.equal((await r.get<Product>('products', p.id))!.stock, 5); // rien ne bouge avant la réception
  const got = await receiveOrder(r, o.id, T + 1000);
  assert.equal(got.status, 'RECUE'); assert.equal((await r.get<Product>('products', p.id))!.stock, 20);
  const moves = (await r.all<StockMove>('moves')).filter((m) => m.ref === o.id); assert.equal(moves.length, 2); assert.ok(moves.every((m) => m.type === 'ENTREE'));
  await assert.rejects(() => receiveOrder(r, o.id, T), /déjà reçue/);
  assert.equal(supplierBalance(await r.all<PurchaseOrder>('orders'), s.id), 29000);
  await payOrder(r, o.id, 10000, 'ORANGE_MONEY', T + 2000);
  const done = await payOrder(r, o.id, 19000, 'ESPECES', T + 3000);
  assert.equal(done.paid, 29000); assert.equal(supplierBalance(await r.all<PurchaseOrder>('orders'), s.id), 0);
  const exp = (await r.all<Expense>('expenses')).filter((e) => e.orderId === o.id);
  assert.equal(exp.length, 2); assert.ok(exp.every((e) => e.category === 'Marchandise' && e.supplierId === s.id));
  await assert.rejects(() => payOrder(r, o.id, 1, 'ESPECES', T), /déjà payée/);
  await assert.rejects(() => cancelExpense(r, exp[0].id, T), /commande/);
});
test('commande : surpaiement refusé, annulation seulement si rien payé, produit archivé refusé', async () => {
  const { r, p, s } = await setup();
  const a = await createOrder(r, { supplierId: s.id, lines: [{ productId: p.id, qty: 1 }] }, T);
  await assert.rejects(() => payOrder(r, a.id, 2001, 'ESPECES', T), /reste que 2\s?000/);
  await payOrder(r, a.id, 500, 'ESPECES', T);
  await assert.rejects(() => cancelOrder(r, a.id, T), /paiement/);
  const b = await createOrder(r, { supplierId: s.id, lines: [{ productId: p.id, qty: 1 }] }, T);
  assert.equal(b.number, 'C-00002');
  assert.equal((await cancelOrder(r, b.id, T)).status, 'ANNULEE');
  await assert.rejects(() => receiveOrder(r, b.id, T), /annulée/); await assert.rejects(() => payOrder(r, b.id, 10, 'ESPECES', T), /annulée/);
  await receiveOrder(r, a.id, T); await assert.rejects(() => cancelOrder(r, a.id, T), /reçue/);
  assert.equal(supplierBalance(await r.all<PurchaseOrder>('orders')), 1500);
  assert.equal((await stats(r)).payables, 1500);
  await assert.rejects(() => createOrder(r, { supplierId: s.id, lines: [{ productId: 'nope', qty: 1 }] }, T), /introuvable/);
  await assert.rejects(() => createOrder(r, { supplierId: s.id, lines: [{ productId: p.id, qty: 0 }] }, T), /entier positif/);
});
