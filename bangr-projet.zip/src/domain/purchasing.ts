import type { Repo, Op } from './repo.ts';
import type { Expense, PaymentMethod, Product, PurchaseOrder, StockMove, Supplier } from './types.ts';
import { fail, uid, isInt, mv } from './services.ts';
import { fcfa, isMoney } from './money.ts';
import { PAYMENT_METHODS } from './payments.ts';

// ---------- Dépenses ----------
export const EXPENSE_CATEGORIES = ['Marchandise', 'Loyer', 'Transport', 'Salaire', 'Électricité / Eau', 'Autre'] as const;
export interface ExpenseInput { description?: string; category: string; amount: number; method?: PaymentMethod; at?: number }

export async function createExpense(repo: Repo, i: ExpenseInput, now = Date.now()): Promise<Expense> {
  if (!(EXPENSE_CATEGORIES as readonly string[]).includes(i.category)) fail('Choisis une catégorie de dépense.');
  if (!isMoney(i.amount) || i.amount <= 0) fail('Le montant doit être un nombre entier positif (FCFA).');
  const method = i.method ?? 'ESPECES';
  if (!PAYMENT_METHODS.includes(method)) fail('Mode de paiement inconnu.');
  const description = (i.description ?? '').trim();
  if (description.length > 120) fail('La description est trop longue (120 caractères maximum).');
  const at = i.at ?? now;
  if (!Number.isFinite(at) || at > now + 86400000) fail('La date de la dépense est invalide.');
  const e: Expense = { id: uid(), at, category: i.category, description, amount: i.amount, method, status: 'VALIDEE' };
  await repo.putMany([{ s: 'expenses', v: e }]);
  return e;
}
export async function cancelExpense(repo: Repo, id: string, now = Date.now()): Promise<Expense> {
  const e = await repo.get<Expense>('expenses', id);
  if (!e) return fail('Dépense introuvable.');
  if (e.status === 'ANNULEE') fail('Cette dépense est déjà annulée.');
  if (e.orderId) fail('Ce paiement est lié à une commande fournisseur : il ne peut pas être annulé ici.');
  const done: Expense = { ...e, status: 'ANNULEE', cancelledAt: now };
  await repo.putMany([{ s: 'expenses', v: done }]);
  return done;
}
/** Date saisie (AAAA-MM-JJ) → horodatage : l'heure actuelle si c'est aujourd'hui, sinon midi. */
export function dateToMs(ymd: string, now = Date.now()): number {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd); if (!m) return now;
  const d = new Date(+m[1], +m[2] - 1, +m[3], 12); const n = new Date(now);
  return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate() ? now : d.getTime();
}

// ---------- Fournisseurs ----------
export interface SupplierInput { name: string; phone?: string; address?: string; notes?: string }
const normPhone = (p: string) => p.replace(/[\s.-]/g, '');
function checkSupplier(i: SupplierInput, others: Supplier[], selfId?: string) {
  if (!i.name.trim()) fail('Le nom du fournisseur est obligatoire.');
  const phone = normPhone(i.phone ?? '');
  if (phone && !/^\+?[0-9]{8,15}$/.test(phone)) fail('Numéro de téléphone invalide (8 à 15 chiffres).');
  if (phone && others.some((c) => c.id !== selfId && normPhone(c.phone) === phone)) fail('Un fournisseur avec ce numéro existe déjà.');
}
export async function createSupplier(repo: Repo, i: SupplierInput, now = Date.now()): Promise<Supplier> {
  checkSupplier(i, await repo.all<Supplier>('suppliers'));
  const s: Supplier = { id: uid(), name: i.name.trim(), phone: (i.phone ?? '').trim(), address: (i.address ?? '').trim(), notes: (i.notes ?? '').trim(), active: true, createdAt: now };
  await repo.putMany([{ s: 'suppliers', v: s }]);
  return s;
}
export async function updateSupplier(repo: Repo, id: string, i: SupplierInput): Promise<Supplier> {
  const old = await repo.get<Supplier>('suppliers', id);
  if (!old) return fail('Fournisseur introuvable.');
  checkSupplier(i, await repo.all<Supplier>('suppliers'), id);
  const s: Supplier = { ...old, name: i.name.trim(), phone: (i.phone ?? '').trim(), address: (i.address ?? '').trim(), notes: (i.notes ?? '').trim() };
  await repo.putMany([{ s: 'suppliers', v: s }]);
  return s;
}
/** « Supprimer » = archiver : les commandes passées gardent leur historique. */
async function setSupplierActive(repo: Repo, id: string, active: boolean): Promise<Supplier> {
  const old = await repo.get<Supplier>('suppliers', id);
  if (!old) return fail('Fournisseur introuvable.');
  const s = { ...old, active }; await repo.putMany([{ s: 'suppliers', v: s }]); return s;
}
export const archiveSupplier = (repo: Repo, id: string) => setSupplierActive(repo, id, false);
export const restoreSupplier = (repo: Repo, id: string) => setSupplierActive(repo, id, true);

// ---------- Commandes aux fournisseurs ----------
export interface OrderInput { supplierId: string; lines: { productId: string; qty: number; unitCost?: number }[]; note?: string }

export async function createOrder(repo: Repo, i: OrderInput, now = Date.now()): Promise<PurchaseOrder> {
  const sup = await repo.get<Supplier>('suppliers', i.supplierId);
  if (!sup || !sup.active) return fail('Choisis un fournisseur.');
  if (!i.lines.length) fail('Ajoute au moins un produit à la commande.');
  const products = new Map((await repo.all<Product>('products')).map((p) => [p.id, p]));
  const lines = i.lines.map((l) => {
    const p = products.get(l.productId);
    if (!p || !p.active) return fail('Produit introuvable ou supprimé.');
    if (!isInt(l.qty) || l.qty <= 0) fail('La quantité doit être un entier positif.');
    const unitCost = l.unitCost ?? p.costPrice;
    if (!isMoney(unitCost)) fail('Le prix d’achat doit être un montant entier en FCFA.');
    return { productId: p.id, name: p.name, qty: l.qty, unitCost };
  });
  const total = lines.reduce((t, l) => t + l.qty * l.unitCost, 0);
  const count = (await repo.all<PurchaseOrder>('orders')).length;
  const o: PurchaseOrder = { id: uid(), number: 'C-' + String(count + 1).padStart(5, '0'), at: now, supplierId: sup.id, supplierName: sup.name, lines, total, paid: 0, status: 'EN_COURS', note: (i.note ?? '').trim() || undefined };
  await repo.putMany([{ s: 'orders', v: o }]);
  return o;
}

/** Réception : le stock augmente d'un coup (tout ou rien) et la commande passe à « reçue ». */
export async function receiveOrder(repo: Repo, id: string, now = Date.now()): Promise<PurchaseOrder> {
  const o = await repo.get<PurchaseOrder>('orders', id);
  if (!o) return fail('Commande introuvable.');
  if (o.status !== 'EN_COURS') fail(o.status === 'RECUE' ? 'Cette commande est déjà reçue.' : 'Cette commande est annulée.');
  const touched = new Map<string, Product>(); const ops: Op[] = [];
  for (const l of o.lines) {
    const p = touched.get(l.productId) ?? (await repo.get<Product>('products', l.productId));
    if (!p) return fail(`Le produit « ${l.name} » n’existe plus.`);
    touched.set(p.id, { ...p, stock: p.stock + l.qty });
    ops.push({ s: 'moves', v: mv(p.id, 'ENTREE', l.qty, 'Réception commande ' + o.number, o.id, now) satisfies StockMove });
  }
  for (const p of touched.values()) ops.push({ s: 'products', v: p });
  const done: PurchaseOrder = { ...o, status: 'RECUE', receivedAt: now };
  ops.push({ s: 'orders', v: done });
  await repo.putMany(ops);
  return done;
}

/** Paiement au fournisseur (acompte ou solde) : crée la dépense « Marchandise » correspondante. */
export async function payOrder(repo: Repo, id: string, amount: number, method: PaymentMethod, now = Date.now()): Promise<PurchaseOrder> {
  const o = await repo.get<PurchaseOrder>('orders', id);
  if (!o) return fail('Commande introuvable.');
  if (o.status === 'ANNULEE') fail('Cette commande est annulée.');
  if (!isMoney(amount) || amount <= 0) fail('Le montant doit être un nombre entier positif.');
  if (!PAYMENT_METHODS.includes(method)) fail('Mode de paiement inconnu.');
  if (amount > o.total - o.paid) fail(o.total === o.paid ? 'Cette commande est déjà payée.' : `Il ne reste que ${fcfa(o.total - o.paid)} à payer.`);
  const e: Expense = { id: uid(), at: now, category: 'Marchandise', description: `Commande ${o.number} – ${o.supplierName}`, amount, method, supplierId: o.supplierId, orderId: o.id, status: 'VALIDEE' };
  const done: PurchaseOrder = { ...o, paid: o.paid + amount };
  await repo.putMany([{ s: 'expenses', v: e }, { s: 'orders', v: done }]);
  return done;
}
export async function cancelOrder(repo: Repo, id: string, now = Date.now()): Promise<PurchaseOrder> {
  const o = await repo.get<PurchaseOrder>('orders', id);
  if (!o) return fail('Commande introuvable.');
  if (o.status !== 'EN_COURS') fail(o.status === 'RECUE' ? 'Une commande reçue ne peut plus être annulée (le stock a augmenté).' : 'Cette commande est déjà annulée.');
  if (o.paid > 0) fail('Un paiement a déjà été fait pour cette commande : elle ne peut plus être annulée.');
  const done: PurchaseOrder = { ...o, status: 'ANNULEE', cancelledAt: now };
  await repo.putMany([{ s: 'orders', v: done }]);
  return done;
}
/** Ce que la boutique doit encore à un fournisseur (commandes reçues non soldées). */
export const supplierBalance = (orders: PurchaseOrder[], supplierId?: string) =>
  orders.filter((o) => o.status === 'RECUE' && (supplierId === undefined || o.supplierId === supplierId)).reduce((t, o) => t + (o.total - o.paid), 0);
