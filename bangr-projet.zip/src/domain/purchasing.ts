import type { Repo } from './repo.ts';
import type { ClientOrder, Customer, Expense, PaymentMethod, SupplierOrder } from './types.ts';
import { fail, uid } from './services.ts';
import { fcfa, isMoney } from './money.ts';
import { PAYMENT_METHODS } from './payments.ts';

// ---------- Dépenses ----------
export const EXPENSE_CATEGORIES = ['Marchandise', 'Loyer', 'Transport', 'Salaire', 'Électricité / Eau', 'Autre'] as const;
export interface ExpenseInput { description?: string; category: string; amount: number; method?: PaymentMethod; at?: number }

export async function createExpense(repo: Repo, i: ExpenseInput, now = Date.now()): Promise<Expense> {
  if (!(EXPENSE_CATEGORIES as readonly string[]).includes(i.category)) fail('Choisis une catégorie de dépense.');
  if (!isMoney(i.amount) || i.amount <= 0) fail('Le montant doit être un nombre entier positif (FCFA).');
  const method = i.method ?? 'ESPECES';
  if (!PAYMENT_METHODS.includes(method)) fail('Mode de paiement inconnu.');
  const description = (i.description ?? '').trim();
  if (description.length > 120) fail('La description est trop longue (120 caractères maximum).');
  const at = i.at ?? now;
  if (!Number.isFinite(at) || at > now + 86400000) fail('La date de la dépense est invalide.');
  const e: Expense = { id: uid(), at, category: i.category, description, amount: i.amount, method, status: 'VALIDEE' };
  await repo.putMany([{ s: 'expenses', v: e }]);
  return e;
}
export async function cancelExpense(repo: Repo, id: string, now = Date.now()): Promise<Expense> {
  const e = await repo.get<Expense>('expenses', id);
  if (!e) return fail('Dépense introuvable.');
  if (e.status === 'ANNULEE') fail('Cette dépense est déjà annulée.');
  if (e.orderId) fail('Ce paiement est lié à une commande fournisseur : supprime la commande pour l’enlever.');
  const done: Expense = { ...e, status: 'ANNULEE', cancelledAt: now };
  await repo.putMany([{ s: 'expenses', v: done }]);
  return done;
}
/** Date saisie (AAAA-MM-JJ) → horodatage : l'heure actuelle si c'est aujourd'hui, sinon midi. */
export function dateToMs(ymd: string, now = Date.now()): number {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd); if (!m) return now;
  const d = new Date(+m[1], +m[2] - 1, +m[3], 12); const n = new Date(now);
  return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate() ? now : d.getTime();
}

// ---------- Commandes fournisseur ----------
const text = (v: string | undefined, what: string, max: number) => { const t = (v ?? '').trim(); if (!t) fail(`${what} : champ obligatoire.`); if (t.length > max) fail(`${what} : ${max} caractères maximum.`); return t; };
const okDate = (d: number | undefined) => { if (d !== undefined && !Number.isFinite(d)) fail('La date est invalide.'); return d; };
export interface SupplierOrderInput { supplier: string; goods: string; total: number; paid?: number; dueDate?: number }

export async function createSupplierOrder(repo: Repo, i: SupplierOrderInput, now = Date.now()): Promise<SupplierOrder> {
  const supplier = text(i.supplier, 'Fournisseur', 80); const goods = text(i.goods, 'Marchandise commandée', 200);
  if (!isMoney(i.total) || i.total <= 0) fail('Le montant total doit être un nombre entier positif (FCFA).');
  const paid = i.paid ?? 0;
  if (!isMoney(paid) || paid > i.total) fail('Le montant déjà versé doit être compris entre 0 et le total.');
  const count = (await repo.all<SupplierOrder>('supplierOrders')).length;
  const o: SupplierOrder = { id: uid(), number: 'F-' + String(count + 1).padStart(5, '0'), at: now, supplier, goods, total: i.total, paid, dueDate: okDate(i.dueDate), status: 'EN_ATTENTE' };
  const ops: { s: 'supplierOrders' | 'expenses'; v: unknown }[] = [{ s: 'supplierOrders', v: o }];
  if (paid > 0) ops.push({ s: 'expenses', v: paymentExpense(o, paid, 'ESPECES', now) });
  await repo.putMany(ops);
  return o;
}
const paymentExpense = (o: SupplierOrder, amount: number, method: PaymentMethod, at: number): Expense =>
  ({ id: uid(), at, category: 'Marchandise', description: `Commande ${o.number} – ${o.supplier}`, amount, method, orderId: o.id, status: 'VALIDEE' });

/** Paiement au fournisseur (acompte ou solde) : crée aussi la dépense « Marchandise ». */
export async function paySupplierOrder(repo: Repo, id: string, amount: number, method: PaymentMethod, now = Date.now()): Promise<SupplierOrder> {
  const o = await repo.get<SupplierOrder>('supplierOrders', id);
  if (!o || o.deleted) return fail('Commande introuvable.');
  if (!isMoney(amount) || amount <= 0) fail('Le montant doit être un nombre entier positif.');
  if (!PAYMENT_METHODS.includes(method)) fail('Mode de paiement inconnu.');
  if (amount > o.total - o.paid) fail(o.total === o.paid ? 'Cette commande est déjà payée.' : `Il ne reste que ${fcfa(o.total - o.paid)} à payer.`);
  const done = { ...o, paid: o.paid + amount };
  await repo.putMany([{ s: 'expenses', v: paymentExpense(o, amount, method, now) }, { s: 'supplierOrders', v: done }]);
  return done;
}
export async function deliverSupplierOrder(repo: Repo, id: string, now = Date.now()): Promise<SupplierOrder> {
  const o = await repo.get<SupplierOrder>('supplierOrders', id);
  if (!o || o.deleted) return fail('Commande introuvable.');
  if (o.status === 'LIVREE') fail('Cette commande est déjà marquée comme reçue.');
  const done: SupplierOrder = { ...o, status: 'LIVREE', deliveredAt: now };
  await repo.putMany([{ s: 'supplierOrders', v: done }]);
  return done;
}
/** Supprime la commande de l'application ; les paiements qu'elle avait enregistrés sont retirés des dépenses. */
export async function deleteSupplierOrder(repo: Repo, id: string, now = Date.now()): Promise<void> {
  const o = await repo.get<SupplierOrder>('supplierOrders', id);
  if (!o || o.deleted) return fail('Commande introuvable.');
  const pays = (await repo.all<Expense>('expenses')).filter((e) => e.orderId === id && e.status === 'VALIDEE');
  await repo.putMany([{ s: 'supplierOrders', v: { ...o, deleted: true } }, ...pays.map((e) => ({ s: 'expenses' as const, v: { ...e, status: 'ANNULEE', cancelledAt: now } }))]);
}
/** Ce que la boutique doit encore à ses fournisseurs. */
export const supplierDebt = (orders: SupplierOrder[]) => orders.filter((o) => !o.deleted).reduce((t, o) => t + (o.total - o.paid), 0);

// ---------- Commandes clients ----------
export interface ClientOrderInput { customer: string; customerId?: string; item: string; total: number; advance?: number; dueDate?: number }

export async function createClientOrder(repo: Repo, i: ClientOrderInput, now = Date.now()): Promise<ClientOrder> {
  let customer = (i.customer ?? '').trim();
  if (i.customerId) { const c = await repo.get<Customer>('customers', i.customerId); if (c) customer = c.name; }
  customer = text(customer, 'Client', 80); const item = text(i.item, 'Article commandé', 200);
  if (!isMoney(i.total) || i.total <= 0) fail('Le prix total doit être un nombre entier positif (FCFA).');
  const advance = i.advance ?? 0;
  if (!isMoney(advance) || advance > i.total) fail('L’avance reçue doit être comprise entre 0 et le prix total.');
  const count = (await repo.all<ClientOrder>('clientOrders')).length;
  const o: ClientOrder = { id: uid(), number: 'K-' + String(count + 1).padStart(5, '0'), at: now, customer, customerId: i.customerId, item, total: i.total, advance, dueDate: okDate(i.dueDate), status: 'EN_ATTENTE' };
  await repo.putMany([{ s: 'clientOrders', v: o }]);
  return o;
}
/** Le client verse une nouvelle somme (avance supplémentaire ou solde). */
export async function collectClientOrder(repo: Repo, id: string, amount: number): Promise<ClientOrder> {
  const o = await repo.get<ClientOrder>('clientOrders', id);
  if (!o || o.deleted) return fail('Commande introuvable.');
  if (!isMoney(amount) || amount <= 0) fail('Le montant doit être un nombre entier positif.');
  if (amount > o.total - o.advance) fail(o.total === o.advance ? 'Cette commande est déjà payée.' : `Il ne reste que ${fcfa(o.total - o.advance)} à encaisser.`);
  const done = { ...o, advance: o.advance + amount };
  await repo.putMany([{ s: 'clientOrders', v: done }]);
  return done;
}
export async function deliverClientOrder(repo: Repo, id: string, now = Date.now()): Promise<ClientOrder> {
  const o = await repo.get<ClientOrder>('clientOrders', id);
  if (!o || o.deleted) return fail('Commande introuvable.');
  if (o.status === 'LIVREE') fail('Cette commande est déjà livrée.');
  const done: ClientOrder = { ...o, status: 'LIVREE', deliveredAt: now };
  await repo.putMany([{ s: 'clientOrders', v: done }]);
  return done;
}
export async function deleteClientOrder(repo: Repo, id: string): Promise<void> {
  const o = await repo.get<ClientOrder>('clientOrders', id);
  if (!o || o.deleted) return fail('Commande introuvable.');
  await repo.putMany([{ s: 'clientOrders', v: { ...o, deleted: true } }]);
}
/** Ce que les clients doivent encore sur leurs commandes. */
export const clientOrdersDue = (orders: ClientOrder[]) => orders.filter((o) => !o.deleted).reduce((t, o) => t + (o.total - o.advance), 0);

/** Jour saisi (AAAA-MM-JJ) → horodatage à midi ; undefined si vide ou invalide. */
export function dayMs(ymd: string): number | undefined {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd); return m ? new Date(+m[1], +m[2] - 1, +m[3], 12).getTime() : undefined;
}
