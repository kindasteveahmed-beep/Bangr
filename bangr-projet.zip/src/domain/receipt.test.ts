import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatReceiptText, fmtDate, EMPTY_HEADER } from './receipt.ts';
import { loadHeader, saveHeader } from '../data/settings.ts';
import type { Sale } from './types.ts';

const T = new Date(2026, 9, 24, 10, 5).getTime();
const sale = (o: Partial<Sale> = {}): Sale => ({ id: 'a', number: 'V-00001', at: T, lines: [{ productId: 'p', name: 'Pagne wax', qty: 3, unitPrice: 3000, unitCost: 2000 }], total: 9000, paid: 9000, customerName: '', status: 'VALIDEE', ...o });
const H = { shop: 'Boutique Yaaba', address: 'Marché central, Ouagadougou', phone: '70 00 00 00', extra: 'IFU 0012345A', footer: 'Merci de votre visite !' };

test('reçu complet : en-tête, lignes, totaux, pied de page', () => {
  const t = formatReceiptText(sale(), H);
  for (const s of ['BOUTIQUE YAABA', 'Marché central', 'Tél : 70 00 00 00', 'IFU 0012345A', 'REÇU N° V-00001', '24/10/2026 10:05', 'Pagne wax', '3 x 3 000 FCFA', 'TOTAL', '9 000 FCFA', 'Merci de votre visite !']) assert.ok(t.includes(s), s);
  assert.ok(!t.includes('Reste à payer'));
});
test('en-tête vide : rien d’inventé', () => {
  const t = formatReceiptText(sale(), EMPTY_HEADER);
  assert.ok(t.startsWith('REÇU N° V-00001'));
  assert.ok(!t.includes('Tél'));
});
test('crédit : client et reste à payer', () => {
  const t = formatReceiptText(sale({ paid: 5000, customerName: 'Awa' }), H);
  assert.ok(t.includes('Client : Awa')); assert.ok(t.includes('Reste à payer')); assert.ok(t.includes('4 000 FCFA'));
});
test('vente annulée signalée', () => assert.ok(formatReceiptText(sale({ status: 'ANNULEE' }), H).includes('VENTE ANNULÉE')));
test('aucune ligne ne dépasse la largeur, même avec de longs noms', () => {
  const s = sale({ lines: [{ productId: 'p', name: 'Ensemble complet bazin riche brodé main taille XL couleur bleu nuit', qty: 12, unitPrice: 125000, unitCost: 1 }, { productId: 'q', name: 'Anticonstitutionnellement-long-mot-sans-espace', qty: 1, unitPrice: 5, unitCost: 1 }], total: 1500005, paid: 1500005 });
  for (const w of [32, 42]) for (const l of formatReceiptText(s, { ...H, shop: 'Grande quincaillerie générale du centre-ville' }, w).split('\n')) assert.ok(l.length <= w, `${w}: "${l}"`);
});
test('date au format jj/mm/aaaa hh:mm', () => assert.equal(fmtDate(T), '24/10/2026 10:05'));
test('en-tête : enregistrement, relecture, données abîmées', () => {
  const m = new Map<string, string>(); const kv = { get: (k: string) => m.get(k) ?? null, set: (k: string, v: string) => void m.set(k, v) };
  assert.deepEqual(loadHeader(kv), EMPTY_HEADER);
  saveHeader(kv, H); assert.deepEqual(loadHeader(kv), H);
  m.set('bangr_receipt', '{pas du json'); assert.deepEqual(loadHeader(kv), EMPTY_HEADER);
});
