import type { Sale } from './types.ts';
import { fcfa } from './money.ts';
import { PAYMENT_LABEL, paymentsOf } from './payments.ts';

export interface ReceiptHeader { shop: string; address: string; phone: string; extra: string; footer: string }
export const EMPTY_HEADER: ReceiptHeader = { shop: '', address: '', phone: '', extra: '', footer: '' };

const pad2 = (n: number) => String(n).padStart(2, '0');
export const fmtDate = (ms: number) => { const d = new Date(ms); return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };

function wrap(s: string, w: number): string[] {
  const out: string[] = []; let cur = '';
  for (let word of s.trim().split(/\s+/).filter(Boolean)) {
    while (word.length > w) { if (cur) { out.push(cur); cur = ''; } out.push(word.slice(0, w)); word = word.slice(w); }
    if (!cur) cur = word; else if (cur.length + 1 + word.length <= w) cur += ' ' + word; else { out.push(cur); cur = word; }
  }
  if (cur) out.push(cur);
  return out;
}
const center = (s: string, w: number) => wrap(s, w).map((l) => ' '.repeat(Math.floor((w - l.length) / 2)) + l);
function row(left: string, right: string, w: number): string[] {
  if (left.length + right.length + 1 <= w) return [left + ' '.repeat(w - left.length - right.length) + right];
  return [...wrap(left, w), ' '.repeat(Math.max(0, w - right.length)) + right];
}

// Reçu en texte brut à largeur fixe (ticket de caisse) : même rendu pour l'écran, l'impression, la copie et WhatsApp.
export function formatReceiptText(sale: Sale, h: ReceiptHeader, width = 32): string {
  const w = width; const line = '-'.repeat(w); const L: string[] = [];
  if (h.shop.trim()) L.push(...center(h.shop.toUpperCase(), w));
  if (h.address.trim()) L.push(...center(h.address, w));
  if (h.phone.trim()) L.push(...center('Tél : ' + h.phone.trim(), w));
  if (h.extra.trim()) L.push(...center(h.extra, w));
  if (L.length) L.push(line);
  L.push(`REÇU N° ${sale.number}`, 'Date : ' + fmtDate(sale.at));
  if (sale.customerName) L.push(...wrap('Client : ' + sale.customerName, w));
  L.push(line);
  for (const l of sale.lines) {
    L.push(...wrap(l.name, w));
    L.push(...row(`  ${l.qty} x ${fcfa(l.unitPrice)}`, fcfa(l.qty * l.unitPrice), w));
  }
  L.push(line, ...row('TOTAL', fcfa(sale.total), w));
  const pays = paymentsOf(sale);
  if (!pays.length) L.push(...row('Payé', fcfa(0), w));
  for (const p of pays) L.push(...row(p.method === 'INCONNU' ? 'Payé' : 'Payé - ' + PAYMENT_LABEL[p.method], fcfa(p.amount), w));
  if (sale.total > sale.paid) L.push(...row('Reste à payer', fcfa(sale.total - sale.paid), w));
  if (sale.status === 'ANNULEE') L.push(line, ...center('*** VENTE ANNULÉE ***', w));
  if (h.footer.trim()) L.push(line, ...center(h.footer, w));
  return L.join('\n');
}
