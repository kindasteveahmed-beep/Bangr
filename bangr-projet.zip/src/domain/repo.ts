// Couche de stockage abstraite : l'interface et la logique métier ne connaissent que ce contrat.
export type StoreName = 'products' | 'moves' | 'sales' | 'customers';
export const STORE_NAMES: StoreName[] = ['products', 'moves', 'sales', 'customers'];
export interface Op { s: StoreName; v: unknown }
export interface Repo {
  all<T>(s: StoreName): Promise<T[]>;
  get<T>(s: StoreName, id: string): Promise<T | undefined>;
  putMany(ops: Op[]): Promise<void>; // atomique : tout ou rien. Estampille chaque enregistrement (u) et le met en file d'envoi.
}
// Contrat supplémentaire pour la synchronisation en ligne.
export interface SyncRepo extends Repo {
  outbox(): Promise<string[]>; // enregistrements modifiés localement, "store:id"
  clearOutbox(keys: string[]): Promise<void>;
  markAllDirty(): Promise<void>; // tout renvoyer (à la première connexion)
  putRemote(ops: Op[]): Promise<void>; // écrit tel quel (reçu du cloud), sans estampille ni file d'envoi
}
export class MemoryRepo implements SyncRepo {
  private d: Record<StoreName, Map<string, any>> = { products: new Map(), moves: new Map(), sales: new Map(), customers: new Map() };
  private box = new Set<string>();
  private now: () => number;
  constructor(now: () => number = Date.now) { this.now = now; }
  async all<T>(s: StoreName) { return [...this.d[s].values()].map((x) => structuredClone(x)) as T[]; }
  async get<T>(s: StoreName, id: string) { const x = this.d[s].get(id); return x === undefined ? undefined : (structuredClone(x) as T); }
  async putMany(ops: Op[]) {
    const t = this.now();
    const c = ops.map((o) => ({ s: o.s, v: { ...(structuredClone(o.v) as any), u: t } }));
    for (const o of c) { this.d[o.s].set(o.v.id, o.v); this.box.add(o.s + ':' + o.v.id); }
  }
  async putRemote(ops: Op[]) { for (const o of ops) { const v = structuredClone(o.v) as any; this.d[o.s].set(v.id, v); } }
  async outbox() { return [...this.box]; }
  async clearOutbox(keys: string[]) { for (const k of keys) this.box.delete(k); }
  async markAllDirty() { for (const s of STORE_NAMES) for (const id of this.d[s].keys()) this.box.add(s + ':' + id); }
}
