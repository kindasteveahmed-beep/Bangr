// Couche de stockage abstraite : l'interface et la logique métier ne connaissent que ce contrat.
// Une synchronisation distante pourra plus tard être ajoutée en fournissant une autre implémentation.
export type StoreName = 'products' | 'moves' | 'sales';
export interface Op { s: StoreName; v: unknown }
export interface Repo {
  all<T>(s: StoreName): Promise<T[]>;
  get<T>(s: StoreName, id: string): Promise<T | undefined>;
  putMany(ops: Op[]): Promise<void>; // atomique : tout ou rien
}
export class MemoryRepo implements Repo {
  private d: Record<StoreName, Map<string, any>> = { products: new Map(), moves: new Map(), sales: new Map() };
  async all<T>(s: StoreName) { return [...this.d[s].values()].map((x) => structuredClone(x)) as T[]; }
  async get<T>(s: StoreName, id: string) { const x = this.d[s].get(id); return x === undefined ? undefined : (structuredClone(x) as T); }
  async putMany(ops: Op[]) { const c = ops.map((o) => ({ s: o.s, v: structuredClone(o.v) as any })); for (const o of c) this.d[o.s].set(o.v.id, o.v); }
}
