import type { Repo, Op } from './repo.ts';
import type { Product, Sale, StockMove, MoveType, Customer, Payment, PaymentMethod } from './types.ts';
import { isMoney, fcfa } from './money.ts';
import { PAYMENT_METHODS, paymentsOf } from './payments.ts';

export class DomainError extends Error {}
export const fail = (m: string): never => { throw new DomainError(m); };
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
export const isInt = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n);
export const mv = (productId: string, type: MoveType, qty: number, reason: string | undefined, ref: string | undefined, at: number): StockMove => ({ id: uid(), productId, type, qty, reason, ref, at });

export interface ProductInput { name: string; category?: string; unit?: string; costPrice: number; salePrice: number; minStock?: number; stock?: number }

function checkProduct(i: ProductInput) {
  if (!i.name.trim()) fail('Le nom du produit est obligatoire.');
  if (!isMoney(i.costPrice) || !isMoney(i.salePrice)) fail('Les prix doivent être des montants entiers en FCFA.');
  if (i.minStock !== undefined && !(isInt(i.minStock) && i.minStock >= 0)) fail('Le seuil d’alerte est invalide.');
}

export async function createProduct(repo: Repo, i: ProductInput, now = Date.now()): Promise<Product> {
  checkProduct(i);
  const stock = i.stock ?? 0;
  if (!isInt(stock) || stock < 0) fail('La quantité en stock est invalide.');
  const p: Product = { id: uid(), name: i.name.trim(), category: (i.category ?? '').trim(), unit: (i.unit ?? '').trim() || 'pièce', costPrice: i.costPrice, salePrice: i.salePrice, minStock: i.minStock ?? 0, stock, active: true, createdAt: now };
  const ops: Op[] = [{ s: 'products', v: p }];
  if (stock > 0) ops.push({ s: 'moves', v: mv(p.id, 'ENTREE', stock, 'Stock initial', undefined, now) });
  await repo.putMany(ops);
  return p;
}

// Modifier le prix d'achat n'affecte jamais les ventes passées (coût figé dans chaque ligne de vente).
export async function updateProduct(repo: Repo, id: string, patch: Partial<ProductInput> & { active?: boolean }): Promise<Product> {
  const old = await repo.get<Product>('products', id);
  if (!old) return fail('Produit introuvable.');
  const next = { ...old, ...patch, name: (patch.name ?? old.name).trim() };
  checkProduct({ name: next.name, costPrice: next.costPrice, salePrice: next.salePrice, minStock: next.minStock });
  const saved = { ...next, stock: old.stock };
  await repo.putMany([{ s: 'products', v: saved }]);
  return saved;
}

// « Supprimer » un produit = l'archiver : il disparaît des listes, des ventes et des chiffres, mais l'historique (ventes passées, mouvements) reste exact.
export const archiveProduct = (repo: Repo, id: string) => updateProduct(repo, id, { active: false });
export const restoreProduct = (repo: Repo, id: string) => updateProduct(repo, id, { active: true });

export async function adjustStock(repo: Repo, productId: string, type: 'ENTREE' | 'SORTIE' | 'AJUSTEMENT', delta: number, reason: string, now = Date.now()): Promise<Product> {
  const p = await repo.get<Product>('products', productId);
  if (!p) return fail('Produit introuvable.');
  if (!isInt(delta) || delta === 0) fail('La quantité doit être un nombre entier non nul.');
  if (type === 'ENTREE' && delta < 0) fail('Une entrée doit être positive.');
  if (type === 'SORTIE' && delta > 0) fail('Une sortie doit être négative.');
  if (p.stock + delta < 0) fail(`Stock insuffisant : il reste ${p.stock} ${p.unit}.`);
  const up = { ...p, stock: p.stock + delta };
  await repo.putMany([{ s: 'products', v: up }, { s: 'moves', v: mv(p.id, type, delta, reason.trim() || undefined, undefined, now) }]);
  return up;
}

export interface SaleInput { lines: { productId: string; qty: number; unitPrice?: number }[]; paid: number; customerName?: string; customerId?: string; method?: PaymentMethod }

export async function recordSale(repo: Repo, input: SaleInput, now = Date.now()): Promise<Sale> {
  if (!input.lines.length) fail('Ajoute au moins un produit à la vente.');
  const products = new Map((await repo.all<Product>('products')).map((p) => [p.id, p]));
  const left = new Map<string, number>();
  const lines = input.lines.map((l) => {
    const p = products.get(l.productId);
    if (!p || !p.active) return fail('Produit introuvable ou archivé.');
    if (!isInt(l.qty) || l.qty <= 0) fail('La quantité doit être un entier positif.');
    const unitPrice = l.unitPrice ?? p.salePrice;
    if (!isMoney(unitPrice)) fail('Prix de vente invalide.');
    const rest = (left.get(p.id) ?? p.stock) - l.qty;
    if (rest < 0) fail(`Stock insuffisant pour « ${p.name} » : il reste ${p.stock} ${p.unit}.`);
    left.set(p.id, rest);
    return { productId: p.id, name: p.name, qty: l.qty, unitPrice, unitCost: p.costPrice };
  });
  const total = lines.reduce((t, l) => t + l.qty * l.unitPrice, 0);
  if (!isMoney(input.paid) || input.paid > total) fail('Le montant payé doit être compris entre 0 et le total.');
  const method = input.method ?? 'ESPECES';
  if (!PAYMENT_METHODS.includes(method)) fail('Mode de paiement inconnu.');
  let customerName = (input.customerName ?? '').trim();
  if (input.customerId) { const c = await repo.get<Customer>('customers', input.customerId); if (!c) return fail('Client introuvable.'); customerName = c.name; }
  if (input.paid < total && !customerName) fail('Pour une vente à crédit ou un paiement partiel, choisis ou crée un client.');
  const count = (await repo.all<Sale>('sales')).length;
  const sale: Sale = { id: uid(), number: 'V-' + String(count + 1).padStart(5, '0'), at: now, lines, total, paid: input.paid, customerName, customerId: input.customerId, payments: input.paid > 0 ? [{ method, amount: input.paid, at: now }] : [], status: 'VALIDEE' };
  const ops: Op[] = [{ s: 'sales', v: sale }];
  for (const [pid, rest] of left) ops.push({ s: 'products', v: { ...products.get(pid)!, stock: rest } });
  for (const l of lines) ops.push({ s: 'moves', v: mv(l.productId, 'VENTE', -l.qty, undefined, sale.id, now) });
  await repo.putMany(ops);
  return sale;
}

export async function cancelSale(repo: Repo, saleId: string, reason: string, now = Date.now()): Promise<Sale> {
  const sale = await repo.get<Sale>('sales', saleId);
  if (!sale) return fail('Vente introuvable.');
  if (sale.status === 'ANNULEE') fail('Cette vente est déjà annulée.');
  const ops: Op[] = [];
  const touched = new Map<string, Product>();
  for (const l of sale.lines) {
    const p = touched.get(l.productId) ?? (await repo.get<Product>('products', l.productId));
    if (!p) continue;
    p.stock += l.qty; touched.set(p.id, p);
    ops.push({ s: 'moves', v: mv(l.productId, 'ANNULATION_VENTE', l.qty, reason.trim() || undefined, sale.id, now) });
  }
  for (const p of touched.values()) ops.push({ s: 'products', v: p });
  const done: Sale = { ...sale, status: 'ANNULEE', cancelledAt: now, cancelReason: reason.trim() || undefined };
  ops.push({ s: 'sales', v: done });
  await repo.putMany(ops);
  return done;
}

// ---------- Clients ----------
export interface CustomerInput { name: string; phone?: string; address?: string; notes?: string }
const normPhone = (p: string) => p.replace(/[\s.-]/g, '');

function checkCustomer(i: CustomerInput, others: Customer[], selfId?: string) {
  if (!i.name.trim()) fail('Le nom du client est obligatoire.');
  const phone = normPhone(i.phone ?? '');
  if (phone && !/^\+?[0-9]{8,15}$/.test(phone)) fail('Numéro de téléphone invalide (8 à 15 chiffres).');
  if (phone && others.some((c) => c.id !== selfId && normPhone(c.phone) === phone)) fail('Un client avec ce numéro existe déjà.');
}
export async function createCustomer(repo: Repo, i: CustomerInput, now = Date.now()): Promise<Customer> {
  checkCustomer(i, await repo.all<Customer>('customers'));
  const c: Customer = { id: uid(), name: i.name.trim(), phone: (i.phone ?? '').trim(), address: (i.address ?? '').trim(), notes: (i.notes ?? '').trim(), createdAt: now };
  await repo.putMany([{ s: 'customers', v: c }]);
  return c;
}
export async function updateCustomer(repo: Repo, id: string, i: CustomerInput): Promise<Customer> {
  const old = await repo.get<Customer>('customers', id);
  if (!old) return fail('Client introuvable.');
  checkCustomer(i, await repo.all<Customer>('customers'), id);
  const c: Customer = { ...old, name: i.name.trim(), phone: (i.phone ?? '').trim(), address: (i.address ?? '').trim(), notes: (i.notes ?? '').trim() };
  await repo.putMany([{ s: 'customers', v: c }]);
  return c;
}
/** Somme que le client doit encore (ventes non annulées). */
export const customerBalance = (sales: Sale[], customerId: string) =>
  sales.filter((s) => s.customerId === customerId && s.status === 'VALIDEE').reduce((t, s) => t + (s.total - s.paid), 0);

/** Remboursement d'un crédit : réparti sur les plus anciennes dettes d'abord. */
export async function recordDebtPayment(repo: Repo, customerId: string, amount: number, method: PaymentMethod, now = Date.now()): Promise<Sale[]> {
  const c = await repo.get<Customer>('customers', customerId);
  if (!c) return fail('Client introuvable.');
  if (!isMoney(amount) || amount <= 0) fail('Le montant doit être un nombre entier positif.');
  if (!PAYMENT_METHODS.includes(method)) fail('Mode de paiement inconnu.');
  const open = (await repo.all<Sale>('sales')).filter((s) => s.customerId === customerId && s.status === 'VALIDEE' && s.total > s.paid).sort((a, b) => a.at - b.at);
  const owed = open.reduce((t, s) => t + (s.total - s.paid), 0);
  if (amount > owed) fail(`Ce client ne doit que ${fcfa(owed)}.`);
  let left = amount; const done: Sale[] = [];
  for (const s of open) {
    if (left <= 0) break;
    const pay = Math.min(left, s.total - s.paid); left -= pay;
    const payments: Payment[] = [...paymentsOf(s), { method, amount: pay, at: now }];
    done.push({ ...s, paid: s.paid + pay, payments });
  }
  await repo.putMany(done.map((v) => ({ s: 'sales' as const, v })));
  return done;
}
