import type { Product, Sale } from './types.ts';

const margin = (s: Sale) => s.lines.reduce((t, l) => t + l.qty * (l.unitPrice - l.unitCost), 0);
function sum(sales: Sale[]) {
  return { count: sales.length, revenue: sales.reduce((t, s) => t + s.total, 0), margin: sales.reduce((t, s) => t + margin(s), 0), cashIn: sales.reduce((t, s) => t + s.paid, 0) };
}
export function computeStats(d: { products: Product[]; sales: Sale[] }, now: number) {
  const day = new Date(now); day.setHours(0, 0, 0, 0);
  const dayStart = day.getTime();
  const monthStart = new Date(day.getFullYear(), day.getMonth(), 1).getTime();
  const valid = d.sales.filter((s) => s.status === 'VALIDEE');
  const active = d.products.filter((p) => p.active);
  return {
    day: sum(valid.filter((s) => s.at >= dayStart && s.at < dayStart + 86400000)),
    month: sum(valid.filter((s) => s.at >= monthStart)),
    receivables: valid.reduce((t, s) => t + (s.total - s.paid), 0), // créances clients en cours
    stockValue: active.reduce((t, p) => t + p.stock * p.costPrice, 0), // au prix d'achat
    lowStock: active.filter((p) => p.stock <= p.minStock),
  };
}
