import type { Expense, Product, Sale, SupplierOrder } from './types.ts';
import { paymentsOf } from './payments.ts';

const margin = (s: Sale) => s.lines.reduce((t, l) => t + l.qty * (l.unitPrice - l.unitCost), 0);

// Les ventes comptent à la date de la vente ; l'argent encaissé compte à la date de chaque paiement
// (un crédit remboursé plus tard est encaissé le jour du remboursement), avec le détail par mode de paiement.
function range(valid: Sale[], from: number, to: number, exp: Expense[] = []) {
  const ex = exp.filter((e) => e.at >= from && e.at < to);
  const expenses = ex.reduce((t, e) => t + e.amount, 0);
  // La « Marchandise » est déjà comptée dans la marge (prix d'achat de chaque vente) : on ne la retranche pas deux fois.
  const opExpenses = ex.filter((e) => e.category !== 'Marchandise').reduce((t, e) => t + e.amount, 0);
  const sales = valid.filter((s) => s.at >= from && s.at < to);
  const byMethod: Record<string, number> = {}; let cashIn = 0;
  for (const s of valid) for (const p of paymentsOf(s)) if (p.at >= from && p.at < to) { cashIn += p.amount; byMethod[p.method] = (byMethod[p.method] ?? 0) + p.amount; }
  const mg = sales.reduce((t, x) => t + margin(x), 0);
  return { expenses, opExpenses, profit: mg - opExpenses, count: sales.length, revenue: sales.reduce((t, s) => t + s.total, 0), margin: sales.reduce((t, s) => t + margin(s), 0), cashIn, byMethod };
}
export function computeStats(d: { products: Product[]; sales: Sale[]; expenses?: Expense[]; supplierOrders?: SupplierOrder[] }, now: number) {
  const day = new Date(now); day.setHours(0, 0, 0, 0);
  const dayStart = day.getTime();
  const monthStart = new Date(day.getFullYear(), day.getMonth(), 1).getTime();
  const valid = d.sales.filter((s) => s.status === 'VALIDEE');
  const exp = (d.expenses ?? []).filter((e) => e.status === 'VALIDEE');
  const active = d.products.filter((p) => p.active);
  return {
    day: range(valid, dayStart, dayStart + 86400000, exp),
    month: range(valid, monthStart, now + 86400000, exp),
    receivables: valid.reduce((t, s) => t + (s.total - s.paid), 0), // crédits clients en cours
    payables: (d.supplierOrders ?? []).filter((o) => !o.deleted).reduce((t, o) => t + (o.total - o.paid), 0), // dettes envers les fournisseurs
    stockValue: active.reduce((t, p) => t + p.stock * p.costPrice, 0), // au prix d'achat
    lowStock: active.filter((p) => p.stock <= p.minStock),
  };
}
