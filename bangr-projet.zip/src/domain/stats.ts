import type { Product, Sale } from './types.ts';
import { paymentsOf } from './payments.ts';

const margin = (s: Sale) => s.lines.reduce((t, l) => t + l.qty * (l.unitPrice - l.unitCost), 0);

// Les ventes comptent à la date de la vente ; l'argent encaissé compte à la date de chaque paiement
// (un crédit remboursé plus tard est encaissé le jour du remboursement), avec le détail par mode de paiement.
function range(valid: Sale[], from: number, to: number) {
  const sales = valid.filter((s) => s.at >= from && s.at < to);
  const byMethod: Record<string, number> = {}; let cashIn = 0;
  for (const s of valid) for (const p of paymentsOf(s)) if (p.at >= from && p.at < to) { cashIn += p.amount; byMethod[p.method] = (byMethod[p.method] ?? 0) + p.amount; }
  return { count: sales.length, revenue: sales.reduce((t, s) => t + s.total, 0), margin: sales.reduce((t, s) => t + margin(s), 0), cashIn, byMethod };
}
export function computeStats(d: { products: Product[]; sales: Sale[] }, now: number) {
  const day = new Date(now); day.setHours(0, 0, 0, 0);
  const dayStart = day.getTime();
  const monthStart = new Date(day.getFullYear(), day.getMonth(), 1).getTime();
  const valid = d.sales.filter((s) => s.status === 'VALIDEE');
  const active = d.products.filter((p) => p.active);
  return {
    day: range(valid, dayStart, dayStart + 86400000),
    month: range(valid, monthStart, now + 86400000),
    receivables: valid.reduce((t, s) => t + (s.total - s.paid), 0), // crédits clients en cours
    stockValue: active.reduce((t, p) => t + p.stock * p.costPrice, 0), // au prix d'achat
    lowStock: active.filter((p) => p.stock <= p.minStock),
  };
}
