import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildTicket } from './ticket.ts';
import { CODE39_PATTERNS, code39Bars } from './code39.ts';
import { makeImagePdf } from './pdf.ts';
import type { Sale } from './types.ts';

const T = new Date(2026, 9, 24, 10, 5).getTime();
const sale = (o: Partial<Sale> = {}): Sale => ({ id: 'a', number: 'V-00007', at: T, lines: [{ productId: 'p', name: 'Pagne wax', qty: 3, unitPrice: 3000, unitCost: 2000 }, { productId: 'q', name: 'Foulard', qty: 1, unitPrice: 1500, unitCost: 1 }], total: 10500, paid: 5000, customerName: 'Awa', payments: [{ method: 'ORANGE_MONEY', amount: 5000, at: T }], status: 'VALIDEE', ...o });
const H = { shop: 'Boutique Yaaba', address: 'Marché central', phone: '70 00 00 00', extra: '', footer: '' };

test('ticket : en-tête, numéro, code-barres, articles, total, paiement, reste, merci', () => {
  const t = buildTicket(sale(), H);
  const kinds = t.map((i) => i.k);
  assert.ok(kinds.includes('barcode') && kinds.includes('dash') && kinds.includes('line'));
  const all = JSON.stringify(t);
  for (const s of ['BOUTIQUE YAABA', 'Tél : 70 00 00 00', 'REÇU N° V-00007', '24/10/2026 10:05', 'Client : Awa', '1. Pagne wax', '3 x 3 000 FCFA', '9 000 FCFA', 'TOTAL', '10 500 FCFA', 'Payé - Orange Money', 'Reste à payer', '5 500 FCFA', 'Merci de votre visite !']) assert.ok(all.includes(s), s);
  assert.equal((t.find((i) => i.k === 'line' && i.name.includes('Foulard')) as { detail?: string }).detail, undefined); // qté 1 : pas de détail
});
test('ticket : vente annulée, soldée, sans en-tête', () => {
  assert.ok(buildTicket(sale({ status: 'ANNULEE' }), H).some((i) => i.k === 'stamp'));
  const paid = buildTicket(sale({ paid: 10500, payments: [{ method: 'ESPECES', amount: 10500, at: T }] }), { ...H, shop: '', address: '', phone: '' });
  assert.ok(!JSON.stringify(paid).includes('Reste à payer')); assert.equal(paid[0].k, 'title'); assert.ok(JSON.stringify(paid[0]).includes('REÇU'));
});
test('Code 39 : 44 motifs uniques à 3 traits larges, départ/arrêt *', () => {
  const pats = Object.values(CODE39_PATTERNS); assert.equal(new Set(pats).size, pats.length);
  for (const p of pats) { assert.equal(p.length, 9); assert.equal([...p].filter((c) => c === 'w').length, 3); }
  const bars = code39Bars('V-00007'); // 9 segments par caractère, 9 caractères, 8 espaces
  assert.equal(bars.length, 9 * 9 + 8); assert.ok(bars[0].bar && bars[bars.length - 1].bar);
  assert.deepEqual(code39Bars('v-00007'), bars); // minuscules acceptées
});
test('PDF image : structure valide et références exactes', () => {
  const jpeg = Uint8Array.from([0xff, 0xd8, 1, 2, 3, 0xff, 0xd9]);
  const b = makeImagePdf(jpeg, 960, 1500); const s = String.fromCharCode(...b);
  assert.ok(s.startsWith('%PDF-1.4')); assert.ok(s.trimEnd().endsWith('%%EOF'));
  const start = Number(/startxref\n(\d+)/.exec(s)![1]); assert.ok(s.slice(start).startsWith('xref'));
  const offs = [...s.slice(start).matchAll(/^(\d{10}) 00000 n $/gm)].map((m) => Number(m[1])); assert.equal(offs.length, 5);
  offs.forEach((o, i) => assert.ok(s.slice(o).startsWith(`${i + 1} 0 obj`), 'objet ' + (i + 1)));
  assert.ok(s.includes('/DCTDecode') && s.includes('/Length 7')); assert.ok(s.includes('MediaBox [0 0 226.77 '));
});
