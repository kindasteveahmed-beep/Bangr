import type { Customer, Sale } from './types.ts';
import type { ReceiptHeader } from './receipt.ts';
import { fmtDate } from './receipt.ts';
import { fcfa } from './money.ts';
import { PAYMENT_LABEL, paymentsOf } from './payments.ts';

/** Éléments d'un ticket de caisse : décrits une seule fois, puis dessinés à l'écran, en PDF, en image ou à l'impression. */
export type TicketItem =
  | { k: 'title'; text: string }
  | { k: 'center'; text: string; small?: boolean; bold?: boolean }
  | { k: 'dash' }
  | { k: 'gap'; h: number }
  | { k: 'row'; l: string; r: string; bold?: boolean; big?: boolean }
  | { k: 'line'; name: string; detail?: string; amount: string }
  | { k: 'barcode'; code: string }
  | { k: 'stamp'; text: string };

export function buildTicket(sale: Sale, h: ReceiptHeader, customer?: Customer): TicketItem[] {
  const T: TicketItem[] = [];
  if (h.shop.trim()) T.push({ k: 'title', text: h.shop.trim().toUpperCase() });
  for (const s of [h.address, h.phone.trim() && 'Tél : ' + h.phone.trim(), h.extra]) if (s && s.trim()) T.push({ k: 'center', text: s.trim(), small: true });
  if (T.length) T.push({ k: 'dash' });
  T.push({ k: 'title', text: 'REÇU N° ' + sale.number }, { k: 'center', text: fmtDate(sale.at), small: true });
  const client = sale.customerName || customer?.name;
  if (client) T.push({ k: 'center', text: 'Client : ' + client, small: true });
  T.push({ k: 'dash' }, { k: 'barcode', code: sale.number }, { k: 'dash' }, { k: 'gap', h: 4 });
  sale.lines.forEach((l, i) => T.push({ k: 'line', name: `${i + 1}. ${l.name}`, detail: l.qty === 1 ? undefined : `${l.qty} x ${fcfa(l.unitPrice)}`, amount: fcfa(l.qty * l.unitPrice) }));
  T.push({ k: 'gap', h: 6 }, { k: 'row', l: 'TOTAL', r: fcfa(sale.total), bold: true, big: true });
  const pays = paymentsOf(sale);
  for (const p of pays) T.push({ k: 'row', l: p.method === 'INCONNU' ? 'Payé' : 'Payé - ' + PAYMENT_LABEL[p.method], r: fcfa(p.amount) });
  if (!pays.length) T.push({ k: 'row', l: 'Payé', r: fcfa(0) });
  if (sale.total > sale.paid) T.push({ k: 'row', l: 'Reste à payer', r: fcfa(sale.total - sale.paid), bold: true });
  if (sale.status === 'ANNULEE') T.push({ k: 'gap', h: 4 }, { k: 'stamp', text: 'VENTE ANNULÉE' });
  T.push({ k: 'gap', h: 4 }, { k: 'dash' }, { k: 'gap', h: 4 }, { k: 'center', text: h.footer.trim() || 'Merci de votre visite !', bold: true }, { k: 'gap', h: 4 });
  return T;
}
