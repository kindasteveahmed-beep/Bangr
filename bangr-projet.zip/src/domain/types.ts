// Tous les montants sont des entiers en FCFA (XOF) : pas de décimales.
export interface Product { id: string; name: string; category: string; unit: string; costPrice: number; salePrice: number; minStock: number; stock: number; active: boolean; createdAt: number; u?: number }
export type MoveType = 'ENTREE' | 'SORTIE' | 'AJUSTEMENT' | 'VENTE' | 'ANNULATION_VENTE';
// qty est signée : + entrée en stock, − sortie.
export interface StockMove { id: string; productId: string; type: MoveType; qty: number; reason?: string; ref?: string; at: number; u?: number }
// unitCost est figé au moment de la vente : la marge historique ne change jamais.
export interface SaleLine { productId: string; name: string; qty: number; unitPrice: number; unitCost: number }
export interface Sale { id: string; number: string; at: number; lines: SaleLine[]; total: number; paid: number; customerName: string; status: 'VALIDEE' | 'ANNULEE'; cancelledAt?: number; cancelReason?: string; u?: number }
