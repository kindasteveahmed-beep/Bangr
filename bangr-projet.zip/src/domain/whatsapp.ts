export const DEFAULT_COUNTRY_CODE = '226'; // Burkina Faso
/** Numéro au format international pour WhatsApp (sans + ni espaces), ou null s'il est inutilisable. */
export function whatsappNumber(phone: string, cc = DEFAULT_COUNTRY_CODE): string | null {
  let d = phone.replace(/[^\d+]/g, ''); if (!d) return null;
  let intl = false;
  if (d.startsWith('+')) { d = d.slice(1); intl = true; } else if (d.startsWith('00')) { d = d.slice(2); intl = true; }
  d = d.replace(/\D/g, '');
  if (intl) return d.length >= 8 && d.length <= 15 ? d : null;
  if (d.length === 8) return cc + d; // numéro local à 8 chiffres
  return d.length >= 10 && d.length <= 15 ? d : null;
}
export function whatsappLink(phone: string | undefined, text: string): string {
  const n = phone ? whatsappNumber(phone) : null;
  return `https://wa.me/${n ?? ''}?text=${encodeURIComponent(text)}`;
}
