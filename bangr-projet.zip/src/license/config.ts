// true  : il faut un code d'activation valable pour utiliser BÃNGR (sauf l'administrateur).
// false : l'application s'utilise librement (mettre false pour désactiver tout le système de licences).
export const LICENSE_REQUIRED = true;
