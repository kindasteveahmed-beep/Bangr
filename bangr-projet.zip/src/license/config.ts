// true  : il faut un code d'activation valable pour utiliser BÃNGR (sauf l'administrateur).
// false : l'application s'utilise librement (mettre false pour désactiver tout le système de licences).
export const LICENSE_REQUIRED = true;

// Contact pour obtenir ou renouveler un code d'activation (affiché dans l'application).
// Numéros locaux à 8 chiffres (Burkina Faso, indicatif 226 ajouté automatiquement).
export const SUPPORT_PHONES = ['73503199', '66575719'];
export const SUPPORT_LABEL = '73 50 31 99 / 66 57 57 19';
