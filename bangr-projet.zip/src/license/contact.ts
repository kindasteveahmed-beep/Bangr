import { whatsappLink } from '../domain/whatsapp.ts';
import { SUPPORT_PHONES } from './config.ts';

export type ContactReason = 'none' | 'trial' | 'trialEnded' | 'expired' | 'soon' | 'revoked' | 'device' | 'other';
const WHY: Record<ContactReason, string> = {
  none: 'Bonjour, je voudrais obtenir un code d’activation pour BÃNGR.',
  trial: 'Bonjour, mon essai gratuit de BÃNGR se termine bientôt. Je voudrais obtenir un code d’activation.',
  trialEnded: 'Bonjour, mon essai gratuit de BÃNGR est terminé. Je voudrais obtenir un code d’activation.',
  expired: 'Bonjour, mon abonnement BÃNGR a expiré. Je voudrais le renouveler.',
  soon: 'Bonjour, mon abonnement BÃNGR expire bientôt. Je voudrais le renouveler.',
  revoked: 'Bonjour, mon accès à BÃNGR est suspendu. Pouvez-vous m’aider ?',
  device: 'Bonjour, mon compte BÃNGR est bloqué sur un nouvel appareil. Pouvez-vous le libérer ?',
  other: 'Bonjour, j’ai besoin d’aide avec BÃNGR.',
};
/** Lien WhatsApp vers le fournisseur, avec un message déjà écrit (et l'e-mail du compte pour le retrouver vite). */
export function contactLink(reason: ContactReason, email?: string | null): string {
  const text = WHY[reason] + (email ? `\nMon e-mail : ${email}` : '');
  return whatsappLink(SUPPORT_PHONES[0], text);
}
