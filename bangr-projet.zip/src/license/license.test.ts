import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Cloud } from '../sync/cloud.ts';
import type { KV } from '../sync/cloud.ts';
import { LicenseService } from './service.ts';
import { DAY, evaluate, generateCode, normalizeCode, isValidCodeFormat, expiresAt } from './model.ts';
import type { LocalState, LicenseDoc } from './model.ts';
import { getDeviceId } from './store.ts';

// ---- Faux Firebase en mémoire : applique les MÊMES règles que REGLES-FIRESTORE-LICENCES.txt (simulation, pas le vrai serveur) ----
const clock = { t: new Date(2026, 9, 26, 9, 0).getTime() };
function backend(adminEmail: string) {
  const users = new Map<string, { pw: string; uid: string }>(); let docs = new Map<string, any>();
  const emailOf = (uid: string) => [...users].find(([, u]) => u.uid === uid)?.[0];
  const ok = (b: unknown) => ({ ok: true, status: 200, json: async () => b });
  const no = (status: number, message = '') => ({ ok: false, status, json: async () => ({ error: { message } }) });
  const ts = (ms: number) => ({ timestampValue: new Date(ms).toISOString() });
  const str = (f: any) => f?.stringValue, int = (f: any) => Number(f?.integerValue), arr = (f: any): string[] => (f?.arrayValue?.values ?? []).map((v: any) => v.stringValue);
  function allowed(key: string, before: any, after: any, staged: Map<string, any>, auth: string, admin: boolean): boolean {
    if (admin) return true; if (!auth) return false;
    const [coll, id] = key.split('/'); const code = (c: string) => docs.get('codes/' + c);
    if (coll === 'redeemed') return !before && !!code(id) && !code(id).revoked?.booleanValue && str(after.uid) === auth && after.at?.timestampValue === ts(clock.t).timestampValue;
    if (coll === 'licenses' && id === auth) {
      const c = str(after.code), cd = code(c), red = staged.get('redeemed/' + c);
      const fresh = !!cd && !!red && str(red.uid) === auth && int(after.days) === int(cd.days) && int(after.maxDevices) === int(cd.maxDevices) && after.activatedAt?.timestampValue === ts(clock.t).timestampValue && str(after.email) === emailOf(auth) && arr(after.devices).length === 1;
      if (!before) return fresh;
      const sameButDevices = ['code', 'email', 'days', 'maxDevices', 'activatedAt'].every((k) => JSON.stringify(before[k]) === JSON.stringify(after[k])) && !!before.revoked === !!after.revoked;
      const addDevice = sameButDevices && arr(after.devices).length <= int(before.maxDevices) && arr(before.devices).every((d) => arr(after.devices).includes(d));
      return addDevice || (str(after.code) !== str(before.code) && fresh);
    }
    return false;
  }
  const f = (async (url: string, init: any = {}) => {
    const body = init.body && String(init.headers?.['Content-Type']).includes('json') ? JSON.parse(init.body) : null;
    if (url.includes('accounts:signUp') || url.includes('signInWithPassword')) {
      if (url.includes('signUp')) { if (users.has(body.email)) return no(400, 'EMAIL_EXISTS'); users.set(body.email, { pw: body.password, uid: 'U' + users.size }); }
      const u = users.get(body.email); if (!u || u.pw !== body.password) return no(400, 'INVALID_LOGIN_CREDENTIALS');
      return ok({ localId: u.uid, idToken: 'T:' + u.uid, refreshToken: 'r', expiresIn: '3600' });
    }
    const m = url.match(/\/documents(.*)$/); if (!m) return no(400, 'URL');
    const auth = String(init.headers?.Authorization ?? '').replace('Bearer T:', ''); const admin = emailOf(auth) === adminEmail;
    const path = m[1];
    if (init.method === 'GET') {
      const [p] = path.split('?'); const parts = p.split('/').filter(Boolean);
      if (parts.length === 1) { // liste : réservée à l'administrateur
        if (!admin) return no(403, 'PERMISSION_DENIED');
        const documents = [...docs].filter(([k]) => k.startsWith(parts[0] + '/')).map(([k, fields]) => ({ name: `projects/P/databases/(default)/documents/${k}`, fields }));
        return ok(documents.length ? { documents } : {});
      }
      const [coll, id] = parts; const may = coll === 'codes' ? !!auth : coll === 'licenses' ? auth === id || admin : admin;
      if (!may) return no(403, 'PERMISSION_DENIED');
      const d = docs.get(parts.join('/')); return d ? ok({ name: `projects/P/databases/(default)/documents/${parts.join('/')}`, fields: d }) : no(404, 'NOT_FOUND');
    }
    if (path === ':commit') {
      const staged = new Map(docs); const changes: { key: string; before: any; after: any }[] = [];
      for (const w of body.writes) {
        const key = (w.update?.name ?? w.delete).split('/documents/')[1]; const before = staged.get(key);
        if (w.currentDocument?.exists === false && before) return no(409, 'ALREADY_EXISTS');
        if (w.currentDocument?.exists === true && !before) return no(404, 'NOT_FOUND');
        if (w.delete) { staged.delete(key); changes.push({ key, before, after: null }); continue; }
        let after: any = w.updateMask ? { ...(before ?? {}) } : {};
        for (const [k, v] of Object.entries(w.update.fields)) if (!w.updateMask || w.updateMask.fieldPaths.includes(k)) after[k] = v;
        for (const t of w.updateTransforms ?? []) after[t.fieldPath] = ts(clock.t);
        staged.set(key, after); changes.push({ key, before, after });
      }
      for (const c of changes) if (c.after && !allowed(c.key, c.before, c.after, staged, auth, admin)) return no(403, 'PERMISSION_DENIED');
      docs = staged; return ok({});
    }
    return no(400, 'CHEMIN');
  }) as unknown as typeof fetch;
  return { f };
}
const mkKV = (): KV => { const m = new Map<string, string>(); return { get: (k) => m.get(k) ?? null, set: (k, v) => void m.set(k, v), del: (k) => void m.delete(k) }; };
async function person(be: ReturnType<typeof backend>, email: string) { const cloud = new Cloud({ apiKey: 'K', projectId: 'P' }, mkKV(), be.f); await cloud.signUp(email, 'secret1'); return { cloud, svc: new LicenseService(cloud) }; }
const setup = async () => { clock.t = new Date(2026, 9, 26, 9, 0).getTime(); const be = backend('admin@x.com'); return { be, admin: await person(be, 'admin@x.com') }; };

test('codes : format, alphabet sans confusion, unicité, normalisation', () => {
  const seen = new Set<string>();
  for (let i = 0; i < 2000; i++) { const c = generateCode(); assert.match(c, /^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/); seen.add(c); }
  assert.equal(seen.size, 2000);
  assert.equal(normalizeCode(' abcd-efgh jkmn '), 'ABCDEFGHJKMN'); assert.ok(isValidCodeFormat('ABCDEFGHJKMN')); assert.ok(!isValidCodeFormat('ABCDEFGHJK0N'));
});
test('évaluation de l’accès : ok, expiré, annulé, appareil, horloge, vérification en ligne, administrateur', () => {
  const lic: LicenseDoc = { code: 'X', email: 'a@x.com', days: 30, maxDevices: 1, devices: ['D1'], activatedAt: 1000 * DAY, revoked: false };
  const st = (o: Partial<LocalState> = {}, l: Partial<LicenseDoc> = {}): LocalState => ({ uid: 'U1', license: { ...lic, ...l }, admin: false, verifiedAt: 1005 * DAY, lastSeen: 1005 * DAY, ...o });
  const g = (s: LocalState | null, now: number, dev = 'D1', uid: string | null = 'U1') => evaluate(s, uid, dev, now).state;
  assert.deepEqual(evaluate(st(), 'U1', 'D1', 1010 * DAY), { state: 'ok', admin: false, daysLeft: 20 });
  assert.equal(g(null, 1010 * DAY), 'none'); assert.equal(g(st(), 1010 * DAY, 'D1', null), 'none'); assert.equal(g(st(), 1010 * DAY, 'D1', 'U2'), 'none');
  assert.equal(g(st({ license: null }), 1010 * DAY), 'none');
  assert.equal(g(st({}, { revoked: true }), 1010 * DAY), 'revoked');
  assert.equal(g(st(), 1010 * DAY, 'D2'), 'device');
  assert.equal(g(st(), 1031 * DAY), 'expired');
  assert.equal(g(st({ lastSeen: 1020 * DAY }), 1010 * DAY), 'clock');
  assert.equal(g(st({ verifiedAt: 1000 * DAY, lastSeen: 1000 * DAY }, { days: 365 }), 1035 * DAY), 'online');
  assert.deepEqual(evaluate(st({ admin: true, license: null }), 'U1', 'D9', 5000 * DAY), { state: 'ok', admin: true, daysLeft: null });
});
test('identifiant d’appareil : créé une fois puis conservé', () => {
  const m = new Map<string, string>(); const kv = { get: (k: string) => m.get(k) ?? null, set: (k: string, v: string) => void m.set(k, v) };
  const a = getDeviceId(kv, 'Android', () => 'aaaa1111'); assert.equal(a, 'Android:aaaa1111'); assert.equal(getDeviceId(kv, 'Windows', () => 'zzzz'), a);
});
test('activation complète : l’administrateur crée un code, le client l’active, un second client est refusé', async () => {
  const { be, admin } = await setup();
  assert.equal(await admin.svc.probeAdmin(), true);
  const code = await admin.svc.createCode({ days: 30, maxDevices: 1, note: 'Boutique Awa' });
  assert.match(code, /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
  assert.equal((await admin.svc.listCodes())[0].usedBy, null);
  const awa = await person(be, 'awa@x.com'); assert.equal(await awa.svc.probeAdmin(), false);
  const lic = await awa.svc.redeem(' ' + code.toLowerCase() + ' ', 'Android:d1', clock.t);
  assert.equal(lic.days, 30); assert.deepEqual(lic.devices, ['Android:d1']); assert.equal(lic.activatedAt, clock.t); assert.equal(lic.email, 'awa@x.com');
  assert.equal(expiresAt(lic), clock.t + 30 * DAY);
  const bob = await person(be, 'bob@x.com');
  await assert.rejects(() => bob.svc.redeem(code, 'Android:d2', clock.t), /déjà été utilisé/);
  assert.equal(await bob.svc.getLicense(), null);
  const row = (await admin.svc.listCodes())[0]; assert.equal(row.usedBy, 'awa@x.com'); assert.equal(row.note, 'Boutique Awa');
});
test('codes invalides : mauvais format, inconnu, annulé', async () => {
  const { be, admin } = await setup(); const c = await person(be, 'c@x.com');
  await assert.rejects(() => c.svc.redeem('ABC', 'D', clock.t), /bon format/);
  await assert.rejects(() => c.svc.redeem('AAAA-BBBB-CCCC', 'D', clock.t), /inconnu/);
  const code = await admin.svc.createCode({ days: 10, maxDevices: 1, note: '' });
  await admin.svc.setCodeRevoked(code, true);
  await assert.rejects(() => c.svc.redeem(code, 'D', clock.t), /annulé/);
});
test('appareils : limite respectée, appareil supplémentaire refusé, réinitialisation par l’administrateur', async () => {
  const { be, admin } = await setup(); const c = await person(be, 'c@x.com');
  const code = await admin.svc.createCode({ days: 30, maxDevices: 2, note: '' });
  await c.svc.redeem(code, 'Android:1', clock.t);
  assert.deepEqual((await c.svc.refresh('Windows:2')).license!.devices, ['Android:1', 'Windows:2']);
  assert.deepEqual((await c.svc.refresh('Android:3')).license!.devices, ['Android:1', 'Windows:2']);
  const uid = c.cloud.session!.uid; await admin.svc.resetDevices(uid);
  assert.deepEqual((await c.svc.refresh('Android:3')).license!.devices, ['Android:3']);
});
test('abonnement : un code actif n’est pas écrasé trop tôt, le renouvellement est possible dans les 30 derniers jours', async () => {
  const { be, admin } = await setup(); const c = await person(be, 'c@x.com');
  const c1 = await admin.svc.createCode({ days: 90, maxDevices: 1, note: '' }), c2 = await admin.svc.createCode({ days: 90, maxDevices: 1, note: '' });
  const t0 = clock.t; await c.svc.redeem(c1, 'D', clock.t);
  clock.t = t0 + 10 * DAY; await assert.rejects(() => c.svc.redeem(c2, 'D', clock.t), /encore actif/);
  clock.t = t0 + 70 * DAY; const renewed = await c.svc.redeem(c2, 'D', clock.t);
  assert.equal(renewed.activatedAt, t0 + 70 * DAY); assert.equal(renewed.code, normalizeCode(c2));
});
test('administration : révoquer, rétablir et prolonger une licence', async () => {
  const { be, admin } = await setup(); const c = await person(be, 'c@x.com'); const uid = c.cloud.session!.uid;
  await c.svc.redeem(await admin.svc.createCode({ days: 30, maxDevices: 1, note: '' }), 'D', clock.t);
  await admin.svc.setLicenseRevoked(uid, true); assert.equal((await c.svc.refresh('D')).license!.revoked, true);
  await admin.svc.setLicenseRevoked(uid, false); await admin.svc.extend(uid, 30);
  const l = (await c.svc.refresh('D')).license!; assert.equal(l.revoked, false); assert.equal(l.days, 60);
  assert.equal((await admin.svc.listLicenses())[0].email, 'c@x.com');
});
test('un client ne peut ni administrer, ni se fabriquer une licence à la main (simulation des règles)', async () => {
  const { be, admin } = await setup(); const c = await person(be, 'c@x.com'); const uid = c.cloud.session!.uid;
  await assert.rejects(() => c.svc.createCode({ days: 30, maxDevices: 1, note: '' }), /règles Firestore/);
  await assert.rejects(() => c.svc.listCodes(), /règles Firestore/);
  const code = (await admin.svc.createCode({ days: 7, maxDevices: 1, note: '' })).replace(/-/g, '');
  const forge = (days: number) => c.cloud.fsRequest('POST', ':commit', { writes: [
    { update: { name: c.cloud.docName(`/redeemed/${code}`), fields: { uid: { stringValue: uid } } }, updateTransforms: [{ fieldPath: 'at', setToServerValue: 'REQUEST_TIME' }], currentDocument: { exists: false } },
    { update: { name: c.cloud.docName(`/licenses/${uid}`), fields: { code: { stringValue: code }, email: { stringValue: 'c@x.com' }, days: { integerValue: String(days) }, maxDevices: { integerValue: '1' }, devices: { arrayValue: { values: [{ stringValue: 'D' }] } } } }, updateTransforms: [{ fieldPath: 'activatedAt', setToServerValue: 'REQUEST_TIME' }], currentDocument: { exists: false } }] });
  assert.equal((await forge(3650)).status, 403); assert.equal(await c.svc.getLicense(), null);
  assert.equal((await forge(7)).status, 200);
});
