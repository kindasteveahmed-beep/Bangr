// Licences : logique pure (sans réseau), testable.
export interface LicenseDoc { code: string; email: string; days: number; maxDevices: number; devices: string[]; activatedAt: number; revoked: boolean }
export interface LocalState { uid: string; license: LicenseDoc | null; trial?: { startedAt: number } | null; admin: boolean; verifiedAt: number; lastSeen: number }
export type Gate = { state: 'ok'; admin: boolean; daysLeft: number | null; trial?: boolean } | { state: 'none' | 'expired' | 'trialEnded' | 'revoked' | 'device' | 'clock' | 'online' };

export const DAY = 86400000;
export const TRIAL_DAYS = 7; // essai gratuit : doit rester égal à la durée écrite dans les règles Firestore (trialOk)
export const OFFLINE_GRACE_DAYS = 30; // au-delà, une connexion est exigée pour revérifier
export const RENEW_WINDOW_DAYS = 30; // un nouveau code n'est accepté que dans les 30 derniers jours
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 signes, sans 0/O/1/I (évite les confusions)

const randomBytes = (n: number) => globalThis.crypto.getRandomValues(new Uint8Array(n));
/** Code de 12 signes (≈ 60 bits), affiché XXXX-XXXX-XXXX. 32 divise 256 : aucun biais. */
export function generateCode(rand: (n: number) => Uint8Array = randomBytes): string {
  const c = [...rand(12)].map((b) => ALPHABET[b % 32]).join('');
  return `${c.slice(0, 4)}-${c.slice(4, 8)}-${c.slice(8)}`;
}
export const normalizeCode = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, '');
export const isValidCodeFormat = (norm: string) => new RegExp(`^[${ALPHABET}]{12}$`).test(norm);
export const formatCode = (norm: string) => `${norm.slice(0, 4)}-${norm.slice(4, 8)}-${norm.slice(8)}`;

export const expiresAt = (l: LicenseDoc) => l.activatedAt + l.days * DAY;
export const daysLeft = (l: LicenseDoc, now: number) => Math.ceil((expiresAt(l) - now) / DAY);

/** Décide si l'application peut s'utiliser. Fonctionne hors connexion grâce à l'état enregistré. */
export function evaluate(st: LocalState | null, uid: string | null, deviceId: string, now: number): Gate {
  if (!st || !uid || st.uid !== uid) return { state: 'none' };
  if (st.admin) return { state: 'ok', admin: true, daysLeft: null };
  const l = st.license;
  if (!l) {
    const t = st.trial;
    if (!t) return { state: 'none' };
    if (now < st.lastSeen - DAY || t.startedAt > now + DAY) return { state: 'clock' };
    const end = t.startedAt + TRIAL_DAYS * DAY;
    if (now >= end) return { state: 'trialEnded' };
    if (now - st.verifiedAt > OFFLINE_GRACE_DAYS * DAY) return { state: 'online' };
    return { state: 'ok', admin: false, daysLeft: Math.ceil((end - now) / DAY), trial: true };
  }
  if (l.revoked) return { state: 'revoked' };
  if (!l.devices.includes(deviceId)) return { state: 'device' };
  if (now < st.lastSeen - DAY || l.activatedAt > now + DAY) return { state: 'clock' }; // l'horloge a été reculée
  if (now >= expiresAt(l)) return { state: 'expired' };
  if (now - st.verifiedAt > OFFLINE_GRACE_DAYS * DAY) return { state: 'online' };
  return { state: 'ok', admin: false, daysLeft: daysLeft(l, now) };
}
