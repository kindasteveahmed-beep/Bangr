import { CloudError } from '../sync/cloud.ts';
import type { Cloud } from '../sync/cloud.ts';
import { DAY, RENEW_WINDOW_DAYS, expiresAt, formatCode, generateCode, isValidCodeFormat, normalizeCode } from './model.ts';
import type { LicenseDoc } from './model.ts';

type Resp = { ok: boolean; status: number; json: any };
const S = (v: string) => ({ stringValue: v });
const I = (n: number) => ({ integerValue: String(n) });
const B = (v: boolean) => ({ booleanValue: v });
const A = (a: string[]) => ({ arrayValue: { values: a.map(S) } });
function dec(v: any): any {
  if ('stringValue' in v) return v.stringValue; if ('integerValue' in v) return Number(v.integerValue); if ('booleanValue' in v) return v.booleanValue;
  if ('timestampValue' in v) return Date.parse(v.timestampValue); if ('arrayValue' in v) return (v.arrayValue.values ?? []).map(dec); return null;
}
const fields = (d: any): any => Object.fromEntries(Object.entries(d.fields ?? {}).map(([k, v]) => [k, dec(v)]));
const idOf = (d: any) => String(d.name).split('/').pop() as string;
const toLicense = (f: any): LicenseDoc => ({ code: f.code ?? '', email: f.email ?? '', days: f.days ?? 0, maxDevices: f.maxDevices ?? 1, devices: f.devices ?? [], activatedAt: f.activatedAt ?? 0, revoked: !!f.revoked });

export interface CodeRow { code: string; days: number; maxDevices: number; note: string; createdAt: number; revoked: boolean; usedBy: string | null }
export type LicenseRow = LicenseDoc & { uid: string };

export class LicenseService {
  private c: Cloud;
  constructor(c: Cloud) { this.c = c; }
  private me() { const s = this.c.session; if (!s) throw new CloudError('Non connecté.'); return s; }
  private err(r: Resp) { return new CloudError(r.status === 403 ? 'Accès refusé : les règles Firestore ne sont pas à jour.' : 'Erreur : ' + (r.json?.error?.message ?? r.status)); }
  private commit(writes: unknown[]) { return this.c.fsRequest('POST', ':commit', { writes }); }

  async getLicense(): Promise<LicenseDoc | null> {
    const r = await this.c.fsRequest('GET', `/licenses/${this.me().uid}`);
    if (r.status === 404) return null; if (!r.ok) throw this.err(r);
    return toLicense(fields(r.json));
  }

  /** Active un code : crée (ou renouvelle) la licence liée au compte et à cet appareil. */
  async redeem(raw: string, deviceId: string, now = Date.now()): Promise<LicenseDoc> {
    const s = this.me(); const code = normalizeCode(raw);
    if (!isValidCodeFormat(code)) throw new CloudError('Ce code n’a pas le bon format (12 lettres et chiffres).');
    const g = await this.c.fsRequest('GET', `/codes/${code}`);
    if (g.status === 404 || g.status === 403) throw new CloudError('Code inconnu. Vérifie-le et réessaie.');
    if (!g.ok) throw this.err(g);
    const cf = fields(g.json);
    if (cf.revoked) throw new CloudError('Ce code a été annulé.');
    const existing = await this.getLicense();
    if (existing && !existing.revoked && expiresAt(existing) - now > RENEW_WINDOW_DAYS * DAY)
      throw new CloudError(`Ton abonnement est encore actif. Tu pourras ajouter un nouveau code dans les ${RENEW_WINDOW_DAYS} derniers jours.`);
    const r = await this.commit([
      { update: { name: this.c.docName(`/redeemed/${code}`), fields: { uid: S(s.uid) } }, updateTransforms: [{ fieldPath: 'at', setToServerValue: 'REQUEST_TIME' }], currentDocument: { exists: false } },
      { update: { name: this.c.docName(`/licenses/${s.uid}`), fields: { code: S(code), email: S(s.email), days: I(cf.days), maxDevices: I(cf.maxDevices), devices: A([deviceId]) } }, updateTransforms: [{ fieldPath: 'activatedAt', setToServerValue: 'REQUEST_TIME' }], currentDocument: { exists: !!existing } },
    ]);
    if (!r.ok) { if ([400, 403, 409].includes(r.status)) throw new CloudError('Code refusé : il a déjà été utilisé ou il a été annulé.'); throw this.err(r); }
    const lic = await this.getLicense(); if (!lic) throw new CloudError('Activation incomplète. Réessaie.');
    return lic;
  }

  /** Relit la licence, enregistre cet appareil s'il reste de la place, et détecte l'administrateur. */
  async refresh(deviceId: string): Promise<{ license: LicenseDoc | null; admin: boolean }> {
    let license = await this.getLicense();
    if (license && !license.devices.includes(deviceId) && license.devices.length < license.maxDevices) {
      const devices = [...license.devices, deviceId];
      const r = await this.commit([{ update: { name: this.c.docName(`/licenses/${this.me().uid}`), fields: { devices: A(devices) } }, updateMask: { fieldPaths: ['devices'] }, currentDocument: { exists: true } }]);
      if (r.ok) license = { ...license, devices };
    }
    return { license, admin: await this.probeAdmin() };
  }
  /** L'administrateur est celui à qui les règles Firestore permettent de lister les codes. */
  async probeAdmin(): Promise<boolean> { return (await this.c.fsRequest('GET', '/codes?pageSize=1')).ok; }

  // ---------- Administration ----------
  async createCode(o: { days: number; maxDevices: number; note: string }): Promise<string> {
    if (!Number.isInteger(o.days) || o.days < 1 || o.days > 3650) throw new CloudError('Durée invalide (1 à 3650 jours).');
    if (!Number.isInteger(o.maxDevices) || o.maxDevices < 1 || o.maxDevices > 20) throw new CloudError('Nombre d’appareils invalide (1 à 20).');
    for (let i = 0; i < 5; i++) {
      const code = generateCode().replace(/-/g, '');
      const r = await this.commit([{ update: { name: this.c.docName(`/codes/${code}`), fields: { days: I(o.days), maxDevices: I(o.maxDevices), note: S(o.note.trim()) } }, updateTransforms: [{ fieldPath: 'createdAt', setToServerValue: 'REQUEST_TIME' }], currentDocument: { exists: false } }]);
      if (r.ok) return formatCode(code);
      if (r.status !== 409) throw this.err(r);
    }
    throw new CloudError('Impossible de créer un code. Réessaie.');
  }
  private async list(coll: string): Promise<any[]> {
    const r = await this.c.fsRequest('GET', `/${coll}?pageSize=300`);
    if (!r.ok) throw this.err(r);
    return r.json.documents ?? [];
  }
  async listLicenses(): Promise<LicenseRow[]> { return (await this.list('licenses')).map((d) => ({ uid: idOf(d), ...toLicense(fields(d)) })).sort((a, b) => b.activatedAt - a.activatedAt); }
  async listCodes(): Promise<CodeRow[]> {
    const [codes, used, lics] = await Promise.all([this.list('codes'), this.list('redeemed'), this.listLicenses()]);
    const usedBy = new Map(used.map((d) => [idOf(d), fields(d).uid as string]));
    const email = new Map(lics.map((l) => [l.uid, l.email]));
    return codes.map((d) => { const f = fields(d), id = idOf(d), u = usedBy.get(id); return { code: formatCode(id), days: f.days, maxDevices: f.maxDevices, note: f.note ?? '', createdAt: f.createdAt ?? 0, revoked: !!f.revoked, usedBy: u ? email.get(u) ?? 'compte supprimé' : null }; }).sort((a, b) => b.createdAt - a.createdAt);
  }
  private async patch(path: string, f: Record<string, unknown>) {
    const r = await this.commit([{ update: { name: this.c.docName(path), fields: f }, updateMask: { fieldPaths: Object.keys(f) }, currentDocument: { exists: true } }]);
    if (!r.ok) throw this.err(r);
  }
  setCodeRevoked(code: string, revoked: boolean) { return this.patch(`/codes/${normalizeCode(code)}`, { revoked: B(revoked) }); }
  setLicenseRevoked(uid: string, revoked: boolean) { return this.patch(`/licenses/${uid}`, { revoked: B(revoked) }); }
  resetDevices(uid: string) { return this.patch(`/licenses/${uid}`, { devices: { arrayValue: {} } }); }
  async extend(uid: string, addDays: number) {
    const r = await this.c.fsRequest('GET', `/licenses/${uid}`); if (!r.ok) throw this.err(r);
    return this.patch(`/licenses/${uid}`, { days: I(toLicense(fields(r.json)).days + addDays) });
  }
}
