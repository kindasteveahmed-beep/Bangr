import type { LocalState } from './model.ts';
import type { SimpleKV } from '../data/settings.ts';

const KEY = 'bangr_lic', DEV = 'bangr_device';
export function loadState(kv: SimpleKV): LocalState | null {
  try { const v = JSON.parse(kv.get(KEY) || 'null'); return v && typeof v.uid === 'string' ? (v as LocalState) : null; } catch { return null; }
}
export const saveState = (kv: SimpleKV, st: LocalState) => kv.set(KEY, JSON.stringify(st));
/** Identifiant de cet appareil : créé une fois (ex. « Android:3fa9c2d1 »). Une réinstallation en crée un nouveau. */
export function getDeviceId(kv: SimpleKV, label: string, rand: () => string = () => [...globalThis.crypto.getRandomValues(new Uint8Array(4))].map((b) => b.toString(16).padStart(2, '0')).join('')): string {
  const old = kv.get(DEV); if (old) return old;
  const id = `${label}:${rand()}`; kv.set(DEV, id); return id;
}
