import { createRoot } from 'react-dom/client';
import App from './ui/App.tsx';
import './ui/index.css';

navigator.storage?.persist?.(); // demande au téléphone de ne pas effacer les données
if (!(window as any).Capacitor && 'serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
createRoot(document.getElementById('root')!).render(<App />);
