import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MemoryRepo } from '../domain/repo.ts';
import { createProduct, recordSale, cancelSale } from '../domain/services.ts';
import { Cloud } from './cloud.ts';
import type { KV } from './cloud.ts';
import type { Product, Sale } from '../domain/types.ts';

// Faux serveur Firebase en mémoire (auth + Firestore) pour tester la synchronisation sans réseau.
function fakeServer() {
  const users = new Map<string, { pw: string; uid: string }>(); const docs = new Map<string, any>();
  const ok = (b: unknown) => ({ ok: true, status: 200, json: async () => b });
  const err = (m: string) => ({ ok: false, status: 400, json: async () => ({ error: { message: m } }) });
  const f = (async (url: string, init: any) => {
    const body = typeof init.body === 'string' && init.headers['Content-Type'].includes('json') ? JSON.parse(init.body) : init.body;
    if (url.includes('accounts:signUp')) { if (users.has(body.email)) return err('EMAIL_EXISTS'); users.set(body.email, { pw: body.password, uid: 'U' + users.size }); }
    if (url.includes('accounts:signUp') || url.includes('signInWithPassword')) {
      const u = users.get(body.email); if (!u || u.pw !== body.password) return err('INVALID_LOGIN_CREDENTIALS');
      return ok({ localId: u.uid, idToken: 't', refreshToken: 'r', expiresIn: '3600' });
    }
    if (url.includes('securetoken')) return ok({ id_token: 't2', refresh_token: 'r', expires_in: '3600' });
    if (url.includes('accounts:delete')) { for (const [e, u] of users) if (u.uid === 'U' + [...users.keys()].indexOf(e)) users.delete(e); return ok({}); }
    if (url.includes(':commit')) { for (const w of body.writes) { if (w.delete) docs.delete(w.delete); else docs.set(w.update.name, w.update.fields); } return ok({}); }
    if (url.includes(':runQuery')) {
      const since = Number(body.structuredQuery.where?.fieldFilter.value.integerValue ?? 0); const prefix = '/bangr/' + url.split('/bangr/')[1].split(':')[0] + '/r/';
      const rows = [...docs].filter(([n, v]) => n.includes(prefix) && Number(v.u.integerValue) >= since).sort((a, b) => Number(a[1].u.integerValue) - Number(b[1].u.integerValue)).slice(0, body.structuredQuery.limit);
      return ok(rows.map(([name, fields]) => ({ document: { name, fields } })));
    }
    return err('INCONNU');
  }) as unknown as typeof fetch;
  return { f, docs };
}
const mkKV = (): KV => { const m = new Map<string, string>(); return { get: (k) => m.get(k) ?? null, set: (k, v) => void m.set(k, v), del: (k) => void m.delete(k) }; };
let clock = 1000; const tick = () => ++clock;
const CFG = { apiKey: 'K', projectId: 'P' };
async function device(srv: ReturnType<typeof fakeServer>) { return { repo: new MemoryRepo(tick), cloud: new Cloud(CFG, mkKV(), srv.f) }; }
const stock = async (r: MemoryRepo, id: string) => (await r.get<Product>('products', id))!.stock;

test('inscription, mauvais mot de passe, compte déjà existant', async () => {
  const srv = fakeServer(); const { cloud } = await device(srv);
  await cloud.signUp('a@x.com', 'secret1'); assert.equal(cloud.session?.email, 'a@x.com');
  await assert.rejects(() => cloud.signUp('a@x.com', 'secret1'), /existe déjà/);
  cloud.signOut(); assert.equal(cloud.session, null);
  await assert.rejects(() => cloud.signIn('a@x.com', 'faux'), /incorrect/);
  await cloud.signIn('a@x.com', 'secret1'); assert.ok(cloud.session);
});
test('un second téléphone retrouve produits, ventes et stock', async () => {
  const srv = fakeServer(); const A = await device(srv); const B = await device(srv);
  await A.cloud.signUp('a@x.com', 'secret1');
  const p = await createProduct(A.repo, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 10 }, tick());
  await recordSale(A.repo, { lines: [{ productId: p.id, qty: 3 }], paid: 9000 }, tick());
  const r = await A.cloud.sync(A.repo); assert.ok(r.pushed >= 4);
  await B.cloud.signIn('a@x.com', 'secret1'); await B.repo.markAllDirty();
  await B.cloud.sync(B.repo);
  assert.equal((await B.repo.all<Product>('products')).length, 1);
  assert.equal(await stock(B.repo, p.id), 7);
  assert.equal((await B.repo.all<Sale>('sales'))[0].lines[0].unitCost, 2000);
});
test('une annulation faite sur un téléphone arrive sur l’autre', async () => {
  const srv = fakeServer(); const A = await device(srv); const B = await device(srv);
  await A.cloud.signUp('a@x.com', 'secret1'); await B.cloud.signIn('a@x.com', 'secret1');
  const p = await createProduct(A.repo, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 10 }, tick());
  const s = await recordSale(A.repo, { lines: [{ productId: p.id, qty: 3 }], paid: 9000 }, tick());
  await A.cloud.sync(A.repo); await B.cloud.sync(B.repo);
  await cancelSale(B.repo, s.id, 'erreur', tick()); await B.cloud.sync(B.repo);
  await A.cloud.sync(A.repo);
  assert.equal((await A.repo.get<Sale>('sales', s.id))!.status, 'ANNULEE'); assert.equal(await stock(A.repo, p.id), 10);
});
test('deux téléphones vendent en même temps : le stock reste juste', async () => {
  const srv = fakeServer(); const A = await device(srv); const B = await device(srv);
  await A.cloud.signUp('a@x.com', 'secret1'); await B.cloud.signIn('a@x.com', 'secret1');
  const p = await createProduct(A.repo, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 10 }, tick());
  await A.cloud.sync(A.repo); await B.cloud.sync(B.repo);
  await recordSale(A.repo, { lines: [{ productId: p.id, qty: 2 }], paid: 6000 }, tick());
  await recordSale(B.repo, { lines: [{ productId: p.id, qty: 1 }], paid: 3000 }, tick());
  await A.cloud.sync(A.repo); await B.cloud.sync(B.repo); await A.cloud.sync(A.repo);
  assert.equal(await stock(A.repo, p.id), 7); assert.equal(await stock(B.repo, p.id), 7);
  assert.equal((await A.repo.all<Sale>('sales')).length, 2); assert.equal((await B.repo.all<Sale>('sales')).length, 2);
});
test('hors connexion : message clair et rien n’est perdu', async () => {
  const kv = mkKV(); const srv = fakeServer(); const c1 = new Cloud(CFG, kv, srv.f); await c1.signUp('a@x.com', 'secret1');
  const down = (async () => { throw new TypeError('fail'); }) as unknown as typeof fetch;
  const c2 = new Cloud(CFG, kv, down); const repo = new MemoryRepo(tick);
  await createProduct(repo, { name: 'X', costPrice: 1, salePrice: 2, stock: 1 }, tick());
  await assert.rejects(() => c2.sync(repo), /Pas de connexion/);
  assert.ok((await repo.outbox()).length > 0);
});

test('suppression du compte : mot de passe vérifié, données en ligne effacées, données du téléphone conservées', async () => {
  const srv = fakeServer(); const A = await device(srv);
  await A.cloud.signUp('a@x.com', 'secret1');
  await createProduct(A.repo, { name: 'Pagne', costPrice: 2000, salePrice: 3000, stock: 10 }, tick());
  await A.cloud.sync(A.repo); assert.ok(srv.docs.size >= 2);
  await assert.rejects(() => A.cloud.deleteAccount('faux'), /incorrect/); assert.ok(srv.docs.size >= 2);
  await A.cloud.deleteAccount('secret1');
  assert.equal(srv.docs.size, 0); assert.equal(A.cloud.session, null);
  await assert.rejects(() => A.cloud.signIn('a@x.com', 'secret1'), /incorrect/);
  assert.equal((await A.repo.all<Product>('products')).length, 1);
});
