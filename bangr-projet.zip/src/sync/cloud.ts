import type { SyncRepo, StoreName } from '../domain/repo.ts';
import { STORE_NAMES } from '../domain/repo.ts';
import type { Product, StockMove } from '../domain/types.ts';

export interface CloudConfig { apiKey: string; projectId: string }
export interface Session { email: string; uid: string; rt: string; tok: string; exp: number }
export interface KV { get(k: string): string | null; set(k: string, v: string): void; del(k: string): void }
export class CloudError extends Error {}

const MSG: [RegExp, string][] = [
  [/EMAIL_EXISTS/, 'Ce compte existe déjà : touche « Se connecter ».'],
  [/INVALID_LOGIN|INVALID_PASSWORD|EMAIL_NOT_FOUND/, 'Adresse ou mot de passe incorrect.'],
  [/WEAK_PASSWORD/, 'Mot de passe trop court (6 caractères minimum).'],
  [/INVALID_EMAIL|MISSING_EMAIL/, 'Adresse e-mail invalide.'],
  [/OPERATION_NOT_ALLOWED/, 'La connexion par e-mail n’est pas activée dans Firebase.'],
  [/TOO_MANY_ATTEMPTS/, 'Trop d’essais. Réessaie dans quelques minutes.'],
  [/permission|PERMISSION/i, 'Accès refusé : mets à jour les règles Firestore (voir le guide).'],
];
const BATCH = 300;

// Synchronisation « un enregistrement = un document » : fusion par date de modification (u).
// Les mouvements de stock ne sont jamais modifiés : le stock est donc recalculé à partir d'eux après chaque réception,
// ce qui évite les erreurs quand deux téléphones vendent en même temps.
export class Cloud {
  private cfg: CloudConfig; private kv: KV; private f: typeof fetch; private s: Session | null;
  constructor(cfg: CloudConfig, kv: KV, f?: typeof fetch) {
    this.cfg = cfg; this.kv = kv; this.f = f ?? ((...a) => fetch(...a));
    try { const raw = kv.get('bangr_auth'); this.s = raw ? (JSON.parse(raw) as Session) : null; } catch { this.s = null; }
  }
  get session() { return this.s; }
  private setSession(s: Session | null) { this.s = s; if (s) this.kv.set('bangr_auth', JSON.stringify(s)); else this.kv.del('bangr_auth'); }

  private async call(url: string, body: unknown, headers: Record<string, string> = {}, form = false): Promise<any> {
    let r: Response;
    try { r = await this.f(url, { method: 'POST', headers: { 'Content-Type': form ? 'application/x-www-form-urlencoded' : 'application/json', ...headers }, body: form ? (body as string) : JSON.stringify(body) }); }
    catch { throw new CloudError('Pas de connexion internet.'); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const m: string = j?.error?.message ?? j?.error?.status ?? ''; throw new CloudError(MSG.find(([re]) => re.test(m))?.[1] ?? 'Erreur : ' + (m || r.status)); }
    return j;
  }
  private async auth(kind: 'signUp' | 'signInWithPassword', email: string, pw: string) {
    const e = email.trim();
    const j = await this.call(`https://identitytoolkit.googleapis.com/v1/accounts:${kind}?key=${this.cfg.apiKey}`, { email: e, password: pw, returnSecureToken: true });
    this.setSession({ email: e, uid: j.localId, rt: j.refreshToken, tok: j.idToken, exp: Date.now() + (Number(j.expiresIn) - 60) * 1000 });
  }
  signUp(email: string, pw: string) { return this.auth('signUp', email, pw); }
  signIn(email: string, pw: string) { return this.auth('signInWithPassword', email, pw); }
  signOut() { this.setSession(null); }
  async resetPassword(email: string) { await this.call(`https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${this.cfg.apiKey}`, { requestType: 'PASSWORD_RESET', email: email.trim() }); }

  private async token(): Promise<string> {
    if (!this.s) throw new CloudError('Non connecté.');
    if (Date.now() < this.s.exp) return this.s.tok;
    const j = await this.call(`https://securetoken.googleapis.com/v1/token?key=${this.cfg.apiKey}`, 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(this.s.rt), {}, true);
    this.setSession({ ...this.s, tok: j.id_token, rt: j.refresh_token ?? this.s.rt, exp: Date.now() + (Number(j.expires_in) - 60) * 1000 });
    return this.s!.tok;
  }
  private get base() { return `projects/${this.cfg.projectId}/databases/(default)/documents`; }
  private async fs(path: string, body: unknown) { const t = await this.token(); return this.call(`https://firestore.googleapis.com/v1/${this.base}${path}`, body, { Authorization: 'Bearer ' + t }); }

  async sync(repo: SyncRepo): Promise<{ pulled: number; pushed: number }> {
    if (!this.s) throw new CloudError('Non connecté.');
    const uid = this.s.uid; let pulled = 0, pushed = 0;
    // 1) Réception
    const sinceKey = 'bangr_since_' + uid; let since = Number(this.kv.get(sinceKey) ?? 0);
    for (;;) {
      const res: any[] = await this.fs(`/bangr/${uid}:runQuery`, { structuredQuery: { from: [{ collectionId: 'r' }], where: { fieldFilter: { field: { fieldPath: 'u' }, op: 'GREATER_THAN_OR_EQUAL', value: { integerValue: String(since) } } }, orderBy: [{ field: { fieldPath: 'u' }, direction: 'ASCENDING' }], limit: BATCH } });
      const docs = res.filter((x) => x.document).map((x) => x.document.fields);
      let maxU = since;
      for (const f of docs) {
        const s = f.s.stringValue as StoreName; const rec = JSON.parse(f.j.stringValue); const u = Number(f.u.integerValue);
        if (!STORE_NAMES.includes(s)) continue;
        maxU = Math.max(maxU, u);
        const local = await repo.get<{ u?: number }>(s, rec.id);
        if (!local || u > (local.u ?? 0)) { await repo.putRemote([{ s, v: { ...rec, u } }]); pulled++; }
      }
      const more = docs.length >= BATCH && maxU > since;
      since = maxU; this.kv.set(sinceKey, String(since));
      if (!more) break;
    }
    if (pulled > 0) await this.recomputeStock(repo);
    // 2) Envoi
    const keys = await repo.outbox();
    for (let i = 0; i < keys.length; i += BATCH) {
      const chunk = keys.slice(i, i + BATCH); const writes: unknown[] = [];
      for (const k of chunk) {
        const [s, id] = [k.slice(0, k.indexOf(':')) as StoreName, k.slice(k.indexOf(':') + 1)];
        const rec = await repo.get<{ u?: number }>(s, id); if (!rec) continue;
        writes.push({ update: { name: `${this.base}/bangr/${uid}/r/${s}__${id}`, fields: { s: { stringValue: s }, j: { stringValue: JSON.stringify(rec) }, u: { integerValue: String(rec.u ?? 0) } } } });
      }
      if (writes.length) await this.fs(':commit', { writes });
      await repo.clearOutbox(chunk); pushed += writes.length;
    }
    return { pulled, pushed };
  }

  // Suppression définitive du compte et des données en ligne (les données du téléphone restent).
  async deleteAccount(password: string): Promise<void> {
    if (!this.s) throw new CloudError('Non connecté.');
    await this.signIn(this.s.email, password); // vérifie le mot de passe et renouvelle la session
    const uid = this.s!.uid;
    for (let i = 0; i < 1000; i++) {
      const res: any[] = await this.fs(`/bangr/${uid}:runQuery`, { structuredQuery: { from: [{ collectionId: 'r' }], limit: BATCH } });
      const names = res.filter((x) => x.document).map((x) => x.document.name as string);
      if (!names.length) break;
      await this.fs(':commit', { writes: names.map((name) => ({ delete: name })) });
    }
    const t = await this.token();
    await this.call(`https://identitytoolkit.googleapis.com/v1/accounts:delete?key=${this.cfg.apiKey}`, { idToken: t });
    this.kv.del('bangr_since_' + uid);
    this.setSession(null);
  }

  private async recomputeStock(repo: SyncRepo) {
    const sums = new Map<string, number>();
    for (const m of await repo.all<StockMove>('moves')) sums.set(m.productId, (sums.get(m.productId) ?? 0) + m.qty);
    for (const p of await repo.all<Product>('products')) {
      const want = sums.get(p.id) ?? 0;
      if (p.stock !== want) await repo.putRemote([{ s: 'products', v: { ...p, stock: want } }]);
    }
  }
}
