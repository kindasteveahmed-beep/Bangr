// Configuration Firebase (non secrète : la protection repose sur les règles Firestore).
export const FIREBASE = { apiKey: 'AIzaSyDnnZlastYgr1Tm8PuZOL25APWfajEilAw', projectId: 'rood-woko-403be' };
