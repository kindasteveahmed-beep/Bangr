import { useState } from 'react';
import type { Cloud } from '../sync/cloud.ts';
import type { LicenseService } from '../license/service.ts';
import type { Gate } from '../license/model.ts';

const MSG: Record<string, string> = {
  none: '',
  expired: 'Ton abonnement a expiré. Entre un nouveau code pour continuer.',
  revoked: 'Ton accès a été suspendu. Contacte ton fournisseur.',
  device: 'Ce compte est déjà utilisé sur le nombre maximum d’appareils autorisés. Contacte ton fournisseur pour libérer un appareil.',
  clock: 'La date ou l’heure de ton appareil semble incorrecte. Remets la date et l’heure automatiques, puis réessaie.',
  online: 'Une connexion internet est nécessaire pour vérifier ton accès.',
};
interface P { cloud: Cloud; svc: LicenseService; gate: Gate; deviceId: string; error: string; onDone: () => Promise<void>; refresh: () => void }

export default function Activation({ cloud, svc, gate, deviceId, error, onDone, refresh }: P) {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [code, setCode] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async (fn: () => Promise<void>) => {
    setBusy(true); setInfo('');
    try { await fn(); } catch (e) { setInfo(e instanceof Error ? e.message : 'Erreur inattendue.'); }
    setBusy(false); refresh();
  };
  const s = cloud.session;
  const m = MSG[gate.state] ?? '';
  const canEnter = gate.state === 'none' || gate.state === 'expired';
  return (
    <div className="card">
      <h2>Activation de BÃNGR</h2>
      {m && <p className="red">{m}</p>}
      {error && <p className="red">{error}</p>}
      {info && <p className="red">{info}</p>}
      {!s ? <>
        <p className="k">Connecte-toi (ou crée ton compte) avec ton adresse e-mail, puis entre le code d’activation que ton fournisseur t’a remis.</p>
        <label>Adresse e-mail<input type="email" autoCapitalize="off" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label>Mot de passe (6 caractères minimum)<input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></label>
        <button className="primary" disabled={busy} onClick={() => go(async () => { await cloud.signIn(email, pw); await onDone(); })}>Se connecter</button>
        <button className="ghost" disabled={busy} onClick={() => go(async () => { await cloud.signUp(email, pw); await onDone(); })}>Créer mon compte (première fois)</button>
        <button className="ghost" disabled={busy} onClick={() => go(async () => { await cloud.resetPassword(email); setInfo('Un e-mail pour changer ton mot de passe a été envoyé (regarde aussi dans les spams).'); })}>Mot de passe oublié</button>
      </> : <>
        <p>Connecté avec : <b>{s.email}</b></p>
        {canEnter && <>
          <label>Code d’activation<input value={code} autoCapitalize="characters" autoCorrect="off" placeholder="XXXX-XXXX-XXXX" onChange={(e) => setCode(e.target.value)} /></label>
          <button className="primary" disabled={busy || !code.trim()} onClick={() => go(async () => { await svc.redeem(code, deviceId); setCode(''); await onDone(); })}>Activer</button>
        </>}
        <button className="ghost" disabled={busy} onClick={() => go(onDone)}>Vérifier à nouveau</button>
        <button className="ghost" onClick={() => { if (confirm('Te déconnecter ?')) { cloud.signOut(); refresh(); void onDone(); } }}>Se déconnecter</button>
      </>}
      <p className="k">Pas de code ? Contacte ton fournisseur.</p>
      <p className="k"><a href="./confidentialite.html">Politique de confidentialité</a></p>
    </div>
  );
}
