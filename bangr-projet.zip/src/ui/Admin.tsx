import { useEffect, useState } from 'react';
import type { LicenseService, CodeRow, LicenseRow } from '../license/service.ts';
import { daysLeft, expiresAt } from '../license/model.ts';

const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'Erreur inattendue.');
const date = (ms: number) => new Date(ms).toLocaleDateString('fr-FR');

export default function Admin({ svc }: { svc: LicenseService }) {
  const [codes, setCodes] = useState<CodeRow[]>([]);
  const [lics, setLics] = useState<LicenseRow[]>([]);
  const [days, setDays] = useState('30');
  const [dev, setDev] = useState('1');
  const [note, setNote] = useState('');
  const [last, setLast] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const load = async () => { try { const [c, l] = await Promise.all([svc.listCodes(), svc.listLicenses()]); setCodes(c); setLics(l); } catch (e) { setInfo(errMsg(e)); } };
  useEffect(() => { void load(); }, []);
  const run = async (fn: () => Promise<unknown>) => { setBusy(true); setInfo(''); try { await fn(); await load(); } catch (e) { setInfo(errMsg(e)); } setBusy(false); };
  const text = (c: string, d: number) => `Ton code d’activation BÃNGR : ${c}\nValable ${d} jours à partir de l’activation.`;
  const now = Date.now();
  return (
    <div className="card">
      <h2>Administration des codes</h2>
      {info && <p className="red">{info}</p>}
      <div className="two">
        <label>Durée (jours)<select value={days} onChange={(e) => setDays(e.target.value)}>{['7', '30', '90', '180', '365'].map((d) => <option key={d} value={d}>{d}</option>)}</select></label>
        <label>Appareils max<select value={dev} onChange={(e) => setDev(e.target.value)}>{['1', '2', '3', '5'].map((d) => <option key={d} value={d}>{d}</option>)}</select></label>
      </div>
      <label>Pour qui ? (nom du client, pour t’y retrouver)<input value={note} onChange={(e) => setNote(e.target.value)} /></label>
      <button className="primary" disabled={busy} onClick={() => run(async () => setLast(await svc.createCode({ days: Number(days), maxDevices: Number(dev), note })))}>Générer un code</button>
      {last && <div className="card">
        <b style={{ fontSize: 20, letterSpacing: 1 }}>{last}</b>
        <div><button className="ghost" onClick={() => { void navigator.clipboard?.writeText(text(last, Number(days))); alert('Code copié.'); }}>Copier</button>
          <button className="ghost" onClick={() => window.open('https://wa.me/?text=' + encodeURIComponent(text(last, Number(days))), '_blank')}>WhatsApp</button></div>
      </div>}
      <h2>Codes ({codes.length})</h2>
      {codes.map((c) => <div className="row small" key={c.code}>
        <span><b>{c.code}</b>{c.revoked ? ' · annulé' : ''}<br /><span className="k">{c.note || 'sans nom'} · {c.days} j · {c.maxDevices} appareil(s) · {c.usedBy ? 'utilisé par ' + c.usedBy : 'libre'}</span></span>
        {!c.usedBy && <button className="ghost" disabled={busy} onClick={() => run(() => svc.setCodeRevoked(c.code, !c.revoked))}>{c.revoked ? 'Rétablir' : 'Annuler'}</button>}
      </div>)}
      <h2>Clients activés ({lics.length})</h2>
      {lics.map((l) => <div className="card" key={l.uid}>
        <b>{l.email}</b>{l.revoked ? <span className="red"> · suspendu</span> : ''}
        <div className="k">{daysLeft(l, now) > 0 ? `Expire le ${date(expiresAt(l))} (${daysLeft(l, now)} j)` : `Expiré le ${date(expiresAt(l))}`} · appareils {l.devices.length}/{l.maxDevices}</div>
        <button className="ghost" disabled={busy} onClick={() => run(() => svc.extend(l.uid, 30))}>+30 jours</button>
        <button className="ghost" disabled={busy} onClick={() => run(() => svc.resetDevices(l.uid))}>Libérer les appareils</button>
        <button className="ghost" disabled={busy} onClick={() => run(() => svc.setLicenseRevoked(l.uid, !l.revoked))}>{l.revoked ? 'Rétablir' : 'Suspendre'}</button>
      </div>)}
    </div>
  );
}
