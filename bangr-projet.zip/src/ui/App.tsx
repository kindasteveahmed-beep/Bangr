import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { IdbRepo } from '../data/idb.ts';
import { Cloud } from '../sync/cloud.ts';
import { FIREBASE } from '../sync/config.ts';
import { useData } from './useData.ts';
import type { Props } from './useData.ts';
import Dashboard from './Dashboard.tsx';
import Products from './Products.tsx';
import Sales from './Sales.tsx';
import Stock from './Stock.tsx';
import Compte from './Compte.tsx';

const TABS = [['dash', 'Accueil', '🏠'], ['prod', 'Produits', '🏷️'], ['sale', 'Vendre', '🧾'], ['stock', 'Stock', '📦'], ['compte', 'Compte', '☁️']] as const;
const KV = { get: (k: string) => localStorage.getItem(k), set: (k: string, v: string) => localStorage.setItem(k, v), del: (k: string) => localStorage.removeItem(k) };
const CHIP: Record<string, string> = { local: '📱 Local', busy: '☁ …', ok: '☁ Synchronisé', err: '⚠ Erreur synchro' };

export default function App() {
  const repo = useMemo(() => new IdbRepo(), []);
  const cloud = useMemo(() => new Cloud(FIREBASE, KV), []);
  const data = useData(repo);
  const reload = data.reload;
  const [tab, setTab] = useState<string>('dash');
  const [st, setSt] = useState<string>(cloud.session ? 'busy' : 'local');
  const [msg, setMsg] = useState('');
  const [, setTick] = useState(0);
  const busy = useRef(false);

  const run = useCallback(async () => {
    if (!cloud.session || busy.current) return;
    busy.current = true; setSt('busy');
    try { await cloud.sync(repo); await reload(); setSt('ok'); setMsg(''); }
    catch (e) { setSt('err'); setMsg(e instanceof Error ? e.message : 'Erreur'); }
    busy.current = false;
  }, [cloud, repo, reload]);

  useEffect(() => { run(); const h = () => { run(); }; addEventListener('online', h); return () => removeEventListener('online', h); }, [run]);

  const act: Props['act'] = async (fn) => {
    try { await fn(); await reload(); run(); } catch (e) { alert(e instanceof Error ? e.message : 'Erreur inattendue.'); }
  };
  const onAuth = async () => { await repo.markAllDirty(); await run(); };
  const p: Props = { repo, data, act };
  const chip = cloud.session ? CHIP[st] : CHIP.local;
  return (
    <div className="app">
      <header><div className="star">★</div><div className="grow"><h1>BÃNGR</h1><small>Ma boutique, bien gérée.</small></div><button className="chip" onClick={() => setTab('compte')}>{chip}</button></header>
      <main>
        {!data.ready ? <p>Chargement…</p> : tab === 'dash' ? <Dashboard {...p} /> : tab === 'prod' ? <Products {...p} /> : tab === 'sale' ? <Sales {...p} /> : tab === 'stock' ? <Stock {...p} /> : <Compte cloud={cloud} state={st} msg={msg} run={run} onAuth={onAuth} refresh={() => setTick((n) => n + 1)} />}
      <p className="k ver">BÃNGR · version 0.3</p>
      </main>
      <nav>{TABS.map(([id, label, icon]) => <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}><span>{icon}</span>{label}</button>)}</nav>
    </div>
  );
}
