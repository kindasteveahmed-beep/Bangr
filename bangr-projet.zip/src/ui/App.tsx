import { useMemo, useState } from 'react';
import { IdbRepo } from '../data/idb.ts';
import { useData } from './useData.ts';
import type { Props } from './useData.ts';
import Dashboard from './Dashboard.tsx';
import Products from './Products.tsx';
import Sales from './Sales.tsx';
import Stock from './Stock.tsx';

const TABS = [['dash', 'Accueil', '🏠'], ['prod', 'Produits', '🏷️'], ['sale', 'Vendre', '🧾'], ['stock', 'Stock', '📦']] as const;

export default function App() {
  const repo = useMemo(() => new IdbRepo(), []);
  const data = useData(repo);
  const [tab, setTab] = useState<string>('dash');
  const act: Props['act'] = async (fn) => {
    try { await fn(); await data.reload(); } catch (e) { alert(e instanceof Error ? e.message : 'Erreur inattendue.'); }
  };
  const p: Props = { repo, data, act };
  return (
    <div className="app">
      <header><div className="star">★</div><div><h1>BÃNGR</h1><small>Ma boutique, bien gérée.</small></div></header>
      <main>
        {!data.ready ? <p>Chargement…</p> : tab === 'dash' ? <Dashboard {...p} /> : tab === 'prod' ? <Products {...p} /> : tab === 'sale' ? <Sales {...p} /> : <Stock {...p} />}
      </main>
      <nav>{TABS.map(([id, label, icon]) => <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}><span>{icon}</span>{label}</button>)}</nav>
    </div>
  );
}
