import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { IdbRepo } from '../data/idb.ts';
import { localKV } from '../data/settings.ts';
import { Cloud } from '../sync/cloud.ts';
import { FIREBASE } from '../sync/config.ts';
import { LicenseService } from '../license/service.ts';
import { evaluate } from '../license/model.ts';
import type { Gate } from '../license/model.ts';
import { getDeviceId, loadState, saveState } from '../license/store.ts';
import { LICENSE_REQUIRED } from '../license/config.ts';
import { useData } from './useData.ts';
import type { Props } from './useData.ts';
import Dashboard from './Dashboard.tsx';
import Products from './Products.tsx';
import Sales from './Sales.tsx';
import Stock from './Stock.tsx';
import Clients from './Clients.tsx';
import Plus from './Plus.tsx';
import Compte from './Compte.tsx';
import Activation from './Activation.tsx';

const TABS = [['dash', 'Accueil', '🏠'], ['prod', 'Produits', '🏷️'], ['sale', 'Vendre', '🧾'], ['stock', 'Stock', '📦'], ['client', 'Clients', '👥'], ['plus', 'Plus', '➕'], ['compte', 'Compte', '☁️']] as const;
const KV = { get: (k: string) => localStorage.getItem(k), set: (k: string, v: string) => localStorage.setItem(k, v), del: (k: string) => localStorage.removeItem(k) };
const CHIP: Record<string, string> = { local: '📱 Local', busy: '☁ …', ok: '☁ Synchronisé', err: '⚠ Erreur synchro' };
const platform = () => ((window as any).Capacitor ? 'Android' : /Electron/i.test(navigator.userAgent) ? 'Windows' : 'Navigateur');

export default function App() {
  const repo = useMemo(() => new IdbRepo(), []);
  const cloud = useMemo(() => new Cloud(FIREBASE, KV), []);
  const svc = useMemo(() => new LicenseService(cloud), [cloud]);
  const deviceId = useMemo(() => getDeviceId(localKV, platform()), []);
  const data = useData(repo);
  const reload = data.reload;
  const [tab, setTab] = useState<string>('dash');
  const [st, setSt] = useState<string>(cloud.session ? 'busy' : 'local');
  const [msg, setMsg] = useState('');
  const [, setTick] = useState(0);
  const [gate, setGate] = useState<Gate>(() => evaluate(loadState(localKV), cloud.session?.uid ?? null, deviceId, Date.now()));
  const [checkErr, setCheckErr] = useState('');
  const busy = useRef(false);

  // Vérifie l'accès (abonnement, appareil) : en ligne si possible, sinon avec l'état enregistré.
  const recheck = useCallback(async () => {
    const s = cloud.session; setCheckErr('');
    if (s) {
      try {
        const { license, admin } = await svc.refresh(deviceId);
        const now = Date.now(); const old = loadState(localKV);
        saveState(localKV, { uid: s.uid, license, admin, verifiedAt: now, lastSeen: Math.max(now, old && old.uid === s.uid ? old.lastSeen : 0) });
      } catch (e) { const m = e instanceof Error ? e.message : ''; if (m && !m.startsWith('Pas de connexion')) setCheckErr(m); }
    }
    const cur = loadState(localKV);
    if (cur) saveState(localKV, { ...cur, lastSeen: Math.max(cur.lastSeen, Date.now()) });
    setGate(evaluate(loadState(localKV), cloud.session?.uid ?? null, deviceId, Date.now()));
  }, [cloud, svc, deviceId]);
  useEffect(() => { void recheck(); const h = () => { void recheck(); }; addEventListener('online', h); const iv = setInterval(h, 6 * 3600 * 1000); return () => { removeEventListener('online', h); clearInterval(iv); }; }, [recheck]);

  const run = useCallback(async () => {
    if (!cloud.session || busy.current) return;
    busy.current = true; setSt('busy');
    try { await cloud.sync(repo); await reload(); setSt('ok'); setMsg(''); }
    catch (e) { setSt('err'); setMsg(e instanceof Error ? e.message : 'Erreur'); }
    busy.current = false;
  }, [cloud, repo, reload]);
  useEffect(() => { run(); const h = () => { run(); }; addEventListener('online', h); return () => removeEventListener('online', h); }, [run]);

  const act: Props['act'] = async (fn) => {
    try { await fn(); await reload(); run(); } catch (e) { alert(e instanceof Error ? e.message : 'Erreur inattendue.'); }
  };
  const onAuth = async () => { await repo.markAllDirty(); await recheck(); await run(); };
  const p: Props = { repo, data, act };
  const locked = LICENSE_REQUIRED && gate.state !== 'ok';
  const chip = cloud.session ? CHIP[st] : CHIP.local;
  const soon = gate.state === 'ok' && !gate.admin && gate.daysLeft !== null && gate.daysLeft <= 7;
  return (
    <div className="app">
      <header><div className="star">★</div><div className="grow"><h1>BÃNGR</h1><small>Ma boutique, bien gérée.</small></div>{!locked && <button className="chip" onClick={() => setTab('compte')}>{chip}</button>}</header>
      <main>
        {locked ? <Activation cloud={cloud} svc={svc} gate={gate} deviceId={deviceId} error={checkErr} onDone={recheck} refresh={() => setTick((n) => n + 1)} />
          : !data.ready ? <p>Chargement…</p> : <>
            {soon && <div className="card"><b className="red">Ton abonnement expire dans {gate.daysLeft} jour(s).</b><div className="k">Demande un nouveau code à ton fournisseur, puis entre-le dans l’onglet Compte.</div></div>}
            {tab === 'dash' ? <Dashboard {...p} /> : tab === 'prod' ? <Products {...p} /> : tab === 'sale' ? <Sales {...p} /> : tab === 'stock' ? <Stock {...p} /> : tab === 'client' ? <Clients {...p} /> : tab === 'plus' ? <Plus {...p} /> : <Compte cloud={cloud} state={st} msg={msg} run={run} onAuth={onAuth} refresh={() => setTick((n) => n + 1)} svc={svc} gate={gate} lic={loadState(localKV)} />}
          </>}
        <p className="k ver">BÃNGR · version 0.9</p>
      </main>
      {!locked && <nav>{TABS.map(([id, label, icon]) => <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}><span>{icon}</span>{label}</button>)}</nav>}
    </div>
  );
}
