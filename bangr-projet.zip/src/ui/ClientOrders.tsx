import { useState } from 'react';
import { clientOrdersDue, collectClientOrder, createClientOrder, dayMs, deleteClientOrder, deliverClientOrder } from '../domain/purchasing.ts';
import { fcfa } from '../domain/money.ts';
import type { Props } from './useData.ts';

const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
const day = (t: number) => new Date(t).toLocaleDateString('fr-FR');
const ymdToday = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

export default function ClientOrders({ repo, data, act }: Props) {
  const [open, setOpen] = useState(false);
  const [client, setClient] = useState(''); const [item, setItem] = useState(''); const [total, setTotal] = useState(''); const [adv, setAdv] = useState(''); const [due, setDue] = useState('');
  const [payFor, setPayFor] = useState(''); const [amt, setAmt] = useState('');
  const save = () => act(async () => {
    const known = data.customers.find((c) => c.name.trim().toLowerCase() === client.trim().toLowerCase());
    await createClientOrder(repo, { customer: client, customerId: known?.id, item, total: Number(total), advance: adv === '' ? 0 : Number(adv), dueDate: dayMs(due) });
    setClient(''); setItem(''); setTotal(''); setAdv(''); setDue(''); setOpen(false);
  });
  const list = data.clientOrders.filter((o) => !o.deleted).sort((a, b) => (a.status === b.status ? b.at - a.at : a.status === 'EN_ATTENTE' ? -1 : 1));
  const due$ = clientOrdersDue(list);
  return (
    <>
      <button className="primary" onClick={() => setOpen(!open)}>{open ? 'Fermer' : '+ Nouvelle commande'}</button>
      {open && (
        <div className="card up">
          <h2 className="m0">Nouvelle commande</h2>
          <label>Client<input list="clients-liste" value={client} onChange={(e) => setClient(e.target.value)} /></label>
          <datalist id="clients-liste">{data.customers.map((c) => <option key={c.id} value={c.name} />)}</datalist>
          <label>Article commandé<input value={item} onChange={(e) => setItem(e.target.value)} /></label>
          <label>Prix total<input inputMode="numeric" value={total} onChange={(e) => setTotal(e.target.value)} /></label>
          <label>Avance reçue<input inputMode="numeric" value={adv} onChange={(e) => setAdv(e.target.value)} /></label>
          <label>Date de livraison<input type="date" min={ymdToday()} value={due} onChange={(e) => setDue(e.target.value)} /></label>
          <button className="primary" onClick={save}>Enregistrer</button>
          <button className="ghost wide" onClick={() => setOpen(false)}>Annuler</button>
        </div>
      )}
      {list.length > 0 && <div className="row sumline"><span className="k">Reste à encaisser sur les commandes</span><b className={due$ > 0 ? 'red' : ''}>{fcfa(due$)}</b></div>}
      {list.length === 0 && <p className="k">Aucune commande de client. Appuie sur « + Nouvelle commande ».</p>}
      {list.map((o) => {
        const rest = o.total - o.advance; const late = o.status === 'EN_ATTENTE' && o.dueDate !== undefined && o.dueDate < startOfToday();
        return (
          <div className="card" key={o.id}>
            <div className="row"><b>{o.customer}</b><b>{fcfa(o.total)}</b></div>
            <div>{o.item}</div>
            <div className="k">{o.number} · {o.status === 'LIVREE' ? '✅ Livrée' + (o.deliveredAt ? ' le ' + day(o.deliveredAt) : '') : '⏳ À livrer'}{o.dueDate !== undefined && o.status === 'EN_ATTENTE' ? ' · Livraison : ' + day(o.dueDate) : ''}</div>
            {late && <div className="red">Livraison en retard</div>}
            <div className={rest > 0 ? 'red' : 'green'}>{rest > 0 ? `Avance reçue : ${fcfa(o.advance)} · Reste : ${fcfa(rest)}` : 'Payée en totalité'}</div>
            <div className="rcpt-actions">
              {rest > 0 && <button className="ghost" onClick={() => { setPayFor(payFor === o.id ? '' : o.id); setAmt(''); }}>💰 Encaisser</button>}
              {o.status === 'EN_ATTENTE' && <button className="ghost" onClick={() => { if (confirm('Marquer cette commande comme livrée ?')) act(() => deliverClientOrder(repo, o.id)); }}>✅ Livrée</button>}
              <button className="ghost" onClick={() => { if (confirm(`Supprimer la commande ${o.number} ?\n\nCette action est définitive.`)) act(() => deleteClientOrder(repo, o.id)); }}>🗑 Supprimer</button>
            </div>
            {payFor === o.id && (
              <div className="subcard">
                <label>Montant reçu (vide = tout le reste : {fcfa(rest)})<input inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value)} /></label>
                <button className="primary" onClick={() => act(async () => { await collectClientOrder(repo, o.id, amt === '' ? rest : Number(amt)); setPayFor(''); setAmt(''); })}>Valider</button>
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}
