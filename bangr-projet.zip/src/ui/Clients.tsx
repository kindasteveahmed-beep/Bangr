import { useState } from 'react';
import { createCustomer, updateCustomer, recordDebtPayment, customerBalance } from '../domain/services.ts';
import { fcfa } from '../domain/money.ts';
import { PAYMENT_LABEL, PAYMENT_METHODS } from '../domain/payments.ts';
import type { Customer, PaymentMethod } from '../domain/types.ts';
import type { Props } from './useData.ts';

const empty = { name: '', phone: '', address: '', notes: '' };

export default function Clients({ repo, data, act }: Props) {
  const [f, setF] = useState(empty);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<string | null>(null);
  const [payFor, setPayFor] = useState<string | null>(null);
  const [amt, setAmt] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('ESPECES');
  const set = (k: keyof typeof empty) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const add = () => act(async () => { await createCustomer(repo, f); setF(empty); });
  const edit = (c: Customer) => {
    const name = prompt('Nom du client', c.name); if (name === null) return;
    const phone = prompt('Téléphone', c.phone); if (phone === null) return;
    const address = prompt('Adresse', c.address); if (address === null) return;
    act(() => updateCustomer(repo, c.id, { name, phone, address, notes: c.notes }));
  };
  const pay = (c: Customer) => act(async () => {
    await recordDebtPayment(repo, c.id, Number(amt), method);
    setPayFor(null); setAmt(''); alert('Paiement enregistré.');
  });
  const term = q.trim().toLowerCase();
  const list = data.customers.filter((c) => (c.name + ' ' + c.phone).toLowerCase().includes(term)).sort((a, b) => a.name.localeCompare(b.name));
  const owedAll = data.customers.reduce((t, c) => t + customerBalance(data.sales, c.id), 0);
  return (
    <>
      <div className="card">
        <h2>Nouveau client</h2>
        <label>Nom<input value={f.name} onChange={set('name')} /></label>
        <label>Téléphone<input inputMode="tel" value={f.phone} onChange={set('phone')} /></label>
        <label>Adresse (facultatif)<input value={f.address} onChange={set('address')} /></label>
        <label>Remarque (facultatif)<input value={f.notes} onChange={set('notes')} /></label>
        <button className="primary" onClick={add}>Enregistrer le client</button>
      </div>
      <h2>Mes clients ({data.customers.length}){owedAll > 0 ? ' · ils te doivent ' + fcfa(owedAll) : ''}</h2>
      {data.customers.length > 0 && <input placeholder="Rechercher un nom ou un numéro" value={q} onChange={(e) => setQ(e.target.value)} />}
      {data.customers.length === 0 && <p className="k">Aucun client enregistré.</p>}
      {list.map((c) => {
        const bal = customerBalance(data.sales, c.id);
        const sales = data.sales.filter((s) => s.customerId === c.id).sort((a, b) => b.at - a.at);
        const bought = sales.filter((s) => s.status === 'VALIDEE').reduce((t, s) => t + s.total, 0);
        return (
          <div className="card" key={c.id}>
            <div className="row" onClick={() => setOpen(open === c.id ? null : c.id)}><b>{c.name}</b>{bal > 0 ? <b className="red">Doit {fcfa(bal)}</b> : <span className="k">À jour</span>}</div>
            <div className="k">{c.phone || 'Pas de numéro'}{c.address ? ' · ' + c.address : ''}</div>
            {open === c.id && <>
              <div className="k">Total des achats : {fcfa(bought)} · {sales.length} vente(s)</div>
              {c.notes && <div className="k">Remarque : {c.notes}</div>}
              {sales.slice(0, 10).map((s) => <div className="row small" key={s.id}><span>{s.number} · {new Date(s.at).toLocaleDateString('fr-FR')}{s.status === 'ANNULEE' ? ' · annulée' : ''}</span><span>{fcfa(s.total)}{s.status === 'VALIDEE' && s.total > s.paid ? ' (reste ' + fcfa(s.total - s.paid) + ')' : ''}</span></div>)}
              {c.phone && <a className="ghost" href={'tel:' + c.phone.replace(/\s/g, '')}>📞 Appeler</a>}
              <button className="ghost" onClick={() => edit(c)}>Modifier</button>
              {bal > 0 && <button className="ghost" onClick={() => { setPayFor(payFor === c.id ? null : c.id); setAmt(String(bal)); }}>Encaisser un paiement</button>}
              {payFor === c.id && <div className="card">
                <label>Montant reçu (FCFA)<input inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value)} /></label>
                <label>Mode de paiement<select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{PAYMENT_LABEL[m]}</option>)}</select></label>
                <button className="primary" onClick={() => pay(c)}>Valider le paiement</button>
              </div>}
            </>}
          </div>
        );
      })}
    </>
  );
}
