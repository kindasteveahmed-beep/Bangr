import { useState } from 'react';
import type { Cloud } from '../sync/cloud.ts';
import type { LicenseService } from '../license/service.ts';
import type { Gate, LocalState } from '../license/model.ts';
import { daysLeft, expiresAt } from '../license/model.ts';
import Admin from './Admin.tsx';

export interface CompteProps { cloud: Cloud; state: string; msg: string; run: () => Promise<void>; onAuth: () => Promise<void>; refresh: () => void; svc: LicenseService; gate: Gate; lic: LocalState | null }
const LABEL: Record<string, string> = { local: 'Données sur ce téléphone uniquement', busy: 'Synchronisation en cours…', ok: 'Synchronisé ✅', err: 'Erreur de synchronisation ⚠️' };

export default function Compte({ cloud, state, msg, run, onAuth, refresh, svc, gate, lic }: CompteProps) {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  const [del, setDel] = useState(false);
  const go = async (fn: () => Promise<void>) => {
    setBusy(true); setInfo('');
    try { await fn(); } catch (e) { setInfo(e instanceof Error ? e.message : 'Erreur inattendue.'); }
    setBusy(false); refresh();
  };
  const s = cloud.session;
  if (s) return (
    <>
    <div className="card">
      <h2>Mon compte</h2>
      <p>Connecté avec : <b>{s.email}</b></p>
      {gate.state === 'ok' && gate.admin && <p className="k">Compte administrateur.</p>}
      {gate.state === 'ok' && !gate.admin && lic?.license && <p className="k">Abonnement actif jusqu’au {new Date(expiresAt(lic.license)).toLocaleDateString('fr-FR')} ({daysLeft(lic.license, Date.now())} jours) · appareils {lic.license.devices.length}/{lic.license.maxDevices}</p>}
      <p className="k">Identifiant du compte : <b style={{ wordBreak: 'break-all' }}>{s.uid}</b> <button className="ghost" onClick={() => { void navigator.clipboard?.writeText(s.uid); alert('Identifiant copié.'); }}>Copier</button></p>
      <p className="k">{LABEL[state] ?? ''}{msg ? ' – ' + msg : ''}</p>
      <p className="k">Tes données sont sauvegardées en ligne. Sur un autre téléphone, connecte-toi avec la même adresse pour les retrouver.</p>
      <button className="primary" disabled={busy || state === 'busy'} onClick={() => go(run)}>Synchroniser maintenant</button>
      <button className="ghost" onClick={() => { if (confirm('Te déconnecter ? Tes données restent sur ce téléphone.')) { cloud.signOut(); refresh(); } }}>Se déconnecter</button>
      <h2>Supprimer mon compte</h2>
      <p className="k">Efface ton compte et toutes tes données en ligne, définitivement. Les données de ce téléphone restent.</p>
      {!del ? <button className="ghost" onClick={() => setDel(true)}>Supprimer mon compte…</button> : <>
        <label>Mot de passe pour confirmer<input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></label>
        {info && <p className="red">{info}</p>}
        <button className="primary danger" disabled={busy} onClick={() => go(async () => { await cloud.deleteAccount(pw); setDel(false); setPw(''); alert('Ton compte et tes données en ligne ont été supprimés.'); })}>Oui, supprimer définitivement</button>
        <button className="ghost" onClick={() => { setDel(false); setInfo(''); }}>Annuler</button>
      </>}
      <p className="k"><a href="./confidentialite.html">Politique de confidentialité</a></p>
    </div>
    {gate.state === 'ok' && gate.admin && <Admin svc={svc} />}
    </>
  );
  return (
    <div className="card">
      <h2>Sauvegarder mes données en ligne</h2>
      <p className="k">Crée un compte avec ton adresse e-mail pour ne jamais perdre tes données et les retrouver sur un autre téléphone. Tout continue de marcher sans connexion.</p>
      <label>Adresse e-mail<input type="email" autoCapitalize="off" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
      <label>Mot de passe (6 caractères minimum)<input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></label>
      {info && <p className="red">{info}</p>}
      <button className="primary" disabled={busy} onClick={() => go(async () => { await cloud.signIn(email, pw); await onAuth(); })}>Se connecter</button>
      <button className="ghost" disabled={busy} onClick={() => go(async () => { await cloud.signUp(email, pw); await onAuth(); })}>Créer mon compte (première fois)</button>
      <button className="ghost" disabled={busy} onClick={() => go(async () => { await cloud.resetPassword(email); setInfo('Un e-mail pour changer ton mot de passe a été envoyé (regarde aussi dans les spams).'); })}>Mot de passe oublié</button>
      <p className="k"><a href="./confidentialite.html">Politique de confidentialité</a></p>
    </div>
  );
}
