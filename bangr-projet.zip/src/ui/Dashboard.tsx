import { computeStats } from '../domain/stats.ts';
import { fcfa } from '../domain/money.ts';
import { PAYMENT_LABEL } from '../domain/payments.ts';
import type { PaymentMethod } from '../domain/types.ts';
import { loadHeader, localKV } from '../data/settings.ts';
import Icon from './icons.tsx';
import type { Props } from './useData.ts';

type Go = (tab: string, sub?: string) => void;
const Amount = ({ n }: { n: number }) => { const t = fcfa(n); const i = t.lastIndexOf(' '); return <div className="v">{t.slice(0, i)} <span className="u">{t.slice(i + 1)}</span></div>; };

function Card({ tone, icon, k, n, sub, wide, to, go }: { tone: string; icon: string; k: string; n: number; sub?: string; wide?: boolean; to?: [string, string?]; go: Go }) {
  return (
    <div className={`sc ${tone}${wide ? ' wide' : ''}`} onClick={to ? () => go(to[0], to[1]) : undefined}>
      <div className="ic"><Icon name={icon} size={20} /></div>
      <div className="tx"><div className="k">{k}</div><Amount n={n} />{sub && <div className="sub">{sub}</div>}</div>
      {wide && <span className="chev"><Icon name="right" size={18} /></span>}
    </div>
  );
}
const Shop = () => (
  <svg className="art" viewBox="0 0 130 120" aria-hidden="true">
    <ellipse cx="65" cy="112" rx="52" ry="6" fill="rgba(0,0,0,.18)" />
    <path d="M96 100c-2-26 6-40 20-48-4 20-8 34-20 48z" fill="#7bc043" /><path d="M104 100c8-14 16-22 22-24-2 14-10 22-22 24z" fill="#5aa02c" />
    <rect x="24" y="52" width="76" height="52" rx="4" fill="#fbf3dc" />
    <rect x="34" y="66" width="28" height="22" rx="3" fill="#1f9d57" /><rect x="68" y="62" width="22" height="42" rx="3" fill="#14804a" /><circle cx="73" cy="84" r="1.8" fill="#f6d365" />
    <path d="M26 24h72l8 8H18z" fill="#e9852a" />
    {[0, 1, 2, 3, 4].map((i) => <rect key={'s' + i} x={18 + i * 17.6} y="32" width="17.6" height="22" fill={i % 2 ? '#fff8e8' : '#f6b73c'} />)}
    {[0, 1, 2, 3, 4].map((i) => <circle key={'c' + i} cx={26.8 + i * 17.6} cy="54" r="8.8" fill={i % 2 ? '#fff8e8' : '#f6b73c'} />)}
  </svg>
);

export default function Dashboard({ data, go }: Props & { go: Go }) {
  const shop = loadHeader(localKV).shop.trim();
  const hello = (new Date().getHours() >= 18 ? 'Bonsoir' : 'Bonjour') + (shop ? ' ' + shop : '');
  const hero = <div className="hero"><h2>{hello}</h2><p>Voici un aperçu de ton activité aujourd’hui</p><Shop /></div>;
  if (!data.products.some((p) => p.active)) return <>{hero}<div className="card up"><h2>Bienvenue sur BÃNGR</h2><p>Aucun produit pour l’instant. Ouvre l’onglet « Produits » pour ajouter ceux de ta boutique. Tes chiffres apparaîtront ici dès ta première vente.</p></div></>;
  const s = computeStats(data, Date.now());
  const low = s.lowStock;
  return (
    <>
      {hero}
      <div className="cards">
        <Card go={go} tone="green" icon="dollar" k="Ventes du mois" n={s.month.revenue} sub={`Marge : ${fcfa(s.month.margin)}`} to={['sale']} />
        <Card go={go} tone="blue" icon="wallet" k="Encaissé aujourd’hui" n={s.day.cashIn} to={['sale']} />
        <Card go={go} tone="lime" icon="trend" k="Ventes du jour" n={s.day.revenue} sub={`${s.day.count} vente(s)`} to={['sale']} />
        <Card go={go} tone="amber" icon="pie" k="Marge du jour" n={s.day.margin} />
        <Card go={go} tone="purple" icon="card" k="Crédits à recevoir" n={s.receivables} to={['client']} />
        <Card go={go} tone="orange" icon="cart" k="Dépenses du mois" n={s.month.expenses} sub={`Aujourd’hui : ${fcfa(s.day.expenses)}`} to={['plus', 'dep']} />
        <Card go={go} tone="teal" icon="box" k="Stock" n={s.stockValue} sub="Au prix d’achat" to={['plus', 'stock']} />
        <Card go={go} tone="pink" icon="pie" k="Bénéfice net du mois" n={s.month.profit} sub="Marge − dépenses (hors marchandise)" />
        <Card go={go} tone="green" icon="doc" k="Dettes fournisseurs" n={s.payables} wide to={['plus', 'four']} />
      </div>
      <div className="banner"><div className="bic"><Icon name="zap" size={22} /></div><div><b>{s.day.cashIn > 0 ? `Encaissé aujourd’hui : ${fcfa(s.day.cashIn)}` : 'Aucun encaissement aujourd’hui'}</b><div>{s.day.cashIn > 0 ? 'Bravo, continue comme ça !' : 'Continuez, chaque vente compte !'}</div></div></div>
      <div className="sec"><h3>Actions rapides</h3></div>
      <div className="quick">
        {([['bag', 'Nouvelle vente', 'green', 'sale', ''], ['tag', 'Ajouter un produit', 'orange', 'prod', ''], ['users', 'Mes clients', 'blue', 'client', ''], ['box', 'Stock', 'purple', 'plus', 'stock'], ['wallet', 'Dépenses', 'pink', 'plus', 'dep']] as const).map(([ic, label, tone, t, sub]) => (
          <button key={label} className="qa" onClick={() => go(t, sub)}><span className={'qi ' + tone}><Icon name={ic} size={22} /></span>{label}</button>
        ))}
      </div>
      <div className="card">
        <div className="sec in"><h3><span className={'qi amber sm'}><Icon name="alert" size={16} /></span> Stock bas {low.length > 0 && <span className="badge">{low.length} produit{low.length > 1 ? 's' : ''}</span>}</h3><button className="link" onClick={() => go('plus', 'stock')}>Voir tout <Icon name="right" size={14} /></button></div>
        {low.length === 0 ? <p className="k">Aucun produit en alerte.</p> : low.slice(0, 5).map((p) => <div className="row" key={p.id}><span>{p.name}</span><b className="red">{p.stock} {p.unit}</b></div>)}
      </div>
      <div className="card">
        <h2 className="m0">Encaissé aujourd’hui par mode</h2>
        {Object.keys(s.day.byMethod).length === 0 ? <p className="k">Aucun encaissement aujourd’hui.</p> : Object.entries(s.day.byMethod).map(([m, v]) => <div className="row" key={m}><span>{PAYMENT_LABEL[m as PaymentMethod]}</span><b>{fcfa(v)}</b></div>)}
      </div>
    </>
  );
}
