import { computeStats } from '../domain/stats.ts';
import { fcfa } from '../domain/money.ts';
import { PAYMENT_LABEL } from '../domain/payments.ts';
import type { PaymentMethod } from '../domain/types.ts';
import type { Props } from './useData.ts';

const Stat = ({ k, v, sub, tone }: { k: string; v: string; sub?: string; tone?: string }) => (
  <div className={'card stat ' + (tone ?? '')}><div className="k">{k}</div><div className="v">{v}</div>{sub && <div className="k">{sub}</div>}</div>
);

export default function Dashboard({ data }: Props) {
  if (!data.products.length) return <div className="card"><h2>Bienvenue sur BÃNGR</h2><p>Aucun produit pour l’instant. Ouvre l’onglet « Produits » pour ajouter ceux de ta boutique. Tes chiffres apparaîtront ici dès ta première vente.</p></div>;
  const s = computeStats(data, Date.now());
  return (
    <>
      <div className="grid">
        <Stat k="Ventes du jour" v={fcfa(s.day.revenue)} sub={`${s.day.count} vente(s)`} />
        <Stat k="Marge du jour" v={fcfa(s.day.margin)} tone="gold" />
        <Stat k="Encaissé aujourd’hui" v={fcfa(s.day.cashIn)} />
        <Stat k="Crédits à recevoir" v={fcfa(s.receivables)} tone={s.receivables > 0 ? 'red' : ''} />
        <Stat k="Ventes du mois" v={fcfa(s.month.revenue)} sub={`Marge : ${fcfa(s.month.margin)}`} />
        <Stat k="Valeur du stock" v={fcfa(s.stockValue)} sub="au prix d’achat" />
      </div>
      <div className="card">
        <h2>Encaissé aujourd’hui par mode</h2>
        {Object.keys(s.day.byMethod).length === 0 ? <p className="k">Aucun encaissement aujourd’hui.</p> : Object.entries(s.day.byMethod).map(([m, v]) => <div className="row" key={m}><span>{PAYMENT_LABEL[m as PaymentMethod]}</span><b>{fcfa(v)}</b></div>)}
      </div>
      <div className="card">
        <h2>Stock bas</h2>
        {s.lowStock.length === 0 ? <p className="k">Aucun produit en alerte.</p> : s.lowStock.map((p) => <div className="row" key={p.id}><span>{p.name}</span><b className="red">{p.stock} {p.unit}</b></div>)}
      </div>
    </>
  );
}
