import { useState } from 'react';
import { cancelExpense, createExpense, dateToMs, EXPENSE_CATEGORIES } from '../domain/purchasing.ts';
import { PAYMENT_LABEL, PAYMENT_METHODS } from '../domain/payments.ts';
import { fcfa } from '../domain/money.ts';
import type { PaymentMethod } from '../domain/types.ts';
import type { Props } from './useData.ts';

const pad = (n: number) => String(n).padStart(2, '0');
const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };

export default function Expenses({ repo, data, act }: Props) {
  const [desc, setDesc] = useState(''); const [cat, setCat] = useState<string>('Marchandise'); const [amount, setAmount] = useState('');
  const [date, setDate] = useState(today()); const [method, setMethod] = useState<PaymentMethod>('ESPECES');
  const save = () => act(async () => {
    await createExpense(repo, { description: desc, category: cat, amount: Number(amount), method, at: dateToMs(date) });
    setDesc(''); setAmount(''); setDate(today());
  });
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime();
  const valid = data.expenses.filter((e) => e.status === 'VALIDEE');
  const month = valid.filter((e) => e.at >= monthStart);
  const byCat = EXPENSE_CATEGORIES.map((c) => [c, month.filter((e) => e.category === c).reduce((t, e) => t + e.amount, 0)] as const).filter(([, v]) => v > 0);
  const list = [...data.expenses].sort((a, b) => b.at - a.at).slice(0, 40);
  return (
    <>
      <div className="card">
        <h2>Nouvelle dépense</h2>
        <label>Description (facultatif)<input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="ex : loyer d’octobre" /></label>
        <label>Catégorie<select value={cat} onChange={(e) => setCat(e.target.value)}>{EXPENSE_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
        <label>Montant (FCFA)<input inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} /></label>
        <div className="two">
          <label>Date<input type="date" value={date} max={today()} onChange={(e) => setDate(e.target.value)} /></label>
          <label>Payé par<select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{PAYMENT_LABEL[m]}</option>)}</select></label>
        </div>
        <button className="primary" onClick={save}>Enregistrer</button>
      </div>
      <div className="card">
        <div className="row"><h2>Dépenses du mois</h2><b>{fcfa(month.reduce((t, e) => t + e.amount, 0))}</b></div>
        {byCat.length === 0 ? <p className="k">Aucune dépense ce mois-ci.</p> : byCat.map(([c, v]) => <div className="row" key={c}><span>{c}</span><b>{fcfa(v)}</b></div>)}
      </div>
      <h2>Dernières dépenses</h2>
      {list.length === 0 && <p className="k">Rien pour l’instant.</p>}
      {list.map((e) => (
        <div className={'card' + (e.status === 'ANNULEE' ? ' off' : '')} key={e.id}>
          <div className="row"><b>{e.category}</b><b>{fcfa(e.amount)}</b></div>
          <div className="k">{new Date(e.at).toLocaleDateString('fr-FR')} · {PAYMENT_LABEL[e.method]}{e.status === 'ANNULEE' ? ' · ANNULÉE' : ''}</div>
          {e.description && <div className="k">{e.description}</div>}
          {e.status === 'VALIDEE' && !e.orderId && <button className="ghost" onClick={() => { if (confirm('Annuler cette dépense ? Elle ne comptera plus dans tes chiffres.')) act(() => cancelExpense(repo, e.id)); }}>Annuler</button>}
        </div>
      ))}
    </>
  );
}
