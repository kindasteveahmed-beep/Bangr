import { useState } from 'react';
import { cancelOrder, createOrder, payOrder, receiveOrder } from '../domain/purchasing.ts';
import { PAYMENT_LABEL, PAYMENT_METHODS } from '../domain/payments.ts';
import { fcfa } from '../domain/money.ts';
import { whatsappLink } from '../domain/whatsapp.ts';
import type { PaymentMethod, PurchaseOrder } from '../domain/types.ts';
import type { Props } from './useData.ts';

const STATUS = { EN_COURS: '⏳ En cours', RECUE: '✅ Reçue', ANNULEE: 'Annulée' } as const;
const orderText = (o: PurchaseOrder) => `Bonjour ${o.supplierName}, je voudrais passer la commande ${o.number} :\n${o.lines.map((l) => `- ${l.qty} x ${l.name} (${fcfa(l.unitCost)})`).join('\n')}\nTotal : ${fcfa(o.total)}${o.note ? '\n' + o.note : ''}\nMerci !`;

export default function Orders({ repo, data, act }: Props) {
  const [sid, setSid] = useState(''); const [pid, setPid] = useState(''); const [qty, setQty] = useState('1'); const [cost, setCost] = useState(''); const [note, setNote] = useState('');
  const [lines, setLines] = useState<{ productId: string; qty: number; unitCost: number }[]>([]);
  const [payFor, setPayFor] = useState(''); const [amt, setAmt] = useState(''); const [method, setMethod] = useState<PaymentMethod>('ESPECES');
  const products = data.products.filter((p) => p.active); const byId = new Map(data.products.map((p) => [p.id, p]));
  const pick = (id: string) => { setPid(id); setCost(id ? String(byId.get(id)!.costPrice) : ''); };
  const add = () => {
    if (!pid) return alert('Choisis un produit.');
    const q = Number(qty), c = Number(cost);
    if (!Number.isInteger(q) || q <= 0) return alert('La quantité doit être un entier positif.');
    if (!Number.isInteger(c) || c < 0) return alert('Le prix d’achat doit être un montant entier en FCFA.');
    setLines([...lines, { productId: pid, qty: q, unitCost: c }]); setPid(''); setQty('1'); setCost('');
  };
  const total = lines.reduce((t, l) => t + l.qty * l.unitCost, 0);
  const create = () => act(async () => { await createOrder(repo, { supplierId: sid, lines, note }); setLines([]); setNote(''); });
  const pay = (o: PurchaseOrder) => act(async () => { await payOrder(repo, o.id, amt === '' ? o.total - o.paid : Number(amt), method); setPayFor(''); setAmt(''); });
  const suppliers = data.suppliers.filter((s) => s.active);
  const list = [...data.orders].sort((a, b) => b.at - a.at).slice(0, 40);
  return (
    <>
      <div className="card">
        <h2>Nouvelle commande</h2>
        {suppliers.length === 0 ? <p className="k">Ajoute d’abord un fournisseur (onglet « Fournisseurs »).</p>
          : products.length === 0 ? <p className="k">Ajoute d’abord des produits.</p> : <>
          <label>Fournisseur<select value={sid} onChange={(e) => setSid(e.target.value)}><option value="">— choisir —</option>{suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
          <label>Produit<select value={pid} onChange={(e) => pick(e.target.value)}><option value="">— choisir —</option>{products.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.stock} en stock)</option>)}</select></label>
          <div className="two">
            <label>Quantité<input inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value)} /></label>
            <label>Prix d’achat unitaire<input inputMode="numeric" value={cost} onChange={(e) => setCost(e.target.value)} /></label>
          </div>
          <button className="ghost" onClick={add}>+ Ajouter à la commande</button>
          {lines.map((l, i) => <div className="row" key={i}><span>{l.qty} × {byId.get(l.productId)?.name}</span><span>{fcfa(l.qty * l.unitCost)} <button className="x" onClick={() => setLines(lines.filter((_, j) => j !== i))}>✕</button></span></div>)}
          <div className="row total"><b>Total</b><b>{fcfa(total)}</b></div>
          <label>Note (facultatif)<input value={note} onChange={(e) => setNote(e.target.value)} placeholder="ex : livraison jeudi" /></label>
          <button className="primary" onClick={create}>Créer la commande</button>
        </>}
      </div>
      <h2>Commandes</h2>
      {list.length === 0 && <p className="k">Aucune commande pour l’instant.</p>}
      {list.map((o) => {
        const sup = data.suppliers.find((s) => s.id === o.supplierId); const rest = o.total - o.paid;
        return (
          <div className={'card' + (o.status === 'ANNULEE' ? ' off' : '')} key={o.id}>
            <div className="row"><b>{o.number} · {o.supplierName}</b><b>{fcfa(o.total)}</b></div>
            <div className="k">{new Date(o.at).toLocaleDateString('fr-FR')} · {STATUS[o.status]}{o.receivedAt ? ' le ' + new Date(o.receivedAt).toLocaleDateString('fr-FR') : ''}</div>
            {o.lines.map((l, i) => <div className="k" key={i}>{l.qty} × {l.name} à {fcfa(l.unitCost)}</div>)}
            {o.note && <div className="k">{o.note}</div>}
            {o.status !== 'ANNULEE' && <div className={rest > 0 ? 'red' : 'k'}>{rest > 0 ? `Payé : ${fcfa(o.paid)} · Reste à payer : ${fcfa(rest)}` : 'Payée en totalité'}</div>}
            <div className="rcpt-actions">
              {o.status === 'EN_COURS' && <a className="ghost" href={whatsappLink(sup?.phone, orderText(o))} target="_blank" rel="noreferrer">WhatsApp</a>}
              {o.status === 'EN_COURS' && <button className="ghost" onClick={() => { if (confirm(`Marquer ${o.number} comme reçue ?\nLe stock va augmenter.`)) act(() => receiveOrder(repo, o.id)); }}>✅ Reçue</button>}
              {o.status !== 'ANNULEE' && rest > 0 && <button className="ghost" onClick={() => { setPayFor(payFor === o.id ? '' : o.id); setAmt(''); }}>💸 Payer</button>}
              {o.status === 'EN_COURS' && o.paid === 0 && <button className="ghost" onClick={() => { if (confirm('Annuler cette commande ?')) act(() => cancelOrder(repo, o.id)); }}>Annuler</button>}
            </div>
            {payFor === o.id && (
              <div className="card">
                <label>Montant payé (vide = tout le reste : {fcfa(rest)})<input inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value)} /></label>
                <label>Payé par<select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{PAYMENT_LABEL[m]}</option>)}</select></label>
                <button className="primary" onClick={() => pay(o)}>Valider le paiement</button>
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}
