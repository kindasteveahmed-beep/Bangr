import { useState } from 'react';
import Expenses from './Expenses.tsx';
import Suppliers from './Suppliers.tsx';
import Orders from './Orders.tsx';
import type { Props } from './useData.ts';

const SUB = [['dep', '💸 Dépenses'], ['four', '🚚 Fournisseurs'], ['cmd', '📋 Commandes']] as const;

export default function Plus(p: Props) {
  const [sub, setSub] = useState<string>('dep');
  return (
    <>
      <div className="rcpt-tabs">{SUB.map(([id, label]) => <button key={id} className={sub === id ? 'on' : ''} onClick={() => setSub(id)}>{label}</button>)}</div>
      {sub === 'dep' ? <Expenses {...p} /> : sub === 'four' ? <Suppliers {...p} /> : <Orders {...p} />}
    </>
  );
}
