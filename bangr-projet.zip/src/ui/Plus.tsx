import type { ReactNode } from 'react';
import Expenses from './Expenses.tsx';
import SupplierOrders from './SupplierOrders.tsx';
import ClientOrders from './ClientOrders.tsx';
import Stock from './Stock.tsx';
import Icon from './icons.tsx';
import type { Props } from './useData.ts';

type PlusProps = Props & { sub: string; go: (tab: string, sub?: string) => void; compte: ReactNode };
const ITEMS = [
  ['dep', 'Dépenses', 'Loyer, transport, salaires…', 'wallet', 'orange'],
  ['four', 'Fournisseurs', 'Commandes passées à tes fournisseurs', 'truck', 'teal'],
  ['cmd', 'Commandes', 'Commandes de tes clients', 'clip', 'purple'],
  ['stock', 'Stock', 'Entrées, sorties et historique', 'box', 'blue'],
  ['compte', 'Compte', 'Synchronisation, abonnement, reçus', 'cloud', 'green'],
] as const;

export default function Plus({ sub, go, compte, ...p }: PlusProps) {
  const item = ITEMS.find((i) => i[0] === sub);
  if (!item) {
    const wait = p.data.supplierOrders.filter((o) => !o.deleted && o.status === 'EN_ATTENTE').length;
    const cmd = p.data.clientOrders.filter((o) => !o.deleted && o.status === 'EN_ATTENTE').length;
    const badge: Record<string, number> = { four: wait, cmd };
    return (
      <>
        <h2 className="m0 title">Plus</h2>
        {ITEMS.map(([id, label, desc, icon, tone]) => (
          <button key={id} className="menuitem" onClick={() => go('plus', id)}>
            <span className={'qi ' + tone}><Icon name={icon} size={22} /></span>
            <span className="grow"><b>{label}</b><span className="k">{desc}</span></span>
            {badge[id] > 0 && <span className="badge">{badge[id]}</span>}
            <Icon name="right" size={18} />
          </button>
        ))}
      </>
    );
  }
  return (
    <>
      <button className="back" onClick={() => go('plus')}><Icon name="left" size={18} /> Plus</button>
      <h2 className="m0 title">{item[1]}</h2>
      {sub === 'dep' ? <Expenses {...p} /> : sub === 'four' ? <SupplierOrders {...p} /> : sub === 'cmd' ? <ClientOrders {...p} /> : sub === 'stock' ? <Stock {...p} /> : compte}
    </>
  );
}
