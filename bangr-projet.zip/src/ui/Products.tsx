import { useState } from 'react';
import { archiveProduct, createProduct, updateProduct } from '../domain/services.ts';
import { fcfa } from '../domain/money.ts';
import type { Props } from './useData.ts';

const empty = { name: '', category: '', cost: '', price: '', stock: '', min: '' };

export default function Products({ repo, data, act }: Props) {
  const [f, setF] = useState(empty);
  const set = (k: keyof typeof empty) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const submit = () => act(async () => {
    await createProduct(repo, { name: f.name, category: f.category, costPrice: Number(f.cost || 0), salePrice: Number(f.price || 0), stock: Number(f.stock || 0), minStock: Number(f.min || 0) });
    setF(empty);
  });
  const editPrices = (id: string, cost: number, price: number) => {
    const c = prompt('Nouveau prix d’achat (FCFA)', String(cost)); if (c === null) return;
    const p = prompt('Nouveau prix de vente (FCFA)', String(price)); if (p === null) return;
    act(() => updateProduct(repo, id, { costPrice: Number(c), salePrice: Number(p) }));
  };
  const remove = (id: string, name: string) => {
    if (!confirm(`Supprimer « ${name} » ?\n\nIl disparaît de l’application. Tes anciennes ventes et tes chiffres restent corrects.\n\nCette action est définitive.`)) return;
    act(() => archiveProduct(repo, id));
  };
  const active = data.products.filter((p) => p.active);
  return (
    <>
      <div className="card">
        <h2>Nouveau produit</h2>
        <label>Nom<input value={f.name} onChange={set('name')} /></label>
        <label>Catégorie (ex : Pagnes, Savons)<input value={f.category} onChange={set('category')} /></label>
        <div className="two">
          <label>Prix d’achat<input inputMode="numeric" value={f.cost} onChange={set('cost')} /></label>
          <label>Prix de vente<input inputMode="numeric" value={f.price} onChange={set('price')} /></label>
          <label>Quantité en stock<input inputMode="numeric" value={f.stock} onChange={set('stock')} /></label>
          <label>Alerte quand il reste<input inputMode="numeric" value={f.min} onChange={set('min')} /></label>
        </div>
        <button className="primary" onClick={submit}>Enregistrer le produit</button>
      </div>
      {active.length === 0 && <p className="k">Aucun produit enregistré.</p>}
      {[...active].sort((a, b) => a.name.localeCompare(b.name)).map((p) => (
        <div className="card" key={p.id}>
          <div className="row"><b>{p.name}</b><span className={p.stock <= p.minStock ? 'red' : ''}>{p.stock} {p.unit}</span></div>
          <div className="k">{p.category || 'Sans catégorie'} · Achat {fcfa(p.costPrice)} · Vente {fcfa(p.salePrice)} · Marge {fcfa(p.salePrice - p.costPrice)}</div>
          <div className="rcpt-actions">
            <button className="ghost" onClick={() => editPrices(p.id, p.costPrice, p.salePrice)}>Modifier les prix</button>
            <button className="ghost" onClick={() => remove(p.id, p.name)}>🗑 Supprimer</button>
          </div>
        </div>
      ))}
    </>
  );
}
