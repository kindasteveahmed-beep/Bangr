import { useState } from 'react';
import { createPortal } from 'react-dom';
import type { Customer, Sale } from '../domain/types.ts';
import type { ReceiptHeader } from '../domain/receipt.ts';
import { formatReceiptText } from '../domain/receipt.ts';
import { formatInvoiceText } from '../domain/invoice.ts';
import { INVOICE_PDF, RECEIPT_PDF, makePdf } from '../domain/pdf.ts';
import { whatsappLink } from '../domain/whatsapp.ts';
import { sharePdf } from './share.ts';

export default function Receipt({ sale, header, customer, onClose }: { sale: Sale; header: ReceiptHeader; customer?: Customer; onClose: () => void }) {
  const [kind, setKind] = useState<'recu' | 'facture'>('recu');
  const isInv = kind === 'facture';
  const text = isInv ? formatInvoiceText(sale, header, customer) : formatReceiptText(sale, header, 32);
  const label = (isInv ? 'Facture ' : 'Reçu ') + sale.number;
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); alert('Copié. Colle-le dans WhatsApp ou un message.'); }
    catch { alert('Copie impossible : fais une capture d’écran.'); }
  };
  const pdf = async () => {
    const bytes = makePdf(text.split('\n'), isInv ? INVOICE_PDF : RECEIPT_PDF);
    const r = await sharePdf(bytes, `${isInv ? 'Facture' : 'Recu'}-${sale.number}.pdf`, label);
    if (r === 'downloaded') alert('PDF enregistré dans tes téléchargements.');
  };
  const share = async () => { try { if (navigator.share) await navigator.share({ title: label, text }); else await copy(); } catch { /* partage annulé */ } };
  const whatsapp = () => { window.open(whatsappLink(customer?.phone, text), '_blank'); };
  return createPortal(
    <div className="rcpt-overlay" onClick={onClose}>
      <div className="rcpt-box" onClick={(e) => e.stopPropagation()}>
        <div className="rcpt-tabs">
          <button className={kind === 'recu' ? 'on' : ''} onClick={() => setKind('recu')}>Reçu</button>
          <button className={isInv ? 'on' : ''} onClick={() => setKind('facture')}>Facture</button>
        </div>
        <pre className={'rcpt-pre' + (isInv ? ' wide' : '')}>{text}</pre>
        <div className="rcpt-actions">
          <button className="ghost" onClick={pdf}>📄 PDF</button>
          <button className="ghost" onClick={whatsapp}>WhatsApp{customer?.phone ? ' → ' + customer.name.split(' ')[0] : ''}</button>
          <button className="ghost" onClick={() => window.print()}>🖨 Imprimer</button>
          <button className="ghost" onClick={share}>↗ Partager</button>
          <button className="ghost" onClick={copy}>Copier</button>
          <button className="primary" onClick={onClose}>Fermer</button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
