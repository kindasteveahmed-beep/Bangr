import { useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import type { Customer, Sale } from '../domain/types.ts';
import type { ReceiptHeader } from '../domain/receipt.ts';
import { formatReceiptText } from '../domain/receipt.ts';
import { formatInvoiceText } from '../domain/invoice.ts';
import { INVOICE_PDF, makeImagePdf, makePdf } from '../domain/pdf.ts';
import { buildTicket } from '../domain/ticket.ts';
import { whatsappLink } from '../domain/whatsapp.ts';
import { drawTicket, ticketDataUrl, ticketJpeg, ticketPng } from './ticketCanvas.ts';
import { isNative, shareFile, sharePdf, type ShareResult } from './share.ts';

const FAIL = 'Le partage de fichier ne marche pas sur cet appareil. Utilise le bouton WhatsApp (texte) ou mets l’application à jour.';

export default function Receipt({ sale, header, customer, onClose }: { sale: Sale; header: ReceiptHeader; customer?: Customer; onClose: () => void }) {
  const [kind, setKind] = useState<'recu' | 'facture'>('recu');
  const isInv = kind === 'facture';
  const ticket = useMemo(() => drawTicket(buildTicket(sale, header, customer)), [sale, header, customer]);
  const shot = useMemo(() => ticketDataUrl(ticket), [ticket]);
  const text = isInv ? formatInvoiceText(sale, header, customer) : formatReceiptText(sale, header, 32);
  const label = (isInv ? 'Facture ' : 'Reçu ') + sale.number;
  const name = `${isInv ? 'Facture' : 'Recu'}-${sale.number}`;
  const done = (r: ShareResult, okMsg?: string) => { if (r === 'failed') alert(FAIL); else if (r === 'downloaded') alert(okMsg ?? 'Fichier enregistré dans tes téléchargements.'); };
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); alert('Copié. Colle-le dans WhatsApp ou un message.'); }
    catch { alert('Copie impossible : fais une capture d’écran.'); }
  };
  const pdf = async () => {
    const bytes = isInv ? makePdf(text.split('\n'), INVOICE_PDF) : makeImagePdf(ticketJpeg(ticket), ticket.width, ticket.height);
    done(await sharePdf(bytes, name + '.pdf', label), 'PDF enregistré dans tes téléchargements.');
  };
  const image = async () => done(await shareFile(ticketPng(ticket), name + '.png', 'image/png', label), 'Image enregistrée dans tes téléchargements.');
  const print = () => { if (isNative()) void pdf(); else window.print(); }; // sur téléphone : le PDF s'ouvre/s'imprime depuis la feuille de partage
  const whatsapp = () => { window.open(whatsappLink(customer?.phone, text), '_blank'); };
  return createPortal(
    <div className="rcpt-overlay" onClick={onClose}>
      <div className="rcpt-box" onClick={(e) => e.stopPropagation()}>
        <div className="rcpt-tabs">
          <button className={kind === 'recu' ? 'on' : ''} onClick={() => setKind('recu')}>Reçu</button>
          <button className={isInv ? 'on' : ''} onClick={() => setKind('facture')}>Facture</button>
        </div>
        {isInv ? <pre className="rcpt-pre wide">{text}</pre> : <div className="rcpt-paper"><img className="rcpt-img" src={shot} alt={label} /></div>}
        <div className="rcpt-actions">
          <button className="ghost" onClick={pdf}>📄 PDF</button>
          <button className="ghost" onClick={whatsapp}>WhatsApp{customer?.phone ? ' → ' + customer.name.split(' ')[0] : ''}</button>
          <button className="ghost" onClick={print}>🖨 Imprimer</button>
          {!isInv && <button className="ghost" onClick={image}>🖼 Image</button>}
          <button className="ghost" onClick={copy}>Copier</button>
          <button className="primary" onClick={onClose}>Fermer</button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
