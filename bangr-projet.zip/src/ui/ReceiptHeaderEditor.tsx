import { useState } from 'react';
import type { ReceiptHeader } from '../domain/receipt.ts';
import { localKV, saveHeader } from '../data/settings.ts';

export default function ReceiptHeaderEditor({ header, onSave }: { header: ReceiptHeader; onSave: (h: ReceiptHeader) => void }) {
  const [h, setH] = useState(header);
  const set = (k: keyof ReceiptHeader) => (e: { target: { value: string } }) => setH({ ...h, [k]: e.target.value });
  return (
    <details className="card">
      <summary><b>En-tête et pied du reçu</b></summary>
      <p className="k">Ces lignes s’impriment en haut et en bas de chaque reçu. Laisse vide ce que tu ne veux pas afficher.</p>
      <label>Nom de la boutique<input value={h.shop} onChange={set('shop')} /></label>
      <label>Adresse<input value={h.address} onChange={set('address')} /></label>
      <label>Téléphone<input inputMode="tel" value={h.phone} onChange={set('phone')} /></label>
      <label>Autre ligne (ex : IFU, RCCM)<input value={h.extra} onChange={set('extra')} /></label>
      <label>Message de fin (ex : Merci de votre visite !)<input value={h.footer} onChange={set('footer')} /></label>
      <button className="primary" onClick={() => { saveHeader(localKV, h); onSave(h); alert('En-tête enregistré.'); }}>Enregistrer l’en-tête</button>
    </details>
  );
}
