import { useState } from 'react';
import { recordSale, cancelSale, createCustomer } from '../domain/services.ts';
import { PAYMENT_LABEL, PAYMENT_METHODS, paymentsOf } from '../domain/payments.ts';
import { fcfa } from '../domain/money.ts';
import type { Props } from './useData.ts';
import type { PaymentMethod, Sale } from '../domain/types.ts';
import { loadHeader, localKV } from '../data/settings.ts';
import Receipt from './Receipt.tsx';
import ReceiptHeaderEditor from './ReceiptHeaderEditor.tsx';

export default function Sales({ repo, data, act }: Props) {
  const [lines, setLines] = useState<{ productId: string; qty: number }[]>([]);
  const [pid, setPid] = useState('');
  const [qty, setQty] = useState('1');
  const [paid, setPaid] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('ESPECES');
  const [header, setHeader] = useState(() => loadHeader(localKV));
  const [shown, setShown] = useState<Sale | null>(null);
  const byId = new Map(data.products.map((p) => [p.id, p]));
  const total = lines.reduce((t, l) => t + l.qty * (byId.get(l.productId)?.salePrice ?? 0), 0);
  const add = () => {
    const q = Number(qty);
    if (!pid || !Number.isInteger(q) || q <= 0) return alert('Choisis un produit et une quantité entière.');
    setLines([...lines, { productId: pid, qty: q }]); setQty('1');
  };
  const validate = () => act(async () => {
    let cid = customerId;
    if (adding) cid = (await createCustomer(repo, { name: newName, phone: newPhone })).id;
    const sale = await recordSale(repo, { lines, paid: paid === '' ? total : Number(paid), customerId: cid || undefined, method });
    setLines([]); setPaid(''); setCustomerId(''); setAdding(false); setNewName(''); setNewPhone(''); setShown(sale);
  });
  const recent = [...data.sales].sort((a, b) => b.at - a.at).slice(0, 20);
  return (
    <>
      <div className="card">
        <h2>Nouvelle vente</h2>
        {data.products.length === 0 ? <p className="k">Ajoute d’abord des produits.</p> : <>
          <label>Produit<select value={pid} onChange={(e) => setPid(e.target.value)}><option value="">— choisir —</option>{data.products.filter((p) => p.active).map((p) => <option key={p.id} value={p.id}>{p.name} ({p.stock} en stock) – {fcfa(p.salePrice)}</option>)}</select></label>
          <label>Quantité<input inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value)} /></label>
          <button className="ghost" onClick={add}>+ Ajouter à la vente</button>
          {lines.map((l, i) => <div className="row" key={i}><span>{l.qty} × {byId.get(l.productId)?.name}</span><span>{fcfa(l.qty * (byId.get(l.productId)?.salePrice ?? 0))} <button className="x" onClick={() => setLines(lines.filter((_, j) => j !== i))}>✕</button></span></div>)}
          <div className="row total"><b>Total</b><b>{fcfa(total)}</b></div>
          <label>Montant payé (vide = tout payé)<input inputMode="numeric" value={paid} onChange={(e) => setPaid(e.target.value)} /></label>
          <label>Mode de paiement<select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{PAYMENT_LABEL[m]}</option>)}</select></label>
          <label>Client (obligatoire si crédit)<select value={adding ? '__new' : customerId} onChange={(e) => { if (e.target.value === '__new') { setAdding(true); setCustomerId(''); } else { setAdding(false); setCustomerId(e.target.value); } }}><option value="">Client de passage</option>{[...data.customers].sort((a, b) => a.name.localeCompare(b.name)).map((c) => <option key={c.id} value={c.id}>{c.name}{c.phone ? ' – ' + c.phone : ''}</option>)}<option value="__new">+ Nouveau client…</option></select></label>
          {adding && <><label>Nom du nouveau client<input value={newName} onChange={(e) => setNewName(e.target.value)} /></label><label>Téléphone<input inputMode="tel" value={newPhone} onChange={(e) => setNewPhone(e.target.value)} /></label></>}
          <button className="primary" onClick={validate}>Valider la vente</button>
        </>}
      </div>
      <ReceiptHeaderEditor header={header} onSave={setHeader} />
      <h2>Dernières ventes</h2>
      {recent.length === 0 && <p className="k">Aucune vente enregistrée.</p>}
      {recent.map((s) => (
        <div className={'card' + (s.status === 'ANNULEE' ? ' off' : '')} key={s.id}>
          <div className="row"><b>{s.number}</b><b>{fcfa(s.total)}</b></div>
          <div className="k">{new Date(s.at).toLocaleString('fr-FR')}{s.customerName ? ' · ' + s.customerName : ''}{s.status === 'ANNULEE' ? ' · ANNULÉE' : ''}</div>
          {paymentsOf(s).length > 0 && <div className="k">Payé : {paymentsOf(s).map((p) => PAYMENT_LABEL[p.method] + ' ' + fcfa(p.amount)).join(' · ')}</div>}
          {s.lines.map((l, i) => <div className="k" key={i}>{l.qty} × {l.name} à {fcfa(l.unitPrice)}</div>)}
          {s.total > s.paid && s.status === 'VALIDEE' && <div className="red">Reste à payer : {fcfa(s.total - s.paid)}</div>}
          <button className="ghost" onClick={() => setShown(s)}>Reçu</button>
          {s.status === 'VALIDEE' && <button className="ghost" onClick={() => { const r = prompt('Motif de l’annulation ?'); if (r !== null) act(() => cancelSale(repo, s.id, r)); }}>Annuler cette vente</button>}
        </div>
      ))}
      {shown && <Receipt sale={shown} header={header} customer={data.customers.find((c) => c.id === shown.customerId)} onClose={() => setShown(null)} />}
    </>
  );
}
