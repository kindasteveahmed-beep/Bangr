import { useState } from 'react';
import { recordSale, cancelSale } from '../domain/services.ts';
import { fcfa } from '../domain/money.ts';
import type { Props } from './useData.ts';

export default function Sales({ repo, data, act }: Props) {
  const [lines, setLines] = useState<{ productId: string; qty: number }[]>([]);
  const [pid, setPid] = useState('');
  const [qty, setQty] = useState('1');
  const [paid, setPaid] = useState('');
  const [customer, setCustomer] = useState('');
  const byId = new Map(data.products.map((p) => [p.id, p]));
  const total = lines.reduce((t, l) => t + l.qty * (byId.get(l.productId)?.salePrice ?? 0), 0);
  const add = () => {
    const q = Number(qty);
    if (!pid || !Number.isInteger(q) || q <= 0) return alert('Choisis un produit et une quantité entière.');
    setLines([...lines, { productId: pid, qty: q }]); setQty('1');
  };
  const validate = () => act(async () => {
    await recordSale(repo, { lines, paid: paid === '' ? total : Number(paid), customerName: customer });
    setLines([]); setPaid(''); setCustomer('');
  });
  const recent = [...data.sales].sort((a, b) => b.at - a.at).slice(0, 20);
  return (
    <>
      <div className="card">
        <h2>Nouvelle vente</h2>
        {data.products.length === 0 ? <p className="k">Ajoute d’abord des produits.</p> : <>
          <label>Produit<select value={pid} onChange={(e) => setPid(e.target.value)}><option value="">— choisir —</option>{data.products.filter((p) => p.active).map((p) => <option key={p.id} value={p.id}>{p.name} ({p.stock} en stock) – {fcfa(p.salePrice)}</option>)}</select></label>
          <label>Quantité<input inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value)} /></label>
          <button className="ghost" onClick={add}>+ Ajouter à la vente</button>
          {lines.map((l, i) => <div className="row" key={i}><span>{l.qty} × {byId.get(l.productId)?.name}</span><span>{fcfa(l.qty * (byId.get(l.productId)?.salePrice ?? 0))} <button className="x" onClick={() => setLines(lines.filter((_, j) => j !== i))}>✕</button></span></div>)}
          <div className="row total"><b>Total</b><b>{fcfa(total)}</b></div>
          <label>Montant payé (vide = tout payé)<input inputMode="numeric" value={paid} onChange={(e) => setPaid(e.target.value)} /></label>
          <label>Nom du client (obligatoire si crédit)<input value={customer} onChange={(e) => setCustomer(e.target.value)} /></label>
          <button className="primary" onClick={validate}>Valider la vente</button>
        </>}
      </div>
      <h2>Dernières ventes</h2>
      {recent.length === 0 && <p className="k">Aucune vente enregistrée.</p>}
      {recent.map((s) => (
        <div className={'card' + (s.status === 'ANNULEE' ? ' off' : '')} key={s.id}>
          <div className="row"><b>{s.number}</b><b>{fcfa(s.total)}</b></div>
          <div className="k">{new Date(s.at).toLocaleString('fr-FR')}{s.customerName ? ' · ' + s.customerName : ''}{s.status === 'ANNULEE' ? ' · ANNULÉE' : ''}</div>
          {s.lines.map((l, i) => <div className="k" key={i}>{l.qty} × {l.name} à {fcfa(l.unitPrice)}</div>)}
          {s.total > s.paid && s.status === 'VALIDEE' && <div className="red">Reste à payer : {fcfa(s.total - s.paid)}</div>}
          {s.status === 'VALIDEE' && <button className="ghost" onClick={() => { const r = prompt('Motif de l’annulation ?'); if (r !== null) act(() => cancelSale(repo, s.id, r)); }}>Annuler cette vente</button>}
        </div>
      ))}
    </>
  );
}
