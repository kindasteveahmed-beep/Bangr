import { adjustStock } from '../domain/services.ts';
import type { Props } from './useData.ts';

const LABEL: Record<string, string> = { ENTREE: 'Entrée', SORTIE: 'Sortie', AJUSTEMENT: 'Ajustement', VENTE: 'Vente', ANNULATION_VENTE: 'Vente annulée' };

export default function Stock({ repo, data, act }: Props) {
  const ask = (id: string, type: 'ENTREE' | 'SORTIE') => {
    const q = prompt(type === 'ENTREE' ? 'Quantité reçue ?' : 'Quantité sortie (casse, perte, don…) ?'); if (q === null) return;
    const n = Number(q); const why = prompt('Motif (facultatif)') ?? '';
    act(() => adjustStock(repo, id, type, type === 'ENTREE' ? n : -n, why));
  };
  const inventory = (id: string, current: number) => {
    const q = prompt('Quantité réellement comptée ?', String(current)); if (q === null) return;
    const delta = Number(q) - current;
    if (delta === 0) return alert('Aucun écart.');
    act(() => adjustStock(repo, id, 'AJUSTEMENT', delta, 'Inventaire'));
  };
  const names = new Map(data.products.map((p) => [p.id, p.name]));
  const moves = [...data.moves].sort((a, b) => b.at - a.at).slice(0, 40);
  return (
    <>
      <h2>Stock actuel</h2>
      {data.products.filter((p) => p.active).length === 0 && <p className="k">Aucun produit.</p>}
      {data.products.filter((p) => p.active).map((p) => (
        <div className="card" key={p.id}>
          <div className="row"><b>{p.name}</b><b className={p.stock <= p.minStock ? 'red' : ''}>{p.stock} {p.unit}</b></div>
          <button className="ghost" onClick={() => ask(p.id, 'ENTREE')}>+ Entrée</button>
          <button className="ghost" onClick={() => ask(p.id, 'SORTIE')}>− Sortie</button>
          <button className="ghost" onClick={() => inventory(p.id, p.stock)}>Inventaire</button>
        </div>
      ))}
      <h2>Derniers mouvements</h2>
      {moves.length === 0 && <p className="k">Aucun mouvement.</p>}
      {moves.map((m) => <div className="row small" key={m.id}><span>{LABEL[m.type]} · {names.get(m.productId) ?? '?'}<br /><span className="k">{new Date(m.at).toLocaleString('fr-FR')}{m.reason ? ' · ' + m.reason : ''}</span></span><b className={m.qty < 0 ? 'red' : 'green'}>{m.qty > 0 ? '+' : ''}{m.qty}</b></div>)}
    </>
  );
}
