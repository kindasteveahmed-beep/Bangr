import { useState } from 'react';
import { createSupplierOrder, dayMs, deleteSupplierOrder, deliverSupplierOrder, paySupplierOrder } from '../domain/purchasing.ts';
import { PAYMENT_LABEL, PAYMENT_METHODS } from '../domain/payments.ts';
import { fcfa } from '../domain/money.ts';
import type { PaymentMethod, SupplierOrder } from '../domain/types.ts';
import type { Props } from './useData.ts';

const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
const day = (t: number) => new Date(t).toLocaleDateString('fr-FR');
const ymdToday = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

export default function SupplierOrders({ repo, data, act }: Props) {
  const [open, setOpen] = useState(false);
  const [supplier, setSupplier] = useState(''); const [goods, setGoods] = useState(''); const [total, setTotal] = useState(''); const [paid, setPaid] = useState(''); const [due, setDue] = useState('');
  const [payFor, setPayFor] = useState(''); const [amt, setAmt] = useState(''); const [method, setMethod] = useState<PaymentMethod>('ESPECES');
  const save = () => act(async () => {
    await createSupplierOrder(repo, { supplier, goods, total: Number(total), paid: paid === '' ? 0 : Number(paid), dueDate: dayMs(due) });
    setSupplier(''); setGoods(''); setTotal(''); setPaid(''); setDue(''); setOpen(false);
  });
  const pay = (o: SupplierOrder) => act(async () => { await paySupplierOrder(repo, o.id, amt === '' ? o.total - o.paid : Number(amt), method); setPayFor(''); setAmt(''); });
  const list = data.supplierOrders.filter((o) => !o.deleted).sort((a, b) => (a.status === b.status ? b.at - a.at : a.status === 'EN_ATTENTE' ? -1 : 1));
  const names = [...new Set(data.supplierOrders.map((o) => o.supplier))];
  const debt = list.reduce((t, o) => t + (o.total - o.paid), 0);
  return (
    <>
      <button className="primary" onClick={() => setOpen(!open)}>{open ? 'Fermer' : '+ Commande fournisseur'}</button>
      {open && (
        <div className="card up">
          <h2 className="m0">Commande fournisseur</h2>
          <label>Fournisseur<input list="fournisseurs" value={supplier} onChange={(e) => setSupplier(e.target.value)} /></label>
          <datalist id="fournisseurs">{names.map((n) => <option key={n} value={n} />)}</datalist>
          <label>Marchandise commandée<input value={goods} onChange={(e) => setGoods(e.target.value)} /></label>
          <label>Montant total<input inputMode="numeric" value={total} onChange={(e) => setTotal(e.target.value)} /></label>
          <label>Montant déjà versé<input inputMode="numeric" value={paid} onChange={(e) => setPaid(e.target.value)} /></label>
          <label>Livraison prévue<input type="date" min={ymdToday()} value={due} onChange={(e) => setDue(e.target.value)} /></label>
          <button className="primary" onClick={save}>Enregistrer</button>
          <button className="ghost wide" onClick={() => setOpen(false)}>Annuler</button>
        </div>
      )}
      {list.length > 0 && <div className="row sumline"><span className="k">Reste à payer aux fournisseurs</span><b className={debt > 0 ? 'red' : ''}>{fcfa(debt)}</b></div>}
      {list.length === 0 && <p className="k">Aucune commande fournisseur. Appuie sur « + Commande fournisseur ».</p>}
      {list.map((o) => {
        const rest = o.total - o.paid; const late = o.status === 'EN_ATTENTE' && o.dueDate !== undefined && o.dueDate < startOfToday();
        return (
          <div className="card" key={o.id}>
            <div className="row"><b>{o.supplier}</b><b>{fcfa(o.total)}</b></div>
            <div>{o.goods}</div>
            <div className="k">{o.number} · {o.status === 'LIVREE' ? '✅ Reçue' + (o.deliveredAt ? ' le ' + day(o.deliveredAt) : '') : '⏳ En attente'}{o.dueDate !== undefined && o.status === 'EN_ATTENTE' ? ' · Livraison prévue : ' + day(o.dueDate) : ''}</div>
            {late && <div className="red">Livraison en retard</div>}
            <div className={rest > 0 ? 'red' : 'green'}>{rest > 0 ? `Déjà versé : ${fcfa(o.paid)} · Reste : ${fcfa(rest)}` : 'Payée en totalité'}</div>
            <div className="rcpt-actions">
              {rest > 0 && <button className="ghost" onClick={() => { setPayFor(payFor === o.id ? '' : o.id); setAmt(''); }}>💸 Payer</button>}
              {o.status === 'EN_ATTENTE' && <button className="ghost" onClick={() => { if (confirm('Marquer cette commande comme reçue ?')) act(() => deliverSupplierOrder(repo, o.id)); }}>✅ Reçue</button>}
              <button className="ghost" onClick={() => { if (confirm(`Supprimer la commande ${o.number} ?\n\nCette action est définitive. Les paiements qu’elle contient seront aussi retirés de tes dépenses.`)) act(() => deleteSupplierOrder(repo, o.id)); }}>🗑 Supprimer</button>
            </div>
            {payFor === o.id && (
              <div className="subcard">
                <label>Montant versé (vide = tout le reste : {fcfa(rest)})<input inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value)} /></label>
                <label>Payé par<select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{PAYMENT_LABEL[m]}</option>)}</select></label>
                <button className="primary" onClick={() => pay(o)}>Valider le paiement</button>
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}
