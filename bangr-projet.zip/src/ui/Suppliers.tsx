import { useState } from 'react';
import { archiveSupplier, createSupplier, restoreSupplier, supplierBalance, updateSupplier } from '../domain/purchasing.ts';
import { fcfa } from '../domain/money.ts';
import { whatsappLink, whatsappNumber } from '../domain/whatsapp.ts';
import type { Props } from './useData.ts';

export default function Suppliers({ repo, data, act }: Props) {
  const [name, setName] = useState(''); const [phone, setPhone] = useState(''); const [address, setAddress] = useState('');
  const save = () => act(async () => { await createSupplier(repo, { name, phone, address }); setName(''); setPhone(''); setAddress(''); });
  const edit = (id: string, n: string, ph: string) => {
    const nn = prompt('Nom du fournisseur', n); if (nn === null) return;
    const pp = prompt('Téléphone', ph); if (pp === null) return;
    const s = data.suppliers.find((x) => x.id === id)!;
    act(() => updateSupplier(repo, id, { name: nn, phone: pp, address: s.address, notes: s.notes }));
  };
  const remove = (id: string, n: string) => { if (confirm(`Supprimer « ${n} » ?\n\nSes anciennes commandes restent dans l’historique. Tu pourras le restaurer.`)) act(() => archiveSupplier(repo, id)); };
  const active = data.suppliers.filter((s) => s.active).sort((a, b) => a.name.localeCompare(b.name));
  const removed = data.suppliers.filter((s) => !s.active);
  return (
    <>
      <div className="card">
        <h2>Nouveau fournisseur</h2>
        <label>Nom<input value={name} onChange={(e) => setName(e.target.value)} /></label>
        <label>Téléphone<input inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
        <label>Adresse (facultatif)<input value={address} onChange={(e) => setAddress(e.target.value)} /></label>
        <button className="primary" onClick={save}>Enregistrer le fournisseur</button>
      </div>
      {active.length === 0 && <p className="k">Aucun fournisseur enregistré.</p>}
      {active.map((s) => {
        const due = supplierBalance(data.orders, s.id);
        return (
          <div className="card" key={s.id}>
            <div className="row"><b>{s.name}</b>{due > 0 && <b className="red">Dû : {fcfa(due)}</b>}</div>
            <div className="k">{s.phone || 'Pas de téléphone'}{s.address ? ' · ' + s.address : ''}</div>
            <div className="rcpt-actions">
              {s.phone && <a className="ghost" href={'tel:' + s.phone.replace(/\s/g, '')}>📞 Appeler</a>}
              {whatsappNumber(s.phone) && <a className="ghost" href={whatsappLink(s.phone, 'Bonjour ' + s.name + ',')} target="_blank" rel="noreferrer">WhatsApp</a>}
              <button className="ghost" onClick={() => edit(s.id, s.name, s.phone)}>Modifier</button>
              <button className="ghost" onClick={() => remove(s.id, s.name)}>🗑 Supprimer</button>
            </div>
          </div>
        );
      })}
      {removed.length > 0 && (
        <details className="card"><summary>Fournisseurs supprimés ({removed.length})</summary>
          {removed.map((s) => <div className="row" key={s.id} style={{ marginTop: 8 }}><span>{s.name}</span><button className="ghost" onClick={() => act(() => restoreSupplier(repo, s.id))}>Restaurer</button></div>)}
        </details>
      )}
    </>
  );
}
