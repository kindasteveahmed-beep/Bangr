/** Partage un fichier : feuille « Partager » d'Android (plugins Capacitor), sinon partage du navigateur, sinon téléchargement. */
type Plug = Record<string, (o: unknown) => Promise<{ uri?: string }>>;
interface Cap { isNativePlatform?: () => boolean; Plugins?: Record<string, Plug>; registerPlugin?: (n: string) => Plug }
const cap = () => (window as unknown as { Capacitor?: Cap }).Capacitor;
export const isNative = () => !!cap()?.isNativePlatform?.();
const plugin = (n: string): Plug | undefined => { const c = cap(); return c?.Plugins?.[n] ?? c?.registerPlugin?.(n); };
const b64 = (u: Uint8Array) => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };

export type ShareResult = 'shared' | 'downloaded' | 'cancelled' | 'failed';

async function shareNative(bytes: Uint8Array, filename: string, title: string): Promise<ShareResult> {
  try {
    const fs = plugin('Filesystem'); const sh = plugin('Share');
    if (!fs || !sh) return 'failed';
    const w = await fs.writeFile({ path: filename, data: b64(bytes), directory: 'CACHE' });
    await sh.share({ title, url: w.uri, dialogTitle: title });
    return 'shared';
  } catch (e) { return /cancel/i.test(String((e as Error)?.message ?? e)) ? 'cancelled' : 'failed'; }
}

export async function shareFile(bytes: Uint8Array, filename: string, mime: string, title: string): Promise<ShareResult> {
  if (isNative()) return shareNative(bytes, filename, title);
  const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  const nav = navigator as Navigator & { canShare?: (d: unknown) => boolean };
  try {
    const file = new File([buf], filename, { type: mime });
    if (nav.canShare?.({ files: [file] })) { await nav.share({ files: [file], title }); return 'shared'; }
  } catch (e) { if (e instanceof Error && e.name === 'AbortError') return 'cancelled'; }
  const url = URL.createObjectURL(new Blob([buf], { type: mime }));
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15000);
  return 'downloaded';
}
export const sharePdf = (bytes: Uint8Array, filename: string, title: string) => shareFile(bytes, filename, 'application/pdf', title);
