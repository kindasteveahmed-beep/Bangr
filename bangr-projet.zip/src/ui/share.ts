/** Partage un PDF (feuille de partage du téléphone : WhatsApp, e-mail…) ; sinon, le télécharge. */
export async function sharePdf(bytes: Uint8Array, filename: string, title: string): Promise<'shared' | 'downloaded' | 'cancelled'> {
  const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  const nav = navigator as Navigator & { canShare?: (d: unknown) => boolean };
  try {
    const file = new File([buf], filename, { type: 'application/pdf' });
    if (nav.canShare?.({ files: [file] })) { await nav.share({ files: [file], title }); return 'shared'; }
  } catch (e) { if (e instanceof Error && e.name === 'AbortError') return 'cancelled'; }
  const url = URL.createObjectURL(new Blob([buf], { type: 'application/pdf' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15000);
  return 'downloaded';
}
