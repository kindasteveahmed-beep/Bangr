import type { TicketItem } from '../domain/ticket.ts';
import { code39Bars } from '../domain/code39.ts';

const W = 320, PAD = 18, SC = 3; // largeur logique du ticket, marge, finesse (x3 = net à l'impression)
const FONT = '"Helvetica Neue", Arial, "Segoe UI", Roboto, sans-serif';
const font = (px: number, bold = false) => `${bold ? '700' : '400'} ${px}px ${FONT}`;
const INK = '#1d1d1d', GREY = '#6a6a6a', RED = '#b3261e';

function wrap(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const out: string[] = []; let cur = '';
  for (let word of text.trim().split(/\s+/).filter(Boolean)) {
    while (ctx.measureText(word).width > maxW && word.length > 1) { // mot trop long : coupé
      let n = word.length - 1; while (n > 1 && ctx.measureText(word.slice(0, n)).width > maxW) n--;
      if (cur) { out.push(cur); cur = ''; } out.push(word.slice(0, n)); word = word.slice(n);
    }
    const t = cur ? cur + ' ' + word : word;
    if (!cur || ctx.measureText(t).width <= maxW) cur = t; else { out.push(cur); cur = word; }
  }
  if (cur) out.push(cur);
  return out.length ? out : [''];
}

/** Parcourt le ticket : mesure seulement (draw=false) ou dessine (draw=true). Renvoie la hauteur utilisée. */
function run(ctx: CanvasRenderingContext2D, items: TicketItem[], draw: boolean): number {
  let y = 18; const inner = W - 2 * PAD; ctx.fillStyle = INK; ctx.textBaseline = 'alphabetic';
  for (const it of items) {
    switch (it.k) {
      case 'gap': y += it.h; break;
      case 'dash':
        y += 8;
        if (draw) { ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = 1.6; ctx.setLineDash([6, 4]); ctx.beginPath(); ctx.moveTo(PAD, y); ctx.lineTo(W - PAD, y); ctx.stroke(); ctx.restore(); }
        y += 10; break;
      case 'title': case 'center': {
        const px = it.k === 'title' ? 17 : it.small ? 12.5 : 14; const bold = it.k === 'title' || !!it.bold; const lh = it.k === 'title' ? 23 : 18;
        ctx.font = font(px, bold); ctx.textAlign = 'center';
        for (const l of wrap(ctx, it.text, inner)) { y += lh; if (draw) { ctx.fillStyle = it.k === 'center' && it.small ? GREY : INK; ctx.fillText(l, W / 2, y - 5); } }
        y += 3; break;
      }
      case 'row': {
        const px = it.big ? 18 : 14; ctx.font = font(px, !!it.bold); const rw = ctx.measureText(it.r).width;
        const ls = wrap(ctx, it.l, inner - rw - 10); const lh = it.big ? 26 : 20;
        ls.forEach((l, i) => { y += lh; if (draw) { ctx.fillStyle = INK; ctx.textAlign = 'left'; ctx.fillText(l, PAD, y - 5); if (i === 0) { ctx.textAlign = 'right'; ctx.fillText(it.r, W - PAD, y - 5); } } });
        break;
      }
      case 'line': {
        ctx.font = font(13.5); ctx.textAlign = 'left'; const aw = ctx.measureText(it.amount).width;
        wrap(ctx, it.name, inner - aw - 12).forEach((l, i) => { y += 18; if (draw) { ctx.fillStyle = INK; ctx.font = font(13.5); ctx.textAlign = 'left'; ctx.fillText(l, PAD, y - 4); if (i === 0) { ctx.textAlign = 'right'; ctx.fillText(it.amount, W - PAD, y - 4); } } });
        if (it.detail) { ctx.font = font(12); y += 16; if (draw) { ctx.fillStyle = GREY; ctx.textAlign = 'left'; ctx.fillText(it.detail, PAD + 16, y - 3); } }
        y += 5; break;
      }
      case 'barcode': {
        const bars = code39Bars(it.code); const total = bars.reduce((s, b) => s + b.w, 0); const unit = Math.min(1.7, inner / total);
        y += 10; const h = 46; let x = (W - total * unit) / 2;
        if (draw) { ctx.fillStyle = INK; for (const b of bars) { if (b.bar) ctx.fillRect(x, y, b.w * unit, h); x += b.w * unit; } }
        y += h + 16;
        if (draw) { ctx.font = font(13, true); ctx.textAlign = 'center'; ctx.fillStyle = INK; ctx.fillText(it.code, W / 2, y - 2); }
        y += 6; break;
      }
      case 'stamp': {
        ctx.font = font(18, true); const w = ctx.measureText(it.text).width + 24; y += 34;
        if (draw) { ctx.save(); ctx.strokeStyle = RED; ctx.fillStyle = RED; ctx.lineWidth = 2.5; ctx.strokeRect((W - w) / 2, y - 28, w, 34); ctx.textAlign = 'center'; ctx.fillText(it.text, W / 2, y - 4); ctx.restore(); }
        y += 6; break;
      }
    }
  }
  return y + 12;
}

export interface TicketImage { canvas: HTMLCanvasElement; width: number; height: number }
export function drawTicket(items: TicketItem[]): TicketImage {
  const probe = document.createElement('canvas').getContext('2d')!;
  const h = Math.ceil(run(probe, items, false));
  const canvas = document.createElement('canvas'); canvas.width = W * SC; canvas.height = h * SC;
  const ctx = canvas.getContext('2d')!; ctx.scale(SC, SC); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, h);
  run(ctx, items, true);
  return { canvas, width: canvas.width, height: canvas.height };
}
const fromDataUrl = (u: string) => { const b = atob(u.slice(u.indexOf(',') + 1)); return Uint8Array.from(b, (c) => c.charCodeAt(0)); };
export const ticketJpeg = (t: TicketImage) => fromDataUrl(t.canvas.toDataURL('image/jpeg', 0.93));
export const ticketPng = (t: TicketImage) => fromDataUrl(t.canvas.toDataURL('image/png'));
export const ticketDataUrl = (t: TicketImage) => t.canvas.toDataURL('image/png');
