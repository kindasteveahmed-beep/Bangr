import { useCallback, useEffect, useState } from 'react';
import type { Repo } from '../domain/repo.ts';
import type { Customer, Product, Sale, StockMove } from '../domain/types.ts';

export interface Data { customers: Customer[]; products: Product[]; moves: StockMove[]; sales: Sale[]; ready: boolean; reload: () => Promise<void> }
export interface Props { repo: Repo; data: Data; act: (fn: () => Promise<unknown>) => Promise<void> }

export function useData(repo: Repo): Data {
  const [d, setD] = useState({ customers: [] as Customer[], products: [] as Product[], moves: [] as StockMove[], sales: [] as Sale[], ready: false });
  const reload = useCallback(async () => {
    const [products, moves, sales, customers] = await Promise.all([repo.all<Product>('products'), repo.all<StockMove>('moves'), repo.all<Sale>('sales'), repo.all<Customer>('customers')]);
    setD({ products, moves, sales, customers, ready: true });
  }, [repo]);
  useEffect(() => { reload(); }, [reload]);
  return { ...d, reload };
}
