import { useCallback, useEffect, useState } from 'react';
import type { Repo } from '../domain/repo.ts';
import type { Customer, ClientOrder, Expense, Product, Sale, StockMove, SupplierOrder } from '../domain/types.ts';

export interface Data { expenses: Expense[]; supplierOrders: SupplierOrder[]; clientOrders: ClientOrder[]; customers: Customer[]; products: Product[]; moves: StockMove[]; sales: Sale[]; ready: boolean; reload: () => Promise<void> }
export interface Props { repo: Repo; data: Data; act: (fn: () => Promise<unknown>) => Promise<void> }

export function useData(repo: Repo): Data {
  const [d, setD] = useState({ expenses: [] as Expense[], supplierOrders: [] as SupplierOrder[], clientOrders: [] as ClientOrder[], customers: [] as Customer[], products: [] as Product[], moves: [] as StockMove[], sales: [] as Sale[], ready: false });
  const reload = useCallback(async () => {
    const [products, moves, sales, customers, expenses, supplierOrders, clientOrders] = await Promise.all([repo.all<Product>('products'), repo.all<StockMove>('moves'), repo.all<Sale>('sales'), repo.all<Customer>('customers'), repo.all<Expense>('expenses'), repo.all<SupplierOrder>('supplierOrders'), repo.all<ClientOrder>('clientOrders')]);
    setD({ products, moves, sales, customers, expenses, supplierOrders, clientOrders, ready: true });
  }, [repo]);
  useEffect(() => { reload(); }, [reload]);
  return { ...d, reload };
}
